// grab the packages we need
var express         = require('express');
var methodOverride  = require('method-override')
var bodyParser      = require('body-parser');
var path            = require('path');
var fs              = require('fs');

var app             = express();
var router          = express.Router();
var port            = process.env.PORT || 5004;

// Create database connection.

app.use(bodyParser.json()); // support json encoded bodies
app.use(bodyParser.urlencoded({	extended: true })); // support encoded bodies
app.use(methodOverride());

app.use('/dist', express.static(path.join(__dirname, './dist')));
app.use('/public', express.static(path.join(__dirname, './public')));
app.use('/sw.js', express.static(path.join(__dirname, './sw.js')));

app.use('/api/*', function(req, res, next) {  
  var request = require('request');
  //var apiUrl = "http://45.34.2.21:5002/api/v1";
  var apiUrl = "http://localhost:5002/api/v1";
  var postData = {};
  var options = {
    method: req.method, 
    url: req.originalUrl.replace("/api", apiUrl),
    form: req.body,
    gzip: true,
    headers: {
      'Content-Type': req.headers['content-type'] || 'application/json',
      'Authorization': req.headers.authorization || '',
    }
  };
  request(options, function (error, response, body) {
      if(error){
        if(isJson(error)){
          res.json(JSON.parse(error));
        }else{
          res.send(error);
        }
      }else{
        if(isJson(body)){
          res.json(JSON.parse(body));
        }else{
          res.send(body);
        }
      }

      function isJson(item) {
          item = typeof item !== "string"
              ? JSON.stringify(item)
              : item;

          try {
              item = JSON.parse(item);
          } catch (e) {
              return false;
          }

          if (typeof item === "object" && item !== null) {
              return true;
          }

          return fals
      }
  })
})

app.use('/', function(req, res, next) {
  res.sendFile(path.join(__dirname, './dist/index.html'));
});

// start the server
app.listen(port);
console.log('Server started! At http://localhost:' + port);