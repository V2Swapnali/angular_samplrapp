import { Component } from '@angular/core';
import {ToasterContainerComponent, ToasterConfig} from 'angular2-toaster';
import { AuthService } from './../../services/auth.services';
declare var jQuery: any;

@Component({
    selector: 'my-app',
    template: `
    <toaster-container [toasterconfig]="toasterconfig"></toaster-container> 
    <p-confirmDialog></p-confirmDialog>
    <nav *ngIf="auth.isLoggedIn">
      <header-comp></header-comp>
      <sidebar-comp></sidebar-comp>
    </nav>
    <div [attr.id]="auth.isLoggedIn ? 'wrapper' : ''">
      <router-outlet></router-outlet>
      <footer-comp *ngIf="auth.isLoggedIn"></footer-comp>
    </div>
  `
})

export class AppComponent {
    constructor(private auth: AuthService) { }

    public toasterconfig: ToasterConfig = new ToasterConfig({
        showCloseButton: true,
        tapToDismiss: true,
        timeout: 10000,
        limit: 1
    });    

    ngAfterViewInit() {
        jQuery(window).bind("load", function () {
            // Remove splash screen after load
            jQuery('.splash').css('display', 'none')
        });

        if (jQuery(window).width() < 769) {
            jQuery('body').addClass('page-small');
        } else {
            jQuery('body').removeClass('page-small');
            jQuery('body').removeClass('show-sidebar');
        }

        jQuery(window).bind("resize click", function () {

            // Add special class to minimalize page elements when screen is less than 768px
            if (jQuery(window).width() < 769) {
                jQuery('body').addClass('page-small');
            } else {
                jQuery('body').removeClass('page-small');
                jQuery('body').removeClass('show-sidebar');
            }

            // Waint until metsiMenu, collapse and other effect finish and set wrapper height
            setTimeout(function () {
                var headerH = 62;
                var navigationH = jQuery("#navigation").height();
                var contentH = jQuery(".content").height();

                // Set new height when contnet height is less then navigation
                if (contentH < navigationH) {
                    jQuery("#wrapper").css("min-height", navigationH + 'px');
                }

                // Set new height when contnet height is less then navigation and navigation is less then window
                if (contentH < navigationH && navigationH < jQuery(window).height()) {
                    jQuery("#wrapper").css("min-height", jQuery(window).height() - headerH + 'px');
                }

                // Set new height when contnet is higher then navigation but less then window
                if (contentH > navigationH && contentH < jQuery(window).height()) {
                    jQuery("#wrapper").css("min-height", jQuery(window).height() - headerH + 'px');
                }
            }, 300);
        });
    }
}