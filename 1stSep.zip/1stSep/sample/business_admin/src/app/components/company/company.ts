import { Component } from '@angular/core';

@Component({
  selector: 'company-component',
  template: `
    <div class="content animate-panel">
        <router-outlet></router-outlet>
    </div>
    `
})

export class CompanyComponent { }