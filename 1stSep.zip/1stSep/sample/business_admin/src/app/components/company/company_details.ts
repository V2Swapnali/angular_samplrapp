import { Component, ViewChild } from '@angular/core';
import { Router, Params } from '@angular/router';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { ToasterService } from 'angular2-toaster';
import { CompanyDetailService } from './services/company_detail.services'
import { AppConfig } from './../../config/app.config';
import { WebStorage } from './../../utility/web.storage';

@Component({
    selector: 'company-detail',
    templateUrl: './html/company_detail.html',
    providers: [
        CompanyDetailService
    ]
})
export class CompanyDetailsComponent {

    constructor(
        private toaster: ToasterService,
        private companyDetail: CompanyDetailService,
        private router: Router,
        private config: AppConfig,
        private formBuilder: FormBuilder,
        private storage: WebStorage
    ) {
        this.companyDetaildata = this.formBuilder.group({
            company: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(25)]],
            logo: ['', [Validators.required]],
            vat_number: ['', [Validators.required]],
            type_business: ['', [Validators.required]],
            type_goods: ['', [Validators.required]],
            category: ['', [Validators.required]],
            default_lang: ['', [Validators.required]],
            timezone: ['', [Validators.required]],
            // default_email: ['', [Validators.required, Validators.pattern(this.config.pattern.EMAIL)]]

        });
    }

    @ViewChild('myngselecttimezone') myngselecttimezone: any;
    public companyDetaildata: FormGroup;
    public roals: any = [];
    public categoryList: any = [];
    public timezoneList: any = [];
    



    save() {
        var self = this;
        self.companyDetail.save(self.companyDetaildata.value).subscribe(function (result) {
            var rs = result.json();
            if (rs.status == 200) {
                self.toaster.pop('success', rs.message);
                //self.router.navigate(['company_detail']);
            } else {
                self.toaster.pop('error', rs.message);
            }
        });
    }

    public ngOnInit(): void {
        let self = this;
        let user = this.storage.get('businessadminUser');
        self.companyDetail.getcategoryList({ root: '0' }).subscribe(function (result) {
            let rs = result.json();
            if (rs.status == 200) {
                self.categoryList = rs.data;
            }

            self.companyDetail.gettimezoneList({}).subscribe(function (result) {
                let rs = result.json();
                if (rs.status == 200) {
                    self.timezoneList = rs.data;
                }

                self.companyDetail.getOne(user.id).subscribe(function (result) {
                    var rs = result.json();
                    if (rs.status == 200) {
                        self.myngselecttimezone.select(parseInt(rs.data.timezone));
                        console.log("self.myngselecttimezone", self.myngselecttimezone)
                        // self.companyDetaildata.patchValue(rs.data);
                        self.companyDetaildata.controls['company'].patchValue(rs.data.company);
                        self.companyDetaildata.controls['logo'].patchValue(rs.data.logo);
                        self.companyDetaildata.controls['vat_number'].patchValue(rs.data.vat_number);
                        self.companyDetaildata.controls['type_business'].patchValue(rs.data.type_business);
                        self.companyDetaildata.controls['type_goods'].patchValue(rs.data.type_goods);
                        self.companyDetaildata.controls['category'].patchValue(rs.data.category);
                        self.companyDetaildata.controls['default_lang'].patchValue(rs.data.default_lang);

                    } else {
                        self.toaster.pop('error', rs.message);
                        //self.router.navigate(['dashboard']);
                    }
                });
            });
        });
    }
}

