import { Component } from '@angular/core';
import { Router, Params } from '@angular/router';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { ToasterService } from 'angular2-toaster';
import { CompanyLocationService } from './services/company_location.services'
import { AppConfig } from './../../config/app.config';

@Component({
    selector: 'companyLocation-edit',
    templateUrl: './html/company_location_add.html',
    providers: [
        CompanyLocationService
    ]
})
export class CompanyLocationaddComponent {

    constructor(
        private toaster: ToasterService,
        private companyLocation: CompanyLocationService,
        private router: Router,
        private config: AppConfig,
        private formBuilder: FormBuilder
    ) {
        this.companyLocationdata = this.formBuilder.group({
            name: ['', [Validators.required, Validators.pattern(this.config.pattern.USERNAME), Validators.maxLength(25)]],
            address: ['', [Validators.required]],
            country: ['', [Validators.required]],
            state: ['', [Validators.required]],
            city: ['', [Validators.required, Validators.pattern(this.config.pattern.CITY),]],
            zip: ['', [Validators.required]],
            phone: ['', [Validators.required]],
            store_hours: ['', [Validators.required]],
            type: ['', [Validators.required]]
        });
    }


    public companyLocationdata: FormGroup;
    public countryList: any = [];
    public stateList: any = [];


    save() {
        var self = this;
        self.companyLocation.save(self.companyLocationdata.value).subscribe(function (result) {
            var rs = result.json();
            if (rs.status == 200) {
                self.toaster.pop('success', rs.message);
                self.router.navigate(['company/location']);
            } else {
                self.toaster.pop('error', rs.message);
            }
        });
    }

    public getState(item: any) {
        let self = this;
        self.companyLocation.getstateList({ c_id: item.value }).subscribe(function (result) {
            let rs = result.json();
            if (rs.status == 200) {
                self.stateList = rs.data;
            }
        });
    }

    public ngOnInit(): void {
        let self = this;
        self.companyLocation.getcountryList({}).subscribe(function (result) {
            let rs = result.json();
            if (rs.status == 200) {
                self.countryList = rs.data;
            }
        });
    }
}
