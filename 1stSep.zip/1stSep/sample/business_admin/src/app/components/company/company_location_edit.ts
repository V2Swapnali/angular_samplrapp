import { Component, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { ToasterService } from 'angular2-toaster';
import { CompanyLocationService } from './services/company_location.services';
import { AppConfig } from './../../config/app.config';

@Component({
    selector: 'companyLocation-edit',
    templateUrl: './html/company_location_edit.html',
    providers: [
        CompanyLocationService
    ]
})
export class CompanyLocationeditComponent {

    constructor(
        private toaster: ToasterService,
        private companyLocation: CompanyLocationService,
        private router: Router,
        private config: AppConfig,
        private activatedRoute: ActivatedRoute,
        private formBuilder: FormBuilder
    ) {
        this.companyLocationdata = this.formBuilder.group({
            name: ['', [Validators.required, Validators.pattern(this.config.pattern.CMPNAME), Validators.maxLength(25)]],
            address: ['', [Validators.required]],
            country: ['', [Validators.required]],
            state: ['', [Validators.required]],
            city: ['', [Validators.required, Validators.pattern(this.config.pattern.CITY),]],
            zip: ['', [Validators.required]],
            phone: ['', [Validators.required]],
            store_hours: ['', [Validators.required]],
            type: ['', [Validators.required]]
        });
    }

    @ViewChild('myngselectcountry') myngselectcountry:any;
    @ViewChild('myngselectstate') myngselectstate:any;
    public companyLocationdata: FormGroup;
    public countryList: any = [];
    public stateList: any = [];
    public oldstate: any = 0;

    save(data: any) {
        var self = this;
        self.activatedRoute.params.subscribe((param: any) => {
            self.companyLocation.update(data.value, param['id']).subscribe(function (result) {
                var rs = result.json();
                if (rs.status == 200) {
                    self.toaster.pop('success', rs.message);
                    self.router.navigate(['company/location']);
                } else {
                    self.toaster.pop('error', rs.message);
                }
            });
        });
    }

    public getState(item: any) {
        let self = this;
        self.companyLocation.getstateList({ c_id: item.value }).subscribe(function (result) {
            let rs = result.json();
            if (rs.status == 200) {
                self.stateList = rs.data;
                setTimeout(function(){ 
                    if(self.oldstate != 0){
                        self.myngselectstate.select(parseInt(self.oldstate));
                        self.oldstate = 0;
                    }
                }, 2000);
            }
        });
    }

    ngOnInit() {
        var self = this;
        self.companyLocation.getcountryList({}).subscribe(function (result) {
            let rs = result.json();
            if (rs.status == 200) {
                self.countryList = rs.data;
            }
        
            self.activatedRoute.params.subscribe((param: any) => {
                self.companyLocation.getOne(param['id']).subscribe(function (result) {
                    var rs = result.json();
                    if (rs.status == 200) {
                        self.myngselectcountry.select(parseInt(rs.data.country));
                        self.oldstate = rs.data.state;
                        //self.vendordata.patchValue(rs.data);
                        self.companyLocationdata.controls['name'].patchValue(rs.data.name);
                        self.companyLocationdata.controls['address'].patchValue(rs.data.address);
                        self.companyLocationdata.controls['city'].patchValue(rs.data.city);
                        self.companyLocationdata.controls['zip'].patchValue(rs.data.zip);
                        self.companyLocationdata.controls['phone'].patchValue(rs.data.phone);
                        self.companyLocationdata.controls['store_hours'].patchValue(rs.data.store_hours);
                        self.companyLocationdata.controls['type'].patchValue(rs.data.type);
                    } else {
                        self.toaster.pop('error', rs.message);
                        self.router.navigate(['company/location']);
                    }
                });
            });
        });
    }
}