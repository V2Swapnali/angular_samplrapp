import { Injectable } from '@angular/core';
import { LocalStorageService, SessionStorageService } from 'ng2-webstorage';
import { Observable } from 'rxjs/Observable';

import { HttpClient } from './../../../utility/http.client';


@Injectable()
export class CompanyDetailService {
  constructor(
    private http: HttpClient
  ) { }

  getOne(id: any): Observable<any> {
    return this.http.get('/companyDetail/get', { business_id: id });
  }
  save(user: any): Observable<any> {
    return this.http.post('/companyDetail/add', user);
  }
  getcategoryList(data: any): Observable<any> {
    return this.http.get('/productcat/treeoptions', data);
  }
  gettimezoneList(data: any): Observable<any> {
    return this.http.get('/timezone/list', data);
  }

}
