import { Injectable } from '@angular/core';
import {LocalStorageService, SessionStorageService} from 'ng2-webstorage';
import { Observable } from 'rxjs/Observable';

import { HttpClient } from './../../../utility/http.client';


@Injectable()
export class CompanyLocationService {
  constructor(
    private http: HttpClient
  ) {}

  getOne(id:any): Observable<any> {
    return this.http.get('/companyLocation/get', {id:id});
  }

  getList(data:any): Observable<any> {
    return this.http.get('/companyLocation/list', data);
  }

  save(user:any): Observable<any> {
    return this.http.post('/companyLocation/add', user);
  }

  update(user:any,id:any): Observable<any> {
    return this.http.post('/companyLocation/edit?id='+id, user);
  }

  deleteMe(id:any){ console.log(id);
    return this.http.post('/companyLocation/delete', id);
  }

  getcountryList(data:any): Observable<any> {
    return this.http.get('/country/list', data);
  }

  getstateList(data:any): Observable<any> {
    return this.http.get('/state/list', data);
  }
  

}
