import { Component } from '@angular/core';

@Component({
  selector: 'customer-component',
  template: `
    <div class="content animate-panel">
        <router-outlet></router-outlet>
    </div>
    `
})

export class CustomerComponent { }