import { Component } from '@angular/core';
import { Router, Params } from '@angular/router';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { ToasterService } from 'angular2-toaster';
import { CustomerService } from './services/customer.services'
import { AppConfig } from './../../config/app.config';

@Component({
    selector: 'customer-add',
    templateUrl: './html/customer_add.html',
    providers: [
        CustomerService
    ]
})
export class CustomeraddComponent {

    constructor(
        private toaster: ToasterService,
        private customer: CustomerService,
        private router: Router,
        private config: AppConfig,
        private formBuilder: FormBuilder
    ) {
        this.customerdata = this.formBuilder.group({
            f_name: ['', [Validators.required, Validators.pattern('[a-zA-Z]*'), Validators.minLength(3), Validators.maxLength(25)]],
            l_name: ['', [Validators.required, Validators.pattern('[a-zA-Z]*'), Validators.minLength(3), Validators.maxLength(25)]],
            email: ['', [Validators.required, Validators.pattern(this.config.pattern.EMAIL)]],
            phone: ['', [Validators.required]],
            company: ['', [Validators.required]],
            address: ['', [Validators.required]],
            country: ['', [Validators.required]],
            state: ['', [Validators.required]],
            city: ['', [Validators.required]],
            zip: ['', [Validators.required]],
        });
    }

    public customerdata: FormGroup;
    public roals: any = [];
    public countryList: any = [];
    public stateList: any = [];

    save() {
        var self = this;
        self.customer.save(self.customerdata.value).subscribe(function (result) {
            var rs = result.json();
            if (rs.status == 200) {
                self.toaster.pop('success', rs.message);
                self.router.navigate(['customer']);
            } else {
                self.toaster.pop('error', rs.message);
            }
        });
    }

    public getState(item: any) {
        let self = this;
        self.customer.getstateList({ c_id: item.value }).subscribe(function (result) {
            let rs = result.json();
            if (rs.status == 200) {
                self.stateList = rs.data;
            }
        });
    }

    public ngOnInit(): void {
        let self = this;
        self.customer.getcountryList({}).subscribe(function (result) {
            let rs = result.json();
            if (rs.status == 200) {
                self.countryList = rs.data;
            }
        });
    }
}