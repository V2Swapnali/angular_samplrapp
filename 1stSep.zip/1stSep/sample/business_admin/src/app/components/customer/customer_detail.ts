import { Component } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { ToasterService } from 'angular2-toaster';
import { CustomerService } from './services/customer.services';
import { AppConfig } from './../../config/app.config';

@Component({
    selector: 'customer-detail',
    templateUrl: './html/customer_detail.html',
    providers: [
        CustomerService
    ]
})
export class CustomerdetailComponent {

    constructor(
        private toaster: ToasterService,
        private customer:CustomerService,
        private router: Router,
        private config: AppConfig,
        private activatedRoute: ActivatedRoute,
        private formBuilder: FormBuilder
    ) {}

    public customerdata:any = [];
 

    ngOnInit() {
        var self = this;
        self.activatedRoute.params.subscribe((param: any) => {
            self.customer.getOne(param['id']).subscribe(function (result) {
                var rs = result.json();
                if (rs.status == 200) {
                    self.customerdata = rs.data;
                } else {
                    self.toaster.pop('error', rs.message);
                    self.router.navigate(['vendor']);
                }
            });
        });
    }
}