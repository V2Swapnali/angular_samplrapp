import { Component, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { ToasterService } from 'angular2-toaster';
import { CustomerService } from './services/customer.services';
import { AppConfig } from './../../config/app.config';

@Component({
    selector: 'customer-edit',
    templateUrl: './html/customer_edit.html',
    providers: [
        CustomerService
    ]
})
export class CustomereditComponent {

    constructor(
        private toaster: ToasterService,
        private customer: CustomerService,
        private router: Router,
        private config: AppConfig,
        private activatedRoute: ActivatedRoute,
        private formBuilder: FormBuilder
    ) {
        this.customerdata = this.formBuilder.group({
            f_name: ['', [Validators.required, Validators.pattern('[a-zA-Z]*'), Validators.minLength(3), Validators.maxLength(25)]],
            l_name: ['', [Validators.required, Validators.pattern('[a-zA-Z]*'), Validators.minLength(3), Validators.maxLength(25)]],
            email: ['', [Validators.required, Validators.pattern(this.config.pattern.EMAIL)]],
            phone: ['', [Validators.required]],
            company: ['', [Validators.required]],
            address: ['', [Validators.required]],
            country: ['', [Validators.required]],
            state: ['', [Validators.required]],
            city: ['', [Validators.required]],
            zip: ['', [Validators.required]],
        });
    }

    @ViewChild('myngselectcountry') myngselectcountry:any;
    @ViewChild('myngselectstate') myngselectstate:any;
    public customerdata: FormGroup;
    public roals: any = [];
    public countryList: any = [];
    public stateList: any = [];
    public oldstate: any = 0;

    save(data: any) {
        var self = this;
        self.activatedRoute.params.subscribe((param: any) => {
            self.customer.update(data.value, param['id']).subscribe(function (result) {
                var rs = result.json();
                if (rs.status == 200) {
                    self.toaster.pop('success', rs.message);
                    self.router.navigate(['customer']);
                } else {
                    self.toaster.pop('error', rs.message);
                }
            });
        });
    }

    public getState(item: any) {
        let self = this;
        self.customer.getstateList({ c_id: item.value }).subscribe(function (result) {
            let rs = result.json();
            if (rs.status == 200) {
                self.stateList = rs.data;
                setTimeout(function(){ 
                    if(self.oldstate != 0){
                        self.myngselectstate.select(parseInt(self.oldstate));
                        self.oldstate = 0;
                    }
                }, 2000);
            }
        });
    }

    ngOnInit() {
        var self = this;
        self.customer.getcountryList({}).subscribe(function (result) {
            let rs = result.json();
            if (rs.status == 200) {
                self.countryList = rs.data;
            }
        
            self.activatedRoute.params.subscribe((param: any) => {
                self.customer.getOne(param['id']).subscribe(function (result) {
                    var rs = result.json();
                    if (rs.status == 200) {
                        self.myngselectcountry.select(parseInt(rs.data.country));
                        self.oldstate = rs.data.state;
                        //self.customerdata.patchValue(rs.data);
                        self.customerdata.controls['f_name'].patchValue(rs.data.f_name);
                        self.customerdata.controls['l_name'].patchValue(rs.data.l_name);
                        self.customerdata.controls['email'].patchValue(rs.data.email);
                        self.customerdata.controls['phone'].patchValue(rs.data.phone);
                        self.customerdata.controls['company'].patchValue(rs.data.company);
                        self.customerdata.controls['address'].patchValue(rs.data.address);
                        self.customerdata.controls['city'].patchValue(rs.data.city);
                        self.customerdata.controls['zip'].patchValue(rs.data.zip);
                    } else {
                        self.toaster.pop('error', rs.message);
                        self.router.navigate(['customer']);
                    }
                });
            });
        });
    }
}