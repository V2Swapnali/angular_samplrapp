import { Injectable } from '@angular/core';
import { LocalStorageService, SessionStorageService } from 'ng2-webstorage';
import { Observable } from 'rxjs/Observable';

import { HttpClient } from './../../../utility/http.client';


@Injectable()
export class CustomerService {
  constructor(
    private http: HttpClient
  ) { }

  getOne(id: any): Observable<any> {
    return this.http.get('/customer/get', { id: id });
  }

  getList(data: any): Observable<any> {
    return this.http.get('/customer/list', data);
  }

  save(user: any): Observable<any> {
    return this.http.post('/customer/add', user);
  }

  update(user: any, id: any): Observable<any> {
    return this.http.post('/customer/edit?id=' + id, user);
  }

  deleteMe(id: any) {
    console.log(id);
    return this.http.post('/customer/delete', id);
  }

  getcategoryList(): Observable<any> {
    return this.http.get('/productcat/treeoptions', {});
  }

  findInMaster(data: any): Observable<any> {
    return this.http.get('/product/masterlist', data);
  }

  getConfOptions(data: any): Observable<any> {
    return this.http.get('/productcat/configoption', data);
  }

  getRoles(): Observable<any> {
    return this.http.get('/role/getall', {});
  }

  getcountryList(data: any): Observable<any> {
    return this.http.get('/country/list', data);
  }

  getstateList(data: any): Observable<any> {
    return this.http.get('/state/list', data);
  }

}
