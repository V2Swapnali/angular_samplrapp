import { Component } from '@angular/core';

@Component({
  selector: 'err404-comp',
  templateUrl: './html/404.html'
})

export class Err404Component { }