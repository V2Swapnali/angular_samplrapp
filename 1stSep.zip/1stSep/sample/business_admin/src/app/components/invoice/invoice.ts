import { Component } from '@angular/core';

@Component({
  selector: 'invoice-component',
  template: `
    <div class="content animate-panel">
        <router-outlet></router-outlet>
    </div>
    `
})

export class InvoiceComponent { }