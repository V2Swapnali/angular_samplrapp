import { Component } from '@angular/core';
import { Router, Params } from '@angular/router';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { ToasterService } from 'angular2-toaster';
import { InvoiceService } from './services/invoice.services'
import { AppConfig } from './../../config/app.config';

@Component({
    selector: 'invoice-add',
    templateUrl: './html/invoice_add.html',
    providers: [
        InvoiceService
    ]
})
export class InvoiceaddComponent {

    constructor(
        private toaster: ToasterService,
        private invoice: InvoiceService,
        private router: Router,
        private config: AppConfig,
        private formBuilder: FormBuilder
    ) {
        this.invoicedata = this.formBuilder.group({
            customer_id: ['', [Validators.required]],
            inv_date: ['', [Validators.required]],
            du_date: ['', [Validators.required]],
            total_due: ['', [Validators.required]],
            balance: ['', [Validators.required]],
            payment_method: ['cash', [Validators.required]],
            currency: ['usd', [Validators.required]],
            terms: ['due_on_recipet', [Validators.required]],
            inv_msg: ['', [Validators.required]],
            int_inv_msg: ['', [Validators.required]],
            items: this.formBuilder.array([])
        });
    }


    public invoicedata: FormGroup;
    public customers: any = [];
    public findProductList: any = [];
    public totalProducts:number = 0;
    public productParams:any = {
        'page': 1,
        'limit': 10,
        'sort': 'created',
        'order': 'desc',
        'name': ''    
    };

    public findProduct(propName: any) {
        var self = this;
        if (propName != '' && propName.length >= 2) {
            self.productParams.name = propName;
            self.invoice.findProduct(self.productParams).subscribe(function (result) {
                var rs = result.json();
                if (rs.status == 200) {
                    self.findProductList = rs.data;
                }
            });
        } else {
            self.findProductList = [];
        }
    }

    public prodPageChanged(event:any):void { 
        this.productParams.page = event.page; 
        this.findProduct(this.productParams.name);
    }

    addProduct(data:any) {
        const control = <FormArray>this.invoicedata.controls['items'];
        const addrCtrl = this.formBuilder.group({
            id: [data.id, Validators.required],
            quentity: [1, Validators.required],
            prod_details: [data]
        });
        control.push(addrCtrl);
    }

    removeProduct(i: number) {
        const control = <FormArray>this.invoicedata.controls['items'];
        control.removeAt(i);
    }

    save() {
        var self = this;
        console.log(self.invoicedata.value);
        /*self.invoice.save(self.invoicedata.value).subscribe(function (result) {
            var rs = result.json();
            if (rs.status == 200) {
                self.toaster.pop('success', rs.message);
                self.router.navigate(['invoice']);
            } else {
                self.toaster.pop('error', rs.message);
            }
        });*/
    }

    public ngOnInit(): void {
        var self = this;
        self.invoice.getCustomers().subscribe(function (result) {
            var rs = result.json();
            if (rs.status == 200) {
                self.customers = rs.data;
            }
        });
    }
}