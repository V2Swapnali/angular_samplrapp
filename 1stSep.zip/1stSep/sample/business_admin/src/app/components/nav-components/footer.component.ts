import { Component } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { AuthService } from './../../services/auth.services';
import { WebStorage } from './../../utility/web.storage';
declare var jQuery:any;

@Component({
  selector: 'footer-comp',
  template: `
    <!-- Footer-->
    <footer class="footer">
        <span class="pull-right">
            YouBlankIt
        </span>
        Company 2015-2020
    </footer>
  `
})

export class FooterComponent { }