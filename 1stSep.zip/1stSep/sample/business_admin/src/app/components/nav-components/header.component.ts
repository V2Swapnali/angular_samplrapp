import { Component } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { AuthService } from './../../services/auth.services';
import { WebStorage } from './../../utility/web.storage';

@Component({
  selector: 'header-comp',
  templateUrl: './html/header.component.html'
})

export class HeaderComponent { 
  user:any;

  constructor(
    private auth: AuthService, 
    private router: Router,
    private storage: WebStorage
  ) {}  

  logout() { 
    var self = this;
    self.auth.logout().subscribe(function(res){
      if(res.status){        
        self.router.navigate(['login']);
      }else{
        console.log('Something went wrong. Please try again!');
      }
    });
  }

  ngOnInit() {
    this.user = this.storage.get('superadminUser');
  }
}