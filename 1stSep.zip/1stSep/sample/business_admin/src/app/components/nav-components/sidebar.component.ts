import { Component } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { AuthService } from './../../services/auth.services';
import { WebStorage } from './../../utility/web.storage';
declare var jQuery:any;

@Component({
  selector: 'sidebar-comp',
  templateUrl: './html/sidebar.component.html'
})

export class SidebarComponent { 
  user:any;
  user_name:any;
  user_id:any;

  constructor(
    private auth: AuthService, 
    private router: Router,
    private storage: WebStorage
  ) {} 

  ngAfterViewInit() {
      jQuery('#side-menu').metisMenu();

      // Handle minimalize sidebar menu
      jQuery('.hide-menu').on('click', function(event:any){
          event.preventDefault();
          if (jQuery(window).width() < 769) {
              jQuery("body").toggleClass("show-sidebar");
          } else {
              jQuery("body").toggleClass("hide-sidebar");
          }
      });

      // Function for small header
      jQuery('.small-header-action').on('click', function(event:any){
          event.preventDefault();
          var icon = jQuery(this).find('i:first');
          var breadcrumb  = jQuery(this).parent().find('#hbreadcrumb');
          jQuery(this).parent().parent().parent().toggleClass('small-header');
          breadcrumb.toggleClass('m-t-lg');
          icon.toggleClass('fa-arrow-up').toggleClass('fa-arrow-down');
      });
  }

  logout() { 
    var self = this;
    self.auth.logout().subscribe(function(res){
      if(res.status){        
        self.router.navigate(['login']);
      }else{
        console.log('Something went wrong. Please try again!');
      }
    });
  }

  ngOnInit() {
    this.user = this.storage.get('businessadminUser');
    if(this.user.f_name == null){ 
      this.user_name = 'Hello Member';
    }else{
      this.user_name = this.user.full_name;
      // this.user_id = this.user.id;
    }    
  }

}