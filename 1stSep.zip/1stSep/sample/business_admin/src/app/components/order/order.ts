import { Component } from '@angular/core';

@Component({
  selector: 'order-component',
  template: `
    <div class="content animate-panel">
        <router-outlet></router-outlet>
    </div>
    `
})

export class OrderComponent { }