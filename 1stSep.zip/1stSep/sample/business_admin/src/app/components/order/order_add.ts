import { Component } from '@angular/core';
import { Router, Params } from '@angular/router';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { ToasterService } from 'angular2-toaster';
import { OrderService } from './services/order.services'
import { AppConfig } from './../../config/app.config';
import { WebStorage } from './../../utility/web.storage';

@Component({
    selector: 'order-add',
    templateUrl: './html/order_add.html',
    providers: [
        OrderService
    ]
})
export class OrderaddComponent {
    public orderdata: FormGroup;
    public acField: any = '';
    public customers: any = [];
    public findProductList: any = [];
    public cartTotal: any = 0;
    public productParams: any = {
        'page': 1,
        'limit': 10,
        'name': ''
    };

    constructor(
        private toaster: ToasterService,
        private order: OrderService,
        private router: Router,
        private config: AppConfig,
        private formBuilder: FormBuilder,
        private storage: WebStorage
    ) {
        this.orderdata = this.formBuilder.group({
            customer_id: [''],
            items: this.formBuilder.array([])
        });
    }

    public findProduct(event: any) {
        var self = this;        
        self.productParams.name = event.query;
        self.order.findProduct(self.productParams).subscribe(function (result) {
            var rs = result.json();
            if (rs.status == 200) {
                self.findProductList = rs.data;
            }
        });
    }

    public prodPageChanged(event: any): void {
        this.productParams.page = event.page;
        this.findProduct(this.productParams.name);
    }

    addProduct(data: any) {
        let self = this;
        self.acField = '';
        let found = 0
        let control = <FormArray>self.orderdata.controls['items'];
        let addrCtrl = self.formBuilder.group({
            id: [data.id, Validators.required],
            quentity: [data.quentity || 1, Validators.required],
            prod_details: [data]
        });

        self.orderdata.value.items.forEach(function (item: any, index: any) {
            if (data.id == item.id && data.vc == item.prod_details.vc) {
                found = 1;
                self.orderdata.controls['items']['controls'][index].controls.quentity.patchValue(self.orderdata.value.items[index].quentity + 1);
            }
        });

        if (found == 0) {
            control.push(addrCtrl);
        } else {
            self.toaster.pop('info', "Already in Order list. Quantity is updated!");
        }
        self.holdProducts();
        self.calculateTotal();
    }

    holdProducts(){
        this.storage.localStore('posHoldOrders', this.orderdata.value);
        this.calculateTotal();
    }

    calculateTotal(){
        let self = this;
        self.cartTotal = 0;
        self.orderdata.value.items.forEach(function (item: any, index:any) {
            self.cartTotal = parseFloat(self.cartTotal)+(parseFloat(self.getVData(item.prod_details.variants,'uprice').co_value)*parseInt(item.quentity));
        });
    }

    removeProduct(i: number) {
        const control = <FormArray>this.orderdata.controls['items'];
        control.removeAt(i);
        this.holdProducts();
        this.calculateTotal();
    }

    getVData(fl: any, type: any) {
        if (type != 'other') {
            var d = fl.find((v: any) => {
                if (type == 'cost' && v.co_id == 18) {
                    return true;
                } else if (type == 'uprice' && v.co_id == 23) {
                    return true;
                } else if (type == 'qty' && v.co_id == 24) {
                    return true;
                }
            });
            return d;
        } else {
            var d = fl.map((v: any) => {
                var except: Array<any> = [18, 23, 24];
                if (except.indexOf(v.co_id) < 0) {
                    return v.confoption.type + ': ' + v.co_value;
                }
            }).filter((n: any) => { return n != undefined }).join(', ');
            return d;
        }

    }    

    save1() {
        var self = this;
        console.log(self.orderdata.value);
        /*self.order.save(self.orderdata.value).subscribe(function (result) {
            var rs = result.json();
            if (rs.status == 200) {
                self.toaster.pop('success', rs.message);
                self.router.navigate(['order']);
            } else {
                self.toaster.pop('error', rs.message);
            }
        });*/
    }

    public ngOnInit(): void {
        let self = this;

        if(self.storage.exists('posHoldOrders')){
            let posHoldOrders = self.storage.get('posHoldOrders');
            self.orderdata.controls['customer_id'].patchValue(posHoldOrders.customer_id);
            posHoldOrders.items.map(function (item: any) {
                let d = item.prod_details;
                d.quentity = item.quentity;
                self.addProduct(d);
            });
        }

        self.order.getCustomers().subscribe(function (result) {
            var rs = result.json();
            if (rs.status == 200) {
                self.customers = rs.data;
            }
        });
    }
}