import { Component, Input, Directive } from '@angular/core'
import { Router, Params, ActivatedRoute } from '@angular/router';
import { ToasterService } from 'angular2-toaster';
import { ConfirmationService } from 'primeng/primeng';

import { AppConfig } from './../../config/app.config';
import { OrderService } from './services/order.services';

@Component({
    selector: 'order-list',
    templateUrl: './html/order_list.html',
    providers: [
        OrderService
    ]
})
export class OrderlistComponent {

    public constructor(
        private router: Router,
        private activatedRoute: ActivatedRoute,
        private config: AppConfig,
        private toaster: ToasterService,
        private confirmationService: ConfirmationService,
        private order: OrderService) {
    }

    /*------------------ Listing Elements --------------------*/
    private listData: any = [];
    public totalItems: number = 0;
    public params: any = {
        'page': 1,
        'limit': this.config.perPageDefault,
        'sort': 'created',
        'order': 'desc',
        'f_name': '',
        'l_name': '',
        'email': '',
        'city': '',
    };

    public setRecordPerPage(records: number): void {
        this.params.page = 1;
        this.params.limit = records;
        this.getAll();
    }

    public pageChanged(event: any): void {
        this.params.page = event.page;
        this.getAll();
    }

    public search(): void {
        console.log(this.params);
    }

    public resetSearch(): void {
        this.params.f_name = '';
        this.params.l_name = '';
        this.params.email = '';
        this.params.city = '';

        this.getAll()
    }

    public getAll() {
        let self = this;
        self.order.getList(self.params).subscribe(function (result) {
            let rs = result.json();
            if (rs.status == 200) {
                self.listData = rs.data;
                self.totalItems = rs.count;
            } else {
                self.toaster.pop('error', rs.message);
            }
        });
    }
    /*------------------ Listing Elements --------------------*/


    public allchk: any = false;
    public categoryList: any = [];
    public checkedData: any = [];

    public checkall() {
        var self = this;
        self.checkedData = [];
        if (self.allchk == false) {
            self.allchk = true;
            self.listData.forEach(function (item: any) {
                self.checkedData.push(item.id);
            });
        } else {
            self.allchk = false;
            self.checkedData = [];
        }
    };

    public deleteOne(id: number) {  
    var self = this;
    this.confirmationService.confirm({
        message: 'Do you want to delete this record?',
        header: 'Delete Confirmation',
        icon: 'fa fa-trash',
        accept: () => {
          self.order.deleteMe({ id: [id] }).subscribe(function (result) {
            var rs = result.json();
            if (rs.status == 200) {
              self.getAll();
              self.toaster.pop('success', rs.message);
            } else {
              self.toaster.pop('error', rs.message);
            }
          });
        }
    });
  }

    public ngOnInit(): void {
        let self = this;
        self.getAll();
    }
}