import { Injectable } from '@angular/core';
import {LocalStorageService, SessionStorageService} from 'ng2-webstorage';
import { Observable } from 'rxjs/Observable';

import { HttpClient } from './../../../utility/http.client';


@Injectable()
export class OrderService {
  constructor(
    private http: HttpClient
  ) {}

  getCustomers(): Observable<any>{
    return this.http.get('/customer/getall', {});
  }

  findProduct(data:any): Observable<any> {
    return this.http.get('/product/getproducts', data);
  }

  getcategoryList(): Observable<any> {
    return this.http.get('/productcat/treeoptions', {});
  } 

  getConfOptions(data:any): Observable<any> {
    return this.http.get('/productcat/configoption', data);
  }

  getOne(id:any): Observable<any> {
    return this.http.get('/order/get', {id:id});
  }

  getList(data:any): Observable<any> {
    return this.http.get('/order/list', data);
  }

  save(user:any): Observable<any> {
    return this.http.post('/order/add', user);
  }

  update(user:any,id:any): Observable<any> {
    return this.http.post('/order/edit?id='+id, user);
  }

  deleteMe(id:any){ console.log(id);
    return this.http.post('/order/delete', id);
  }  
}
