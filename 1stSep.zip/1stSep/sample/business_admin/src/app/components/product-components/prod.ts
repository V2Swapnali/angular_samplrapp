import { Component } from '@angular/core';

@Component({
  selector: 'prod-component',
  template: `
    <div class="content animate-panel">
        <router-outlet></router-outlet>
    </div>
    `
})

export class ProdComponent { }