import { Component, ViewChild } from '@angular/core';
import { Router, Params } from '@angular/router';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { ToasterService } from 'angular2-toaster';
import { TmpStorage } from './../../utility/temp.storage';
import { AppConfig } from './../../config/app.config';
import { ProductService } from './services/product.services'

@Component({
  selector: 'bu-add-n',
  templateUrl: './html/prod_add_n.html',
  providers: [
    ProductService
  ]
})
export class ProdaddnewComponent {

  constructor(
    private toaster: ToasterService,
    private product: ProductService,
    private config: AppConfig,
    private router: Router,
    private formBuilder: FormBuilder,
    private tmpStorage: TmpStorage
  ) {
    this.productdata = this.formBuilder.group({
      category_id: ['', [Validators.required]],
      type: ['consumable', [Validators.required]],
      name: ['', [Validators.required]],
      description: ['', [Validators.required]],
      conf_options: this.formBuilder.array([])
    });
  }

  @ViewChild('myngselect') myngselect:any;
  public productdata: FormGroup;
  private catAddPopup: boolean = false;
  private categoryList: any = [];
  private configOptions: any = [];
  private configOptionsarr: any = {};

  save() {
    var self = this;
    self.productdata.value.is_new = 1;
    self.product.save(self.productdata.value).subscribe(function (result) {
      var rs = result.json();
      if (rs.status == 200) {
        self.toaster.pop('success', rs.message);
        self.router.navigate(['products']);
      } else {
        self.toaster.pop('error', rs.message);
      }
    });
  }

  openCatPopup(){
    this.catAddPopup = true;
  }

  addVariant() {
    const control = <FormArray>this.productdata.controls['conf_options'];
    const addrCtrl = this.formBuilder.group(this.configOptionsarr);
    control.push(addrCtrl);
  }

  removeVariant(i: number) {
    const control = <FormArray>this.productdata.controls['conf_options'];
    control.removeAt(i);
  }

  removeAllValues() {
    let self = this;
    let valueLength = self.productdata.value['conf_options'].length;
    for(var i = 0; i < valueLength; i++){
      self.removeVariant(0)
    }
  }

  public generateArray(val:any){
    return JSON.parse(val);
  }

  public changeType() {
    let self = this;
    self.productdata.value['category_id'] = '';
    self.myngselect.clear();
    self.removeAllValues();
  }

  public noOptionClick(item:any) {
    let self = this;
    console.log(item);
  }

  public getConfig(item:any) {
    let self = this;
    self.removeAllValues();
    if(item.value > 0){
      self.product.getConfOptions({id:item.value, type:self.productdata.value.type}).subscribe(function (result) {
        let rs = result.json();
        if (rs.status == 200) {
          self.configOptions = rs.data.configure_options;
          rs.data.configure_options.forEach((v:any) => {
            switch (v.confdata.field) {      
              case 'text':
              case 'numeric':
              case 'select': 
                  self.configOptionsarr['id'+v.confdata.id] = self.formBuilder.group({
                    val: ['', [Validators.required]],
                    unit: ['']
                  });
                break;
              case 'textunit':
              case 'numericunit':
              case 'selectunit':
                  self.configOptionsarr['id'+v.confdata.id] = self.formBuilder.group({
                    val: ['', [Validators.required]],
                    unit: ['', [Validators.required]]
                  });
                break;
            }            
          });
          self.addVariant();
        } else {
          self.toaster.pop('error', rs.message);
        }
      });
    }
  }  

  public ngOnInit(): void {
    let self = this;
    let prodName = self.tmpStorage.get('productName') || 'sourav';
    self.tmpStorage.remove('productName')
    self.productdata.controls['name'].patchValue(prodName, {onlySelf: true});
    self.product.getcategoryList({root:'0'}).subscribe(function (result) { 
      let rs = result.json();
      if (rs.status == 200) {
        self.categoryList = rs.data;
      } else {
        self.toaster.pop('error', rs.message);
      }
    });
  }
}