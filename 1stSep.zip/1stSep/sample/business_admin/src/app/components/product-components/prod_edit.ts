import { Component, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { ToasterService } from 'angular2-toaster';
import { AppConfig } from './../../config/app.config';
import { ProductService } from './services/product.services'

@Component({
  selector: 'prod-edit',
  templateUrl: './html/prod_edit.html',
  providers:[
    ProductService    
  ]
})
export class ProdeditComponent {

  constructor(
    private toaster: ToasterService,
    private product: ProductService,
    private router: Router,
    private config: AppConfig,
    private activatedRoute: ActivatedRoute,
    private formBuilder: FormBuilder
  ) {
    this.productdata = this.formBuilder.group({
      category_id: ['', [Validators.required]],
      type: ['consumable', [Validators.required]],
      name: ['', [Validators.required]],
      description: ['', [Validators.required]],
      conf_options: this.formBuilder.array([])
    });
  }

  @ViewChild('myngselect') myngselect:any;
  public productdata: FormGroup;
  private categoryList: any = [];
  private configOptions: any = [];
  private configOptionsarr: any = {};
  private oldOptionsData: any = [];

  save() {
    var self = this;
    self.activatedRoute.params.subscribe((param: any) => {
      self.productdata.value.is_new = 0;
      self.product.update(self.productdata.value,param['id']).subscribe(function (result) {
        var rs = result.json();
        if (rs.status == 200) {
          self.toaster.pop('success', rs.message);
          self.router.navigate(['products']);
        } else {
          self.toaster.pop('error', rs.message);
        }
      });
    });
  }

  addVariant() {
    const control = <FormArray>this.productdata.controls['conf_options'];
    const addrCtrl = this.formBuilder.group(this.configOptionsarr);
    control.push(addrCtrl);
  }

  removeVariant(i: number) {
    const control = <FormArray>this.productdata.controls['conf_options'];
    control.removeAt(i);
  }

  removeAllValues() {
    let self = this;
    let valueLength = self.productdata.value['conf_options'].length;
    for(var i = 0; i < valueLength; i++){
      self.removeVariant(0)
    }
  }

  public generateArray(val:any){
    return JSON.parse(val);
  }

  public changeType() {
    let self = this;
    self.productdata.value['category_id'] = '';
    self.myngselect.clear();
    self.removeAllValues();
  }

  public getConfig(item:any) {
    let self = this;
    self.removeAllValues();
    if(item.value > 0){
      self.product.getConfOptions({id:item.value, type:self.productdata.value.type}).subscribe(function (result) {
        let rs = result.json();
        if (rs.status == 200) {
          self.configOptions = rs.data.configure_options;
          rs.data.configure_options.forEach((v:any) => {
            switch (v.confdata.field) {      
              case 'text':
              case 'numeric':
              case 'select': 
                  self.configOptionsarr['id'+v.confdata.id] = self.formBuilder.group({
                    val: ['', [Validators.required]],
                    unit: ['']
                  });
                break;
              case 'textunit':
              case 'numericunit':
              case 'selectunit':
                  self.configOptionsarr['id'+v.confdata.id] = self.formBuilder.group({
                    val: ['', [Validators.required]],
                    unit: ['', [Validators.required]]
                  });
                break;
            }            
          });

          if(self.oldOptionsData.length > 0){
            let confKeys = Object.keys(self.configOptionsarr);
            self.oldOptionsData.forEach((val:any) => {
              let zz = self.configOptionsarr;
              confKeys.forEach((v:any) => {
                if(typeof val[v] != 'undefined'){
                  zz[v] = self.formBuilder.group({
                    val: [val[v].val, [Validators.required]],
                    unit: [val[v].unit]
                  });val[v];
                }else{
                  zz[v] = self.formBuilder.group({
                    val: ['', [Validators.required]],
                    unit: ['']
                  });
                }
              });
              const control = <FormArray>self.productdata.controls['conf_options'];
              const addrCtrl = self.formBuilder.group(zz);
              control.push(addrCtrl);
            });
          }else{
            self.addVariant();
          }
        } else {
          self.toaster.pop('error', rs.message);
        }
      });
    }
  }  

  public ngOnInit(): void {
    let self = this;    
    self.product.getcategoryList({root:'0'}).subscribe(function (result) {
      let rs = result.json();
      if (rs.status == 200) {
        self.categoryList = rs.data;
      }     

      self.activatedRoute.params.subscribe((param: any) => {
          self.product.getOne(param['id']).subscribe(function(result){
            var rs = result.json();
            if(rs.status == 200){
              self.myngselect.select(rs.data.category_id);
              self.productdata.controls['type'].patchValue(rs.data.type);
              self.productdata.controls['name'].patchValue(rs.data.name);
              self.productdata.controls['description'].patchValue(rs.data.description);
              
              rs.data.variants.forEach((v:any) => {
                if(typeof self.oldOptionsData[v.vg_count] == 'undefined'){
                  self.oldOptionsData[v.vg_count] = {};
                }
                self.oldOptionsData[v.vg_count]['id'+v.co_id] = {
                  "val": v.co_value,
                  "unit": v.co_unit
                };
              })           
            }else{
              self.toaster.pop('error', rs.message);
              self.router.navigate(['businessusers']);
            }
          });
      });
    });
  }
 }