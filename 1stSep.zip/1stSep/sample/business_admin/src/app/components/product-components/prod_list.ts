import { Component, Input, Directive } from '@angular/core'
import { Router, Params, ActivatedRoute } from '@angular/router';
import { ToasterService } from 'angular2-toaster';
import { ConfirmationService } from 'primeng/primeng';

import { AppConfig } from './../../config/app.config';
import { TmpStorage } from './../../utility/temp.storage';
import { ProductService } from './services/product.services'

@Component({
  selector: 'bu-list',
  templateUrl: './html/prod_list.html', 
  providers: [
    ProductService
  ]
})
export class ProdlistComponent {  

  public constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private config: AppConfig,
    private tmpStorage: TmpStorage,
    private toaster: ToasterService,
    private confirmationService: ConfirmationService,
    private product: ProductService) {
  }

  /*------------------ Listing Elements --------------------*/
  private listData: any = [];
  public totalItems:number = 0;
  public params:any = {
    'page': 1,
    'limit': this.config.perPageDefault,
    'sort': 'created',
    'order': 'desc',
    'name': '',
    'type': '',
    'category': ''    
  };

  public setRecordPerPage(records:number):void {
    this.params.page = 1;
    this.params.limit = records;
    this.getAll();
  }
 
  public pageChanged(event:any):void { 
    this.params.page = event.page; 
    this.getAll();
  }

  public search():void {
    console.log(this.params);
  }

  public resetSearch():void {
    this.params.name = '';
    this.params.type = '';
    this.params.category = '';
    this.getAll()
  }

  public getAll() {    
    let self = this;
    self.product.getList(self.params).subscribe(function (result) {
      let rs = result.json();
      if (rs.status == 200) {
        self.listData = rs.data;
        self.totalItems = rs.count;
      } else {
        self.toaster.pop('error', rs.message);
      }
    });    
  } 
  /*------------------ Listing Elements --------------------*/

  public findMasterList: any = [];
  public findPropMaster(propName:any){
    var self = this;
    if (propName != '' && propName.length >= 3) {
      self.product.findInMaster({ name: propName }).subscribe(function (result) {
        var rs = result.json();
        if (rs.status == 200) {
          self.findMasterList = rs.data;
        }
      });
    } else {
      self.findMasterList = [];
    }    
  }

  public createNew(propName:any){
    var self = this;
    self.tmpStorage.set('productName',propName);
    self.router.navigate(['/products/add']);        
  }

  public allchk: any = false;
  public categoryList: any = [];
  public checkedData: any = [];  

  public checkall() {
    var self = this;
    self.checkedData = [];
    if (self.allchk == false) {
      self.allchk = true;
      self.listData.forEach(function (item: any) {
        self.checkedData.push(item.id);
      });
    } else {
      self.allchk = false;
      self.checkedData = [];
    }
  };


    public deleteOne(id: number) {  
    var self = this;
    this.confirmationService.confirm({
        message: 'Do you want to delete this record?',
        header: 'Delete Confirmation',
        icon: 'fa fa-trash',
        accept: () => {
          self.product.deleteMe({ id: [id] }).subscribe(function (result) {
            var rs = result.json();
            if (rs.status == 200) {
              self.getAll();
              self.toaster.pop('success', rs.message);
            } else {
              self.toaster.pop('error', rs.message);
            }
          });
        }
    });
  }

  public ngOnInit(): void {
    let self = this;
    self.getAll();     
    self.product.getcategoryList({root:'0'}).subscribe(function (result) {
      let rs = result.json();
      if (rs.status == 200) {
        self.categoryList = rs.data;
      }
    });  
  }
}