import { Injectable } from '@angular/core';
import {LocalStorageService, SessionStorageService} from 'ng2-webstorage';
import { Observable } from 'rxjs/Observable';

import { HttpClient } from './../../../utility/http.client';


@Injectable()
export class ProductService {
  constructor(
    private http: HttpClient
  ) {}

  getOne(id:any): Observable<any> {
    return this.http.get('/product/get', {id:id});
  }

  getList(data:any): Observable<any> {
    return this.http.get('/product/list', data);
  }

  save(user:any): Observable<any> {
    return this.http.post('/product/add', user);
  }

  update(user:any,id:any): Observable<any> {
    return this.http.post('/product/edit?id='+id, user);
  }

  deleteMe(ids:any){ console.log(ids);
    return this.http.post('/product/delete', ids);
  }

  getcategoryList(data:any): Observable<any> {
    return this.http.get('/productcat/treeoptions', data);
  } 

  findInMaster(data:any): Observable<any> {
    return this.http.get('/product/masterlist', data);
  }

  getMasterData(data:any): Observable<any> {
    return this.http.get('/product/masterget', data);
  }

  getConfOptions(data:any): Observable<any> {
    return this.http.get('/productcat/configoption', data);
  }

}