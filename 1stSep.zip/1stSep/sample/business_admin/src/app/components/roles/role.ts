import { Component } from '@angular/core';

@Component({
  selector: 'role-component',
  template: `
    <div fullscreen id="page-wrapper">
    <div class="container-fluid">
        <router-outlet></router-outlet>
    </div>
    <!-- /.container-fluid -->
    </div>
    `
})

export class RoleComponent { }