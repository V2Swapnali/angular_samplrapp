import { Component } from '@angular/core';
import { Router, Params } from '@angular/router';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { ToasterService } from 'angular2-toaster';
import { AppConfig } from './../../config/app.config';
import { RolesService } from './services/role.services'

@Component({
  selector: 'role-add',
  templateUrl: './html/role_add.html',
  providers:[
    RolesService
  ]
})
export class RoleaddComponent {

  constructor(
    private toaster: ToasterService,
    private roles: RolesService,
    private router: Router,
    private config: AppConfig,
    private formBuilder: FormBuilder
  ) {
    this.addRole = this.formBuilder.group({
      role: ['', [Validators.required,Validators.pattern(this.config.pattern.USERNAME)]]
    }); 
  }

  public addRole: FormGroup;
  private modulesData: any = [];
  private checkedOpts:any = [];

  save(){
    var self = this;
    if(self.checkedOpts.length > 0){
      self.addRole.value.role_details = self.checkedOpts;
      self.roles.save(self.addRole.value).subscribe(function(result){
        var rs = result.json();
        if(rs.status == 200){
          self.toaster.pop('success', rs.message);
          self.router.navigate(['roles']);
        }else{
          self.toaster.pop('error', rs.message);
        }
      }); 
    }else{
      self.toaster.pop('error', "Please select access permissions!");
    } 
  }

   public ngOnInit(): void {
    let self = this;
    self.roles.getpermission({'role': ''}).subscribe(function (result) {
      let rs = result.json();
      if (rs.status == 200) {
         self.modulesData = rs.data;
      }
    });  
  }
 }