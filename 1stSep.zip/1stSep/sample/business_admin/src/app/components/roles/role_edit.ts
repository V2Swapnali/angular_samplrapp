import { Component } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { ToasterService } from 'angular2-toaster';
import { AppConfig } from './../../config/app.config';
import { RolesService } from './services/role.services'

@Component({
  selector: 'role-edit',
  templateUrl: './html/role_edit.html',
  providers:[
    RolesService
  ]
})
export class RoleeditComponent {

  constructor(
    private toaster: ToasterService,
    private roles: RolesService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private config: AppConfig,
    private formBuilder: FormBuilder
  ) {
    this.roleFrm = this.formBuilder.group({
     role: ['', [Validators.required,Validators.pattern(this.config.pattern.USERNAME)]]
    }); 
  }

  public roleFrm: FormGroup;
  private modulesData: any = [];
  private checkedOpts:any = [];

  save(){
    var self = this;
    if(self.checkedOpts.length > 0){
      self.roleFrm.value.role_details = self.checkedOpts;
      self.activatedRoute.params.subscribe((param: any) => {
        self.roles.update(self.roleFrm.value, param['id']).subscribe(function(result){
            var rs = result.json();
            if(rs.status == 200){
            self.toaster.pop('success', rs.message);
            self.router.navigate(['roles']);
            }else{
            self.toaster.pop('error', rs.message);
            }
        }); 
      });
    }else{
      self.toaster.pop('error', "Please select access permissions!");
    }  
  }

   public ngOnInit(): void {
    let self = this;
    self.roles.getpermission({'role': ''}).subscribe(function (result) {
      let rs = result.json();
      if (rs.status == 200) {
         self.modulesData = rs.data;
      }    

      self.activatedRoute.params.subscribe((param: any) => {
          self.roles.getOne(param['id']).subscribe(function(result){
            var rs = result.json();
            if(rs.status == 200){
              self.roleFrm.patchValue(rs.data);
              self.checkedOpts = rs.data.role_details.split(',').map((v:any) => { return parseInt(v) });
            }else{
              self.toaster.pop('error', rs.message);
              self.router.navigate(['roles']);
            }
          });
      }); 
    }); 
  }
 }