import { Injectable } from '@angular/core';
import {LocalStorageService, SessionStorageService} from 'ng2-webstorage';
import { Observable } from 'rxjs/Observable';

import { HttpClient } from './../../../utility/http.client';


@Injectable()
export class RolesService {
  isLoggedIn: boolean = false;
  redirectUrl: string; 

  constructor(
    private http: HttpClient
  ) {}

  getOne(id:any): Observable<any> {
    return this.http.get('/role/get', {id:id});
  }

  getList(data:any): Observable<any> {
    return this.http.get('/role/list', data);
  }

  save(user:any): Observable<any> {
    return this.http.post('/role/add', user);
  }

  update(user:any,id:any): Observable<any> {
    return this.http.post('/role/edit?id='+id, user);
  }

  deleteMe(id:any){
    return this.http.post('/role/delete', id);
  }

    getpermission(data:any): Observable<any> {
    return this.http.get('/permission/tree', data);
  }  

}