import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';

import { HttpClient } from './../../../utility/http.client';


@Injectable()
export class SettingsService {
  constructor(
    private http: HttpClient
  ) {}

  getSettings(data:any): Observable<any> {
    return this.http.get('/settings/get', data);
  }

  save(data:any): Observable<any> {
    return this.http.post('/settings/save', data);
  }
}
