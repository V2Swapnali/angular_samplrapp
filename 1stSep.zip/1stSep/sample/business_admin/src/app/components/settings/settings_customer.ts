import { Component } from '@angular/core';
import { Router, Params } from '@angular/router';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { ToasterService } from 'angular2-toaster';
import { SettingsService } from './services/settings.services'
import { AppConfig } from './../../config/app.config';

@Component({
    selector: 'customer-settings',
    templateUrl: './html/settings_customer.html',
    providers: [
        SettingsService
    ]
})
export class SettingsCustomerComponent {

    constructor(
        private toaster: ToasterService,
        private settings: SettingsService,
        private router: Router,
        private config: AppConfig,
        private formBuilder: FormBuilder
    ) {
        this.settingsdata = this.formBuilder.group({
            require_tax_id: [false, [Validators.required]],
            require_manual_approval: [false, [Validators.required]]
        });
    }

    public settingsdata: FormGroup;

    save() {
        var self = this;
        self.settings.save({'settings': self.settingsdata.value, 'settings_name':'customer'}).subscribe(function (result) {
            var rs = result.json();
            if (rs.status == 200) {
                self.toaster.pop('success', rs.message);
            } else {
                self.toaster.pop('error', rs.message);
            }
        });
    }

    public ngOnInit(): void {
        let self = this;
        self.settings.getSettings({'type':'customer'}).subscribe(function (result) {
            let rs = result.json();
            if (rs.status == 200) {
                self.settingsdata.patchValue(rs.data);
            }
        });
    }
}
