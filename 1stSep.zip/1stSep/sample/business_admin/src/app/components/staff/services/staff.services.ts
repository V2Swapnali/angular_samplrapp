import { Injectable } from '@angular/core';
import {LocalStorageService, SessionStorageService} from 'ng2-webstorage';
import { Observable } from 'rxjs/Observable';

import { HttpClient } from './../../../utility/http.client';


@Injectable()
export class StaffService {
  constructor(
    private http: HttpClient
  ) {}

  getOne(id:any): Observable<any> {
    return this.http.get('/staff/get', {id:id});
  }

  getList(data:any): Observable<any> {
    return this.http.get('/staff/list', data);
  }

  save(user:any): Observable<any> {
    return this.http.post('/staff/add', user);
  }

  update(user:any,id:any): Observable<any> {
    return this.http.post('/staff/edit?id='+id, user);
  }

  deleteMe(id:any){ console.log(id);
    return this.http.post('/staff/delete', id);
  }

  getcategoryList(): Observable<any> {
    return this.http.get('/productcat/treeoptions', {});
  } 

  findInMaster(data:any): Observable<any> {
    return this.http.get('/product/masterlist', data);
  }

  getConfOptions(data:any): Observable<any> {
    return this.http.get('/productcat/configoption', data);
  }

  getRoles(): Observable<any> {
    return this.http.get('/role/getall', {});
  }

 status_change(data: any): Observable<any> {
    return this.http.post('/user/bu/status_change', data);
  }
}
