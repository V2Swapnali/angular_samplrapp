import { Component } from '@angular/core';

@Component({
  selector: 'staff-component',
  template: `
    <div class="content animate-panel">
        <router-outlet></router-outlet>
    </div>
    `
})

export class StaffComponent { }