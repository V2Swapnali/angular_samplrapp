import { Component } from '@angular/core';
import { Router, Params } from '@angular/router';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { ToasterService } from 'angular2-toaster';
import { StaffService } from './services/staff.services'
import { AppConfig } from './../../config/app.config';

@Component({
  selector: 'staff-add',
  templateUrl: './html/staff_add.html',
  providers: [
    StaffService
  ]
})
export class StaffaddComponent {

  constructor(
    private toaster: ToasterService,
    private staff: StaffService,
    private router: Router,
    private config: AppConfig,
    private formBuilder: FormBuilder
  ) {
    this.staffdata = this.formBuilder.group({
      role_id: ['', [Validators.required]],
      user_name: ['', [Validators.required]],
      email: ['', [Validators.required, Validators.pattern(this.config.pattern.EMAIL)]],
      f_name: ['', [Validators.required, Validators.pattern(this.config.pattern.NAME), Validators.minLength(3), Validators.maxLength(25)]],
      l_name: ['', [Validators.required, Validators.pattern(this.config.pattern.NAME), Validators.minLength(3), Validators.maxLength(25)]],
      password: ['', [Validators.required]],
      pay_rate: ['', [Validators.required]],
      pay_schedule: ['', [Validators.required]],
      pay_method: ['', [Validators.required]],
      hire_date: ['', [Validators.required]],
      location: ['', [Validators.required]]
    });
  }


  public staffdata: FormGroup;
  public roals: any = [];

  save() {
    var self = this;
    self.staff.save(self.staffdata.value).subscribe(function (result) {
      var rs = result.json();
      if (rs.status == 200) {
        self.toaster.pop('success', rs.message);
        self.router.navigate(['staff']);
      } else {
        self.toaster.pop('error', rs.message);
      }
    });
  }

  public ngOnInit(): void {
    var self = this;
    self.staff.getRoles().subscribe(function (result) {
      var rs = result.json();
      if (rs.status == 200) {
        self.roals = rs.data;
      }
    });

  }
}