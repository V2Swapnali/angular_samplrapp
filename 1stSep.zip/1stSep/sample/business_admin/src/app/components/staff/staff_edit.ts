import { Component } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { ToasterService } from 'angular2-toaster';
import { StaffService } from './services/staff.services';
import { AppConfig } from './../../config/app.config';

@Component({
  selector: 'bu-add',
  templateUrl: './html/staff_edit.html',
  providers:[
    StaffService    
  ]
})
export class StaffeditComponent {

  constructor(
    private toaster: ToasterService,
    private staff: StaffService,
    private router: Router,
    private config: AppConfig,
    private activatedRoute: ActivatedRoute,
    private formBuilder: FormBuilder
  ) {
    this.staffdata = this.formBuilder.group({
      role_id: ['', [Validators.required]],
      user_name: ['', [Validators.required]],
      email: ['', [Validators.required, Validators.pattern(this.config.pattern.EMAIL)]],
      f_name: ['', [Validators.required, Validators.pattern(this.config.pattern.NAME), Validators.minLength(3), Validators.maxLength(25)]],
      l_name: ['', [Validators.required, Validators.pattern(this.config.pattern.NAME), Validators.minLength(3), Validators.maxLength(25)]],
    });
  }

  public staffdata: FormGroup;
  public roals:any = [];

  save(data:any){
    var self = this;
    self.activatedRoute.params.subscribe((param: any) => {
      self.staff.update(data.value,param['id']).subscribe(function(result){
        var rs = result.json();
        if(rs.status == 200){
          self.toaster.pop('success', rs.message);
          self.router.navigate(['staff']);
        }else{
          self.toaster.pop('error', rs.message);
        }
      }); 
    });  
  }

  ngOnInit() {
    var self = this; 
    self.staff.getRoles().subscribe(function (result) {
      var rs = result.json();
      if (rs.status == 200) {
        self.roals = rs.data;
      }
    });

    self.activatedRoute.params.subscribe((param: any) => {
        self.staff.getOne(param['id']).subscribe(function(result){
          var rs = result.json();
          if(rs.status == 200){
            self.staffdata.patchValue(rs.data);
          }else{
            self.toaster.pop('error', rs.message);
            self.router.navigate(['businessusers']);
          }
        });
    });        
  }  
 }