import { Component, Input, Directive } from '@angular/core'
import { Router, Params, ActivatedRoute } from '@angular/router';
import { ToasterService } from 'angular2-toaster';
import { ConfirmationService } from 'primeng/primeng';

import { AppConfig } from './../../config/app.config';
import { StaffService } from './services/staff.services'

@Component({
  selector: 'staff-list',
  templateUrl: './html/staff_list.html', 
  providers: [
    StaffService
  ]
})
export class StafflistComponent {  

  public constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private config: AppConfig,
    private toaster: ToasterService,
    private confirmationService: ConfirmationService,
    private staff: StaffService) {
  }

  /*------------------ Listing Elements --------------------*/
  private listData: any = [];
  public totalItems:number = 0;
  public params:any = {
    'page': 1,
    'limit': this.config.perPageDefault,
    'sort': 'created',
    'order': 'desc',
    'f_name': '',    
  };

  public setRecordPerPage(records:number):void {
    this.params.page = 1;
    this.params.limit = records;
    this.getAll();
  }
 
  public pageChanged(event:any):void { 
    this.params.page = event.page; 
    this.getAll();
  }

  public search():void {
    console.log(this.params);
  }

  public resetSearch():void {
    this.params.f_name = '';
    this.getAll()
  }

 public checked: any = [];  

  public getAll() {    
    let self = this;
    self.staff.getList(self.params).subscribe(function (result) {
      let rs = result.json();
      if (rs.status == 200) {
        self.listData = rs.data;
        self.listData.forEach(function(list:any){
          self.checked['checked_'+list.id] = (list.status ==1)?true:false;          
        })
        self.totalItems = rs.count;
      } else {
        self.toaster.pop('error', rs.message);
      }
    });    
  } 
  /*------------------ Listing Elements --------------------*/

  public findMasterList: any = [];
  public findPropMaster(propName:any){
    var self = this;
    if (propName != '') {
      self.staff.findInMaster({ name: propName }).subscribe(function (result) {
        var rs = result.json();
        if (rs.status == 200) {
          self.findMasterList = rs.data;
        }
      });
    } else {
      self.toaster.pop('error', 'Please enter a name!');
    }    
  }

  public allchk: any = false;
  public categoryList: any = [];
  public checkedData: any = [];  
  public status: any = false;
  public checkall() {
    var self = this;
    self.checkedData = [];
    if (self.allchk == false) {
      self.allchk = true;
      self.listData.forEach(function (item: any) {
        self.checkedData.push(item.id);
      });
    } else {
      self.allchk = false;
      self.checkedData = [];
    }
  };

  public deleteOne(id: number) {  
    var self = this;
    this.confirmationService.confirm({
        message: 'Do you want to delete this record?',
        header: 'Delete Confirmation',
        icon: 'fa fa-trash',
        accept: () => {
          self.staff.deleteMe({ id: [id] }).subscribe(function (result) {
            var rs = result.json();
            if (rs.status == 200) {
              self.getAll();
              self.toaster.pop('success', rs.message);
            } else {
              self.toaster.pop('error', rs.message);
            }
          });
        }
    });
  }

public handleChange(e:any,id:any){
    var self = this;    
    self.staff.status_change({'status':(e.checked)?1:0,'id':id}).subscribe(function (result) {
      var rs = result.json();
      if (rs.status == 200) {
        self.status = (rs.data.status == 1)?true:false;
        self.toaster.pop('success', rs.message);
      } else {
        self.toaster.pop('error', rs.message);
      }
    });
}

  public ngOnInit(): void {
    let self = this;
    self.getAll();     
    self.staff.getcategoryList().subscribe(function (result) {
      let rs = result.json();
      if (rs.status == 200) {
        self.categoryList = rs.data;
      }
    });  
  }
}