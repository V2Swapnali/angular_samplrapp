import { Component } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { ToasterService } from 'angular2-toaster';
import { WebStorage } from './../../utility/web.storage';
import { AppConfig } from './../../config/app.config';
import { UserService } from './services/user.services';


@Component({
  selector: 'account-security',
  templateUrl: './html/account_security.html',
  providers: [
    UserService
  ]
})
export class AccountSecurityComponent {

  constructor(
    private toaster: ToasterService,
    private user: UserService,
    private router: Router,
    private config: AppConfig,
    private activatedRoute: ActivatedRoute,
    private formBuilder: FormBuilder,
    private storage: WebStorage
  ) { }

  public pwd_reset_settings: any = false;

  save() {
    var self = this;
    self.user.account_security({'pwd_reset_settings':(self.pwd_reset_settings)?1:0}).subscribe(function (result) {
      var rs = result.json();
      if (rs.status == 200) {
        self.toaster.pop('success', rs.message);
      } else {
        self.toaster.pop('error', rs.message);
      }
    });
  }

  ngOnInit() {
    var self = this;
    let user = this.storage.get('businessadminUser');
    self.user.getOne(user.id).subscribe(function (result) {
      var rs = result.json();
      if (rs.status == 200) {
        self.pwd_reset_settings = (rs.data.pwd_reset_settings == 1)?true:false;
      } else {
        self.toaster.pop('error', rs.message);
        self.router.navigate(['dashboard']);
      }
    });
  }
}