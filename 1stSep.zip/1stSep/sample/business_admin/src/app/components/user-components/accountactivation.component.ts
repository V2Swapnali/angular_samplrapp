import { Component } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { ToasterService } from 'angular2-toaster';
import { AppConfig } from './../../config/app.config';
import { AuthService } from './../../services/auth.services';
import { UserService } from './services/user.services';

@Component({
  selector: 'registration',
  templateUrl: './html/accountactivation.component.html',
  providers:[
    UserService
  ]
})

export class AccountactivationComponent {    

  constructor(
    private toaster: ToasterService,
    private auth: AuthService, 
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private config: AppConfig,
    private userservice: UserService
  ) { }

  public loadstatus:any = true;
  public activationKeyStatus:any = false;

  ngOnInit() {    
    var self = this;
    self.activatedRoute.params.subscribe((param: any) => {
      if(param['id'] != ''){
        self.userservice.checkActKey({'key':param['id']}).subscribe(function(res:any){
          self.loadstatus = false;
          let body = res.json();
          if(body.status == 200){
            self.activationKeyStatus = true;            
          }
        });
      }else{
        self.loadstatus = false;
      }
    });
  }
}