import { Component } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { ToasterService } from 'angular2-toaster';
import { matchingPasswords } from './../../shared/validators'
import { AppConfig } from './../../config/app.config';
import { AuthService } from './../../services/auth.services';
import { UserService } from './services/user.services';

@Component({
  selector: 'changepassword',
  templateUrl: './html/changepassword.html',
  providers:[
    UserService
  ]
})

export class ChangepasswordComponent {    

  constructor(
    private toaster: ToasterService,
    private auth: AuthService, 
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private formBuilder: FormBuilder,
    private config: AppConfig,
    private user: UserService
  ) {
    this.userData = this.formBuilder.group({
      password: ['', [Validators.required,Validators.pattern(this.config.pattern.PASSWORD)]],
      conf_password: ['', [Validators.required]]
    },{validator: matchingPasswords('password', 'conf_password')});
  }
  public userData: FormGroup;

  public loadstatus:any = true;
  public pchKeyStatus:any = false;
  save(data: any) {
    var self = this;
    console.log("Data value",data);
    if (data.value.password == data.value.conf_password) {
     self.activatedRoute.params.subscribe((param: any) => {
    self.user.changepassword(data.value,param['id']).subscribe(function (result) {
      var rs = result.json();
      if (rs.status == 200) {
        self.toaster.pop('success', rs.message);
         self.router.navigate(['login']);
      } else {
        self.toaster.pop('error', rs.message);
      }
    });
      });
       } else {
      self.toaster.pop('error', 'Password and confirm password is not identical!');
    }
  }

  ngOnInit() {    
    var self = this;
    self.activatedRoute.params.subscribe((param: any) => {
      if(param['id'] != ''){
        self.user.verifypch({'key':param['id']}).subscribe(function(res:any){
          self.loadstatus = false;
          let body = res.json();
          if(body.status == 200){
            self.pchKeyStatus = true;            
          }else{
             self.loadstatus = false;
          }
        });
      }else{
        self.loadstatus = false;
        
      }
    });
  }
}