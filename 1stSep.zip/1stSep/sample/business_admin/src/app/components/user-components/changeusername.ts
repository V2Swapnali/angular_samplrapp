import { Component } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { ToasterService } from 'angular2-toaster';
import { AppConfig } from './../../config/app.config';
import { AuthService } from './../../services/auth.services';
import { UserService } from './services/user.services';

@Component({
  selector: 'changeusername',
  templateUrl: './html/changeusername.html',
  providers:[
    UserService
  ]
})

export class ChangeusernameComponent {    

  constructor(
    private toaster: ToasterService,
    private auth: AuthService, 
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private formBuilder: FormBuilder,
    private config: AppConfig,
    private user: UserService
  ) {
    this.userData = this.formBuilder.group({
           user_name: ['', [Validators.required]]
    });
  }
  public userData: FormGroup;

  public loadstatus:any = true;
  public uchKeyStatus:any = false;
  save(data: any) {
    var self = this;
     self.activatedRoute.params.subscribe((param: any) => {
    self.user.changeusername(data.value,param['id']).subscribe(function (result) {
      var rs = result.json();
      if (rs.status == 200) {
        self.toaster.pop('success', rs.message);
         self.router.navigate(['login']);
      } else {
        self.toaster.pop('error', rs.message);
      }
    });
      });
  }

  ngOnInit() {    
    var self = this;
    self.activatedRoute.params.subscribe((param: any) => {
      if(param['id'] != ''){
        self.user.verifyuch({'key':param['id']}).subscribe(function(res:any){
          self.loadstatus = false;
          let body = res.json();
          if(body.status == 200){
            self.uchKeyStatus = true;            
          }else{
             self.loadstatus = false;
          }
        });
      }else{
        self.loadstatus = false;
        
      }
    });
  }
}