import { Component } from '@angular/core';
import { UserService } from './services/user.services';
declare var jQuery:any;
@Component({
  selector: 'login',
  templateUrl: './html/dashboard.component.html',
  providers:[
    UserService
  ]
})
export class DashboardComponent {

    constructor(
        private userservice: UserService
    ) {}

    public verificationStatus:any = false;

    ngOnInit() {    
        var self = this;    
        self.userservice.getAccountStatus().subscribe(function(res){
            let body = res.json();
            if(body.status != 200){
                self.verificationStatus = true;
            }
        });
    }

    ngAfterViewInit(): void {
        jQuery('.animate-panel').animatePanel();

        // Function for collapse hpanel
        jQuery('.showhide').on('click', function (event:any) { 
            event.preventDefault();
            var hpanel = jQuery(this).closest('div.hpanel');
            var icon = jQuery(this).find('i:first');
            var body = hpanel.find('div.panel-body');
            var footer = hpanel.find('div.panel-footer');
            body.slideToggle(300);
            footer.slideToggle(200);

            // Toggle icon from up to down
            icon.toggleClass('fa-chevron-up').toggleClass('fa-chevron-down');
            hpanel.toggleClass('').toggleClass('panel-collapse');
            setTimeout(function () {
                hpanel.resize();
                hpanel.find('[id^=map-]').resize();
            }, 50);
        });

        // Function for close hpanel
        jQuery('.closebox').on('click', function (event:any) { 
            event.preventDefault();
            var hpanel = jQuery(this).closest('div.hpanel');
            hpanel.remove();
            if(jQuery('body').hasClass('fullscreen-panel-mode')) { jQuery('body').removeClass('fullscreen-panel-mode');}
        });
    }

 }