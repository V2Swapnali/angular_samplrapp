import { Component } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { ToasterService } from 'angular2-toaster';
import { AppConfig } from './../../config/app.config';
import { AuthService } from './../../services/auth.services';
import { UserService } from './services/user.services';

@Component({
  selector: 'forgotusername',
  templateUrl: './html/forgotusername.html',
  providers:[
    UserService
  ]
})

export class ForgotusernameComponent {    

  constructor(
    private toaster: ToasterService,
    private auth: AuthService, 
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private formBuilder: FormBuilder,
    private config: AppConfig,
    private user: UserService
  ) {
    this.userData = this.formBuilder.group({
           email: ['', [Validators.required, Validators.pattern(this.config.pattern.EMAIL)]],
    });
  }
  public userData: FormGroup;

  public loadstatus:any = true;
  public activationKeyStatus:any = false;
  save(data: any) {
    var self = this;
    self.user.forgotusername(data.value).subscribe(function (result) {
      var rs = result.json();
      if (rs.status == 200) {
        self.toaster.pop('success', rs.message);
      } else {
        self.toaster.pop('error', rs.message);
      }
    });
  }

  ngOnInit() {    
    var self = this;
    self.activatedRoute.params.subscribe((param: any) => {
      if(param['id'] != ''){
        self.user.checkActKey({'key':param['id']}).subscribe(function(res:any){
          self.loadstatus = false;
          let body = res.json();
          if(body.status == 200){
            self.activationKeyStatus = true;            
          }
        });
      }else{
        self.loadstatus = false;
      }
    });
  }
}