import { Component } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { ToasterService } from 'angular2-toaster';
import { AuthService } from './../../services/auth.services';
import { AppConfig } from './../../config/app.config';

@Component({
  selector: 'login',
  templateUrl: './html/login.component.html'
})

export class LoginComponent {

  constructor(
    private toaster: ToasterService,
    private auth: AuthService,
    private router: Router,
    private config: AppConfig,
    private formBuilder: FormBuilder
  ) { }

  public userlogin: FormGroup;

  login(user: any) {
    var self = this;
    self.auth.login(user.value).subscribe(function (res) {
      if (res) {
        self.router.navigate(['dashboard']);
      } else {
        self.toaster.pop('error', 'Invalid user name or password!');
      }
    });
  }

  ngOnInit() {
    var self = this;
    self.userlogin = this.formBuilder.group({
      user_name: ['', [Validators.required]],
      password: ['', [Validators.required]],
      rememberme: [true]
    });
  }
}