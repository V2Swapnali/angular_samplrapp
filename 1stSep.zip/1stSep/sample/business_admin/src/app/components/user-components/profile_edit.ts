import { Component } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { ToasterService } from 'angular2-toaster';
import { WebStorage } from './../../utility/web.storage';
import { AppConfig } from './../../config/app.config';
import { UserService } from './services/user.services';


@Component({
  selector: 'profile-edit',
  templateUrl: './html/profile_edit.html',
  providers: [
    UserService
  ]
})
export class ProfileeditComponent {

  constructor(
    private toaster: ToasterService,
    private user: UserService,
    private router: Router,
    private config: AppConfig,
    private activatedRoute: ActivatedRoute,
    private formBuilder: FormBuilder,
    private storage: WebStorage
  ) {
    this.userData = this.formBuilder.group({
      f_name: ['', [Validators.required]],
      l_name: ['', [Validators.required]],
      user_name: ['', [Validators.required ,Validators.pattern(this.config.pattern.USERNAME)]],
      email: ['', [Validators.required, Validators.pattern(this.config.pattern.EMAIL)]],
      phone: ['', [Validators.required]]
    });
  }

  public userData: FormGroup;

  save(data: any) {
    var self = this;
    self.user.updateProfile(data.value).subscribe(function (result) {
      var rs = result.json();
      if (rs.status == 200) {
        self.toaster.pop('success', rs.message);
        //self.router.navigate(['dashboard']);
      } else {
        self.toaster.pop('error', rs.message);
      }
    });
  }

  ngOnInit() {
    var self = this;
    let user = this.storage.get('businessadminUser');
    self.user.getOne(user.id).subscribe(function (result) {
      var rs = result.json();
      if (rs.status == 200) {
        self.userData.patchValue(rs.data);
      } else {
        self.toaster.pop('error', rs.message);
        self.router.navigate(['dashboard']);
      }
    });
  }
}