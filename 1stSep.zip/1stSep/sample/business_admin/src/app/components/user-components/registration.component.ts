import { Component } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { LocalStorageService } from 'ng2-webstorage';
import { ToasterService } from 'angular2-toaster';
import { matchingPasswords } from './../../shared/validators'
import { AppConfig } from './../../config/app.config';
import { AuthService } from './../../services/auth.services';
import { UserService } from './services/user.services';

@Component({
  selector: 'registration',
  templateUrl: './html/registration.component.html',
  providers: [
    UserService
  ]
})

export class RegistrationComponent {

  constructor(
    private localStorageService: LocalStorageService,
    private toaster: ToasterService,
    private auth: AuthService,
    private router: Router,
    private config: AppConfig,
    private formBuilder: FormBuilder,
    private userservice: UserService
  ) { }

  public userRegistration: FormGroup;

  register(user: any) {
    var self = this;
    if (user.value.password == user.value.conf_password) {
      self.userservice.register(user.value).subscribe(function (res) {
        let body = res.json();
        if (body.status == 200) {
          self.localStorageService.store('businessadminAuthToken', body.data.token);
          self.localStorageService.store('businessadminUser', body.data.user);
          self.toaster.pop('success', 'You have registered fuccessfully. Email verification mail is sent to your email id.');
          self.router.navigate(['dashboard']);
        } else {
          self.toaster.pop('error', body.message);
        }
      });
    } else {
      self.toaster.pop('error', 'Password and confirm password is not identical!');
    }
  }

  ngOnInit() {
    var self = this;
    self.userRegistration = this.formBuilder.group({
      email: ['', [Validators.required, Validators.pattern(self.config.pattern.EMAIL)]],
      user_name: ['', [Validators.required, Validators.pattern(self.config.pattern.USERNAME)]],
      password: ['', [Validators.required, Validators.pattern(self.config.pattern.PASSWORD)]],
      conf_password: ['', [Validators.required]],
      terms: [false, [Validators.pattern('true')]]
    }, { validator: matchingPasswords('password', 'conf_password') });
  }
}