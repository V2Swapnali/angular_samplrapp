import { Injectable } from '@angular/core';
import { LocalStorageService, SessionStorageService } from 'ng2-webstorage';
import { Observable } from 'rxjs/Observable';

import { HttpClient } from './../../../utility/http.client';


@Injectable()
export class UserService {

  constructor(
    private http: HttpClient
  ) { }

  register(user: any): Observable<any> {
    return this.http.post('/user/bu/registration', user);
  }

  checkActKey(data: any): Observable<any> {
    return this.http.get('/user/bu/verify_account', data);
  }
  verifyuch(data: any): Observable<any> {
    return this.http.get('/user/bu/verifyuch', data);
  }

  getAccountStatus(): Observable<any> {
    return this.http.get('/user/bu/verificationstatus', {});
  }

  getOne(id: any): Observable<any> {
    return this.http.get('/user/businessuser/get', { id: id });
  }

  updateProfile(user: any): Observable<any> {
    return this.http.post('/user/bu/profileupdate', user);
  }

  updatePass(data: any): Observable<any> {
    return this.http.post('/user/changepwd', data);
  }
  forgotusername(user: any): Observable<any> {
    return this.http.post('/user/bu/forget_username', user);
  }
  changeusername(user: any, id: any): Observable<any> {
    return this.http.post('/user/bu/change_username/edit?id=' + id, user);
  }
  account_security(data: any): Observable<any> {
    return this.http.post('/user/bu/account_security', data);
  }
  forgotpassword(user: any): Observable<any> {
    return this.http.post('/user/bu/forget_password', user);
  }
  changepassword(user: any, id: any): Observable<any> {
    return this.http.post('/user/bu/change_password/edit?id=' + id, user);
  }
  verifypch(data: any): Observable<any> {
    return this.http.get('/user/bu/verifypch', data);
  }
}

