import { Component } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { ToasterService } from 'angular2-toaster';
import { matchingPasswords } from './../../shared/validators'
import { AppConfig } from './../../config/app.config';
import { UserService } from './services/user.services';


@Component({
  selector: 'update-pass',
  templateUrl: './html/update_password.html',
  providers: [
    UserService
  ]
})
export class UpdatePasswordComponent {

  constructor(
    private toaster: ToasterService,
    private user: UserService,
    private router: Router,
    private config: AppConfig,
    private activatedRoute: ActivatedRoute,
    private formBuilder: FormBuilder
  ) {
    this.passwordData = this.formBuilder.group({
      password: ['', [Validators.required]],
      new_password: ['', [Validators.required, Validators.pattern(this.config.pattern.PASSWORD)]],
      conf_password: ['', [Validators.required]]
    },{validator: matchingPasswords('new_password', 'conf_password')});
  }

  public passwordData: FormGroup;

  save(data: any) {
    var self = this;
    if (data.value.new_password == data.value.conf_password) {
      self.user.updatePass(data.value).subscribe(function (result) {
        var rs = result.json();
        if (rs.status == 200) {
          self.toaster.pop('success', rs.message);
          self.router.navigate(['dashboard']);
        } else {
          self.toaster.pop('error', rs.message);
        }
      });
    } else {
      self.toaster.pop('error', 'Password and confirm password is not identical!');
    }
  }

  ngOnInit() { }
}