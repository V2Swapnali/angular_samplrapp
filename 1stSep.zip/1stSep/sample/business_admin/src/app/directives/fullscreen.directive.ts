    import { Directive, ElementRef, HostListener, Input } from '@angular/core';

    @Directive({ selector: '[fullscreen]' })

    export class FullscreenDirective {
        constructor(private el: ElementRef) {           
           let w = window,
            d = document,
            e = d.documentElement,
            g = d.getElementsByTagName('body')[0],
            x = w.innerWidth || e.clientWidth || g.clientWidth,
            y = w.innerHeight|| e.clientHeight|| g.clientHeight;
            //console.log(x + ' × ' + y);
            el.nativeElement.style['min-height'] = (y-50)+'px';
        }
    }