import { NgModule }      from '@angular/core';
import { CommonModule } from '@angular/common'; 
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule }    from '@angular/forms';
import { HttpModule }    from '@angular/http';
import { Ng2Webstorage } from 'ng2-webstorage';
import { Router, ActivatedRoute, Params, NavigationStart } from '@angular/router';
import { ToasterModule } from 'angular2-toaster';
import { DatepickerModule, PaginationModule, ModalModule } from 'ng2-bootstrap';
import { 
  DialogModule,
  AutoCompleteModule, 
  CheckboxModule, 
  SpinnerModule, 
  ConfirmDialogModule, 
  ConfirmationService,
  InputSwitchModule,
  CalendarModule,
  ToggleButtonModule,
  EditorModule,
  SharedModule 
  
} from 'primeng/primeng';

import { SelectModule } from 'angular2-select';

import { HttpClient } from './../utility/http.client';
import { WebStorage } from './../utility/web.storage';
import { TmpStorage } from './../utility/temp.storage';

import { routing } from './../routs/app.routs';
import { AuthBlocker } from './../routs/auth.blocker';
import { AppConfig } from './../config/app.config';

import { FullscreenDirective } from './../directives/fullscreen.directive';

import { AuthService } from './../services/auth.services';
import { AppComponent }   from './../components/app-components/app.component';
import { HeaderComponent } from './../components/nav-components/header.component';
import { SidebarComponent } from './../components/nav-components/sidebar.component';
import { FooterComponent } from './../components/nav-components/footer.component';

import { Err404Component } from './../components/error-components/err404';

import { LoginComponent }   from './../components/user-components/login.component';
import { RegistrationComponent }   from './../components/user-components/registration.component';
import { AccountactivationComponent }   from './../components/user-components/accountactivation.component';
import { DashboardComponent } from './../components/user-components/dashboard.component';

import { ProdComponent } from './../components/product-components/prod';
import { ProdlistComponent } from './../components/product-components/prod_list';
import { ProdaddnewComponent } from './../components/product-components/prod_add_n';
import { ProdaddexComponent } from './../components/product-components/prod_add_ex';
import { ProdeditComponent } from './../components/product-components/prod_edit';

import { RoleComponent } from './../components/roles/role';
import { RolelistComponent } from './../components/roles/role_list';
import { RoleaddComponent } from './../components/roles/role_add';
import { RoleeditComponent } from './../components/roles/role_edit';

import { StaffComponent } from './../components/staff/staff';
import { StafflistComponent } from './../components/staff/staff_list';
import { StaffaddComponent } from './../components/staff/staff_add';
import { StaffeditComponent } from './../components/staff/staff_edit';

import { ProfileeditComponent } from './../components/user-components/profile_edit';
import { UpdatePasswordComponent } from './../components/user-components/update_password';

import { CustomerComponent } from './../components/customer/customer';
import { CustomerlistComponent } from './../components/customer/customer_list';
import { CustomeraddComponent } from './../components/customer/customer_add';
import { CustomereditComponent } from './../components/customer/customer_edit';
import { CustomerdetailComponent } from './../components/customer/customer_detail';

import { VendorComponent } from './../components/vendor/vendor';
import { VendorlistComponent } from './../components/vendor/vendor_list';
import { VendoraddComponent } from './../components/vendor/vendor_add';
import { VendoreditComponent } from './../components/vendor/vendor_edit';
import { VendordetailComponent} from './../components/vendor/vendor_detail';

import { InvoiceComponent } from './../components/invoice/invoice';
import { InvoicelistComponent } from './../components/invoice/invoice_list';
import { InvoiceaddComponent } from './../components/invoice/invoice_add';
import { InvoiceeditComponent } from './../components/invoice/invoice_edit';

import { OrderComponent } from './../components/order/order';
import { OrderlistComponent } from './../components/order/order_list';
import { OrderaddComponent } from './../components/order/order_add';
import { OrdereditComponent } from './../components/order/order_edit';

import { ForgotusernameComponent } from './../components/user-components/forgotusername';
import { ChangeusernameComponent } from './../components/user-components/changeusername';


import { CompanyComponent } from './../components/company/company';
import { CompanyDetailsComponent } from './../components/company/company_details';
import { CompanyLocationlistComponent } from './../components/company/company_location_list';
import { CompanyLocationaddComponent } from './../components/company/company_location_add';
import { CompanyLocationeditComponent } from './../components/company/company_location_edit';

import { SettingsComponent } from './../components/settings/settings';
import { SettingsCustomerComponent } from './../components/settings/settings_customer';

import { AccountSecurityComponent } from './../components/user-components/account_security';

import { ForgotpasswordComponent } from './../components/user-components/forgotpassword';
import { ChangepasswordComponent } from './../components/user-components/changepassword';

@NgModule({
  imports: [ 
    BrowserModule, 
    FormsModule, 
    ReactiveFormsModule,
    HttpModule,
    routing,
    Ng2Webstorage,
    ToasterModule, 
    SelectModule,
    DialogModule,
    CheckboxModule,
    SpinnerModule,
    ConfirmDialogModule,
    InputSwitchModule,
    CalendarModule,
    ToggleButtonModule,
    AutoCompleteModule,
    EditorModule,
    SharedModule,
    PaginationModule.forRoot(),
    ModalModule.forRoot(),
    DatepickerModule.forRoot()
  ],
  declarations: [ 
    AppComponent,
    HeaderComponent,
    SidebarComponent,
    FooterComponent,
    Err404Component,    
    FullscreenDirective,
    LoginComponent,  
    RegistrationComponent, 
    AccountactivationComponent, 
    DashboardComponent,
    ProdComponent,
    ProdlistComponent,
    ProdaddnewComponent,
    ProdaddexComponent,
    ProdeditComponent,
    RoleComponent,
    RolelistComponent,
    RoleaddComponent,
    RoleeditComponent,
    StaffComponent,
    StafflistComponent,
    StaffaddComponent,
    StaffeditComponent,
    ProfileeditComponent,
    UpdatePasswordComponent,    
    CustomerComponent,
    CustomerlistComponent,
    CustomeraddComponent,
    CustomereditComponent,
    CustomerdetailComponent,
    VendorComponent,
    VendorlistComponent,
    VendoraddComponent,
    VendoreditComponent,
    VendordetailComponent,
    InvoiceComponent,
    InvoicelistComponent,
    InvoiceaddComponent,
    InvoiceeditComponent,
    OrderComponent,
    OrderlistComponent,
    OrderaddComponent,
    OrdereditComponent,
    ForgotusernameComponent,
    ChangeusernameComponent,
    CompanyComponent,
    CompanyDetailsComponent,
    CompanyLocationlistComponent,
    CompanyLocationaddComponent,
    CompanyLocationeditComponent,
    AccountSecurityComponent,
    ForgotpasswordComponent,
    ChangepasswordComponent,
    SettingsComponent,
    SettingsCustomerComponent
  ],
  providers: [
    HttpClient,
    AuthService,
    AppConfig,
    AuthBlocker,
    WebStorage,
    TmpStorage,
    ConfirmationService
  ],
  bootstrap:    [ AppComponent ]
})

export class AppModule {}