import { ModuleWithProviders }  from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AuthBlocker } from './auth.blocker';

import { Err404Component } from './../components/error-components/err404';

import { LoginComponent } from './../components/user-components/login.component';
import { RegistrationComponent } from './../components/user-components/registration.component';
import { AccountactivationComponent } from './../components/user-components/accountactivation.component';
import { DashboardComponent } from './../components/user-components/dashboard.component';

import { ProdComponent } from './../components/product-components/prod';
import { ProdlistComponent } from './../components/product-components/prod_list';
import { ProdaddnewComponent } from './../components/product-components/prod_add_n';
import { ProdaddexComponent } from './../components/product-components/prod_add_ex';
import { ProdeditComponent } from './../components/product-components/prod_edit';

import { RoleComponent } from './../components/roles/role';
import { RolelistComponent } from './../components/roles/role_list';
import { RoleaddComponent } from './../components/roles/role_add';
import { RoleeditComponent } from './../components/roles/role_edit';

import { StaffComponent } from './../components/staff/staff';
import { StafflistComponent } from './../components/staff/staff_list';
import { StaffaddComponent } from './../components/staff/staff_add';
import { StaffeditComponent } from './../components/staff/staff_edit';

import { ProfileeditComponent } from './../components/user-components/profile_edit';
import { UpdatePasswordComponent } from './../components/user-components/update_password';

import { CustomerComponent } from './../components/customer/customer';
import { CustomerlistComponent } from './../components/customer/customer_list';
import { CustomeraddComponent } from './../components/customer/customer_add';
import { CustomereditComponent } from './../components/customer/customer_edit';
import { CustomerdetailComponent } from './../components/customer/customer_detail';


import { VendorComponent } from './../components/vendor/vendor';
import { VendorlistComponent } from './../components/vendor/vendor_list';
import { VendoraddComponent } from './../components/vendor/vendor_add';
import { VendoreditComponent } from './../components/vendor/vendor_edit';
import { VendordetailComponent } from './../components/vendor/vendor_detail';

import { InvoiceComponent } from './../components/invoice/invoice';
import { InvoicelistComponent } from './../components/invoice/invoice_list';
import { InvoiceaddComponent } from './../components/invoice/invoice_add';
import { InvoiceeditComponent } from './../components/invoice/invoice_edit';

import { OrderComponent } from './../components/order/order';
import { OrderlistComponent } from './../components/order/order_list';
import { OrderaddComponent } from './../components/order/order_add';
import { OrdereditComponent } from './../components/order/order_edit';

import { ForgotusernameComponent } from './../components/user-components/forgotusername';
import { ChangeusernameComponent } from './../components/user-components/changeusername';

import { CompanyComponent } from './../components/company/company';
import { CompanyDetailsComponent } from './../components/company/company_details';
import { CompanyLocationlistComponent } from './../components/company/company_location_list';
import { CompanyLocationaddComponent } from './../components/company/company_location_add';
import { CompanyLocationeditComponent } from './../components/company/company_location_edit';

import { SettingsComponent } from './../components/settings/settings';
import { SettingsCustomerComponent } from './../components/settings/settings_customer';

import { AccountSecurityComponent } from './../components/user-components/account_security';

import { ForgotpasswordComponent } from './../components/user-components/forgotpassword';
import { ChangepasswordComponent } from './../components/user-components/changepassword';

const appRoutes: Routes = [
    {
        path: 'login',
        component: LoginComponent,
        resolve: { auth: AuthBlocker }
    },
    {
        path: 'registration',
        component: RegistrationComponent,
        resolve: { auth: AuthBlocker }
    },
    {
        path: 'activateaccount/:id',
        component: AccountactivationComponent
    },
    {
        path: 'forgotusername',
        component: ForgotusernameComponent
    },
    {
        path: 'changeusername/:id',
        component: ChangeusernameComponent
    },
    {
        path: 'forgotpassword',
        component: ForgotpasswordComponent
    },
     {
        path: 'changepassword/:id',
        component: ChangepasswordComponent
    },
    {
        path: 'dashboard',
        component: DashboardComponent,
        resolve: { auth: AuthBlocker }
    },
    {
        path: 'updateprofile',
        component: ProfileeditComponent,
        resolve: { auth: AuthBlocker }
    },
    {
        path: 'account_security',
        component: AccountSecurityComponent,
        resolve: { auth: AuthBlocker }
    },
    {
        path: 'updatepassword',
        component: UpdatePasswordComponent,
        resolve: { auth: AuthBlocker }
    },
    {
        path: 'products',
        component: ProdComponent,
        resolve: { auth: AuthBlocker },
        children: [
            {
                path: '',
                component: ProdlistComponent,
                resolve: { auth: AuthBlocker }
            },
            {
                path: 'add',
                component: ProdaddnewComponent,
                resolve: { auth: AuthBlocker }
            },
            {
                path: 'add/:id',
                component: ProdaddexComponent,
                resolve: { auth: AuthBlocker }
            },
            {
                path: 'edit/:id',
                component: ProdeditComponent,
                resolve: { auth: AuthBlocker }
            }
        ]
    },
    {
        path: 'roles',
        component: RoleComponent,
        resolve: { auth: AuthBlocker },
        children: [
            {
                path: '',
                component: RolelistComponent,
                resolve: { auth: AuthBlocker }
            },
            {
                path: 'add',
                component: RoleaddComponent,
                resolve: { auth: AuthBlocker }
            },
            {
                path: 'edit/:id',
                component: RoleeditComponent,
                resolve: { auth: AuthBlocker }
            }
        ]
    },
    {
        path: 'staff',
        component: StaffComponent,
        resolve: { auth: AuthBlocker },
        children: [
            {
                path: '',
                component: StafflistComponent,
                resolve: { auth: AuthBlocker }
            },
            {
                path: 'add',
                component: StaffaddComponent,
                resolve: { auth: AuthBlocker }
            },
            {
                path: 'edit/:id',
                component: StaffeditComponent,
                resolve: { auth: AuthBlocker }
            }
        ]
    },
    {
        path: 'customer',
        component: CustomerComponent,
        resolve: { auth: AuthBlocker },
        children: [
            {
                path: '',
                component: CustomerlistComponent,
                resolve: { auth: AuthBlocker }
            },
            {
                path: 'add',
                component: CustomeraddComponent,
                resolve: { auth: AuthBlocker }
            },
            {
                path: 'edit/:id',
                component: CustomereditComponent,
                resolve: { auth: AuthBlocker }
            },
            {
                path: 'detail/:id',
                component: CustomerdetailComponent,
                resolve: { auth: AuthBlocker }
            }
        ]
    },
    {
        path: 'vendor',
        component: VendorComponent,
        resolve: { auth: AuthBlocker },
        children: [
            {
                path: '',
                component: VendorlistComponent,
                resolve: { auth: AuthBlocker }
            },
            {
                path: 'add',
                component: VendoraddComponent,
                resolve: { auth: AuthBlocker }
            },
            {
                path: 'edit/:id',
                component: VendoreditComponent,
                resolve: { auth: AuthBlocker }
            },
            {
                path: 'detail/:id',
                component: VendordetailComponent,
                resolve: { auth: AuthBlocker }
            }
        ]
    },
    {
        path: 'invoice',
        component: InvoiceComponent,
        resolve: { auth: AuthBlocker },
        children: [
            {
                path: '',
                component: InvoicelistComponent,
                resolve: { auth: AuthBlocker }
            },
            {
                path: 'add',
                component: InvoiceaddComponent,
                resolve: { auth: AuthBlocker }
            },
            {
                path: 'edit/:id',
                component: InvoiceeditComponent,
                resolve: { auth: AuthBlocker }
            }
        ]
    },
    {
        path: 'orders',
        component: OrderComponent,
        resolve: { auth: AuthBlocker },
        children: [
            {
                path: '',
                component: OrderlistComponent,
                resolve: { auth: AuthBlocker }
            },
            {
                path: 'add',
                component: OrderaddComponent,
                resolve: { auth: AuthBlocker }
            },
            {
                path: 'edit/:id',
                component: OrdereditComponent,
                resolve: { auth: AuthBlocker }
            }
        ]
    },
    {
        path: 'company',
        component: CompanyComponent,
        resolve: { auth: AuthBlocker },
        children: [
            {
                path: '',
                component: CompanyDetailsComponent,
                resolve: { auth: AuthBlocker }
            },
            {
                path: 'details',
                component: CompanyDetailsComponent,
                resolve: { auth: AuthBlocker }
            },
            {
                path: 'location',
                component: CompanyLocationlistComponent,
                resolve: { auth: AuthBlocker }
            },
            {
                path: 'locationadd',
                component: CompanyLocationaddComponent,
                resolve: { auth: AuthBlocker }
            },
            {
                path: 'locationedit/:id',
                component: CompanyLocationeditComponent,
                resolve: { auth: AuthBlocker }
            }
      ]
    },
    {
        path: 'settings',
        component: SettingsComponent,
        resolve: { auth: AuthBlocker },
        children: [
            {
                path: '',
                component: SettingsCustomerComponent,
                resolve: { auth: AuthBlocker }
            },
            {
                path: 'customer',
                component: SettingsCustomerComponent,
                resolve: { auth: AuthBlocker }
            }
      ]
    },
    {
        path: '404',
        component: Err404Component
    },
    {
        path: '',
        redirectTo: '/dashboard',
        pathMatch: 'full'
    },
    {
        path: '**',
        redirectTo: '/404'
    }
];

export const routing: ModuleWithProviders = RouterModule.forRoot(appRoutes);