import { Injectable } from '@angular/core';
import {LocalStorageService, SessionStorageService} from 'ng2-webstorage';
import { Observable } from 'rxjs/Observable';

import { HttpClient } from './../utility/http.client';


@Injectable()
export class AuthService {
  isLoggedIn: boolean = false;
  redirectUrl: string; 

  constructor(
    private http: HttpClient,
    private localStorageService: LocalStorageService,
    private sessionStorageService: SessionStorageService
  ) {}

  checkLogin(): Observable<boolean> {
    let self = this;
    return this.http.get('/user/checklogin', {}).map(function(res: any) {
        let body = res.json();
        if(body.status == 203){
            self.isLoggedIn = false;
            return false;     
        }else{
            self.isLoggedIn = true;
            return true;
        }            
    }); 
  }

  login(data:any): Observable<any> {
    let self = this;
    return this.http.post('/user/bu/login', data).map(function(res: any) {
        let body = res.json();
        if(body.status == 201){
            self.isLoggedIn = false;
            return false;
        }else{
            self.isLoggedIn = true;
            if(data.rememberme){
                self.localStorageService.store('businessadminAuthToken', body.data.token);                
            }else{
                self.sessionStorageService.store('businessadminAuthToken', body.data.token);
            }
            self.localStorageService.store('businessadminUser', body.data.user);
            return true;
        }            
    });
  }

  logout(): Observable<any> {    
    this.localStorageService.clear('businessadminAuthToken');
    this.localStorageService.clear('businessadminUser');
    this.sessionStorageService.clear('businessadminAuthToken');
    this.sessionStorageService.clear('businessadminUser');
    this.isLoggedIn = false;
    return Observable.of({status: true});;
  }

}