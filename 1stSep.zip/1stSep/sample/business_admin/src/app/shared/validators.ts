import { Component, AfterViewInit, ViewChild, ViewChildren } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
/*
  Custom validators to use everywhere.
*/
// FORM GROUP VALIDATORS
export function matchingPasswords(passwordKey: string, cpasswordKey: string) {
  return (group: FormGroup): {[key: string]: any} => {
           
    let password = group.controls[passwordKey];
    let cpassword = group.controls[cpasswordKey];
    
    if (password.value !== cpassword.value) {
      return {
        mismatchedPasswords: true
      };
    }
  }
}