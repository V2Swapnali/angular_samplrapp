// Angular
import '@angular/platform-browser';
import '@angular/platform-browser-dynamic';
import '@angular/core';
import '@angular/common';
import '@angular/http';
import '@angular/router';
// RxJS
import 'rxjs';
import 'font-awesome-webpack';

import 'primeng/resources/primeng.min.css';
import 'primeng/resources/themes/bootstrap/theme.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'angular2-toaster/toaster.css';
import 'quill/dist/quill.core.css';
import 'quill/dist/quill.snow.css';
import '../public/fonts/pe-icon-7-stroke/css/pe-icon-7-stroke.css';
import '../public/fonts/pe-icon-7-stroke/css/helper.css';
import '../public/styles/style.css';
import '../public/styles/style-developre.css';

import '../public/vendor/jquery/dist/jquery.min.js';
import 'bootstrap/dist/js/bootstrap.min';
import '../public/vendor/metisMenu/dist/metisMenu.min.js';
import '../public/vendor/iCheck/icheck.min.js';
import '../public/scripts/animate_panel.js';
import 'quill/dist/quill.js';


