// grab the packages we need
var express = require('express');
var methodOverride = require('method-override')
var bodyParser = require('body-parser');
var path = require('path');
var fs = require('fs');
const nodeCache = require("node-cache");

var app = express();
var port = process.env.PORT || 5002;

// rootRequired function
global.__dbConf = {};
global.__rootRequire = function (relpath) {
  return require(path.join(__dirname, relpath));
};

app.use(bodyParser.json()); // support json encoded bodies
app.use(bodyParser.urlencoded({ extended: true })); // support encoded bodies
app.use(methodOverride());

// view engine setup
app.engine('html', function (path, opt, fn) {
  fs.readFile(path, 'utf-8', function (error, str) {
    if (error) return str;
    return fn(null, str);
  });
});
app.set('view engine', 'html');

app.use(function (req, res, next) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, OPTIONS, DELETE');
  res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type, Authorization, Origin, Host, Accept, Origin, Referer, User-Agent');
  next();
});

//app.set('views', path.join(__dirname, 'public'));
app.use('/assets', express.static(path.join(__dirname, 'assets')));



// ********************** Get DB config ****************
app.use(function (req, res, next) {
  req.config = __rootRequire('app/config/config');
  var whiteListedIp = ['::ffff:127.0.0.1', '::ffff:49.248.148.242', '::ffff:45.34.67.58', '::ffff:45.34.2.19'];
  var ip = req.headers['x-forwarded-for'] || req.connection.remoteAddress || req.socket.remoteAddress || req.connection.socket.remoteAddress;
  console.log('requested IP: ', ip);
  if (whiteListedIp.lastIndexOf(ip) >= 0) {
    var bookshelf = __rootRequire('app/config/bookshelf');
    bookshelf.knex.select().table('permissions').then(function (rows) {
      req.modulesArray = rows.reduce(function (r, a) {
        r[a.module_path] = a.id;
        return r;
      }, {});
      next();
    });
  } else {
    res.json({
      status: req.config.statusCode.error,
      message: "your ip address is not authized to access the API!"
    });
  }

  /*var request = require('request');  
  request.post({url:'http://localhost:5002/api/v1/gd', form: {type:'dblocal',pwd: req.config.authPass}}, function(err,httpResponse,body){
    if(!err){
      global.__dbConf = body.data;
      next();
    }else{
      res.status(500).send('DB connection failed!');
    }
  }); */
})

// Router Area
app.use('/api/v1', require('./app/api/v1/routes')(express));

app.use('/', function (req, res, next) {
  res.status(200).send('Welcome to api services.');
})

app.use(logErrors);
app.use(clientErrorHandler);
app.use(errorHandler);

function logErrors(err, req, res, next) {
  console.error(err.stack)
  next(err)
}

function clientErrorHandler(err, req, res, next) {
  if (req.xhr) {
    res.status(500).send({ error: 'Something failed!' })
  } else {
    next(err)
  }
}

function errorHandler(err, req, res, next) {
  if (res.headersSent) {
    return next(err)
  }
  res.status(500)
  res.render('error', { error: err })
}

// start the server
app.listen(port);
console.log('Server started! At http://localhost:' + port);