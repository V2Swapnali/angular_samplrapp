var crypto = __rootRequire('app/utils/crypto');

module.exports = function (router) {

    // ========================= User Block =============================
    var companyDetail = require('./controllers/companyDetail_ctrl')

    router.get('/companyDetail/get', crypto.ensureAuthorized, companyDetail.companyDetail_get)
    router.post('/companyDetail/add', crypto.ensureAuthorized, companyDetail.companyDetail_add)


    // ========================= User Block =============================

    return router;
}
