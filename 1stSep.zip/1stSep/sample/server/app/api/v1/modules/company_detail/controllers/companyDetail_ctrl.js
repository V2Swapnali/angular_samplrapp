var jwt = require('jsonwebtoken');
var Joi = require('joi');
var moment = require('moment');
var async = require('async');
var crypto = __rootRequire('app/utils/crypto');
var utils = __rootRequire('app/utils/common');
var companyDetailModel = require('./../models/companyDetail_model');
const uuidV4 = require('uuid/v4');
module.exports = {

    

    companyDetail_add: function (req, res, next) {
        var id = req.user.id;
        var Data = {
            "company": req.body.company,
            "logo": req.body.logo,
            "vat_number": req.body.vat_number,
            "type_business": req.body.type_business,
            "type_goods": req.body.type_goods,
            "category": req.body.category,
            "default_lang": req.body.default_lang,
            "timezone": req.body.timezone,
            // "default_email": req.body.default_email,
        };
        var schema = Joi.object().keys({
            "company": Joi.string().required(),
            "logo": Joi.string().required(),
            "vat_number": Joi.string().required(),
            "type_business": Joi.string().required(),
            "type_goods": Joi.string().required(),
            "category": Joi.string().required(),
            "default_lang": Joi.string().required(),
            "timezone": Joi.string().required(),
            // "default_email": Joi.string().email().required(),

        });
        Joi.validate(Data, schema, function (err, value) {
            if (err) {
                res.json({
                    status: req.config.statusCode.error,
                    error: err,
                    message: "Validation errors!"
                });
            } else {
                Data.business_id = req.user.id;
                Data.created = moment.utc().format('YYYY-MM-DD HH:mm:ss');
                new companyDetailModel().query(function (qb) {
                    qb.whereRaw("business_id = " + req.user.id);
                }).fetch().then(function (result) {
                console.log("result",result);
                    if (result) {
                        result.save(Data).then(function (result) {
                            if (!result) {
                                throw new Error("An error has occurred while processing your request. Try again.");
                            }
                            res.json({
                                status: req.config.statusCode.success,
                                data: result.toJSON(),
                                message: "Company detail updated successfully."
                            });
                        }).catch(function (err) {
                            res.json({
                                status: req.config.statusCode.error,
                                error: err,
                                message: "Company detail not updated"
                            });
                        });
                    } else {
                        new companyDetailModel(Data).save().then(function (result) {
                            if (!result) {
                                throw new Error("An error has occurred while processing your request. Try again.");
                            }
                            var data = result.toJSON();
                            res.json({
                                status: req.config.statusCode.success,
                                data: data,
                                message: "Company detail added successfully."
                            });
                        }).catch(function (err) {
                            res.json({
                                status: req.config.statusCode.error,
                                data: null,
                                message: err
                            });
                        });
                    }

                }).catch(function (err) {
                    console.log(err);
                    res.json({
                        status: req.config.statusCode.error,
                        message: 'Unable to get configuration!',
                        error: err
                    });
                });
            }
        });
    },


    companyDetail_get: function (req, res, next) {
        if (utils.notEmpty(req.user.id)) {
            new companyDetailModel().query(function (qb) {
                qb.whereRaw("business_id = " + req.user.id);
            }).fetch().then(function (result) {
                res.json({
                    status: req.config.statusCode.success,
                    data: result.toJSON(),
                    message: 'Company detail found successfully!'
                });
            }).catch(function (err) {
                console.log(err);
                res.json({
                    status: req.config.statusCode.error,
                    message: 'Unable to get configuration!',
                    error: err
                });
            });
        } else {
            res.json({
                status: req.config.statusCode.error,
                error: [],
                message: "Please provide id"
            });
        }
    },



}