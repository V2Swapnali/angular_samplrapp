var bookshelf = __rootRequire('app/config/bookshelf');
var CompanyDetails = bookshelf.Model.extend({
    tableName: 'company_details',
    idAttribute: 'id'
});

module.exports = bookshelf.model('CompanyDetails', CompanyDetails);