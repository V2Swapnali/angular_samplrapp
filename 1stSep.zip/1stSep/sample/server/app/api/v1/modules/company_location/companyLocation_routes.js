var crypto = __rootRequire('app/utils/crypto');

module.exports = function (router) {

    // ========================= User Block =============================
    var companyLocation = require('./controllers/companyLocation_ctrl')

    router.get('/companyLocation/get', crypto.ensureAuthorized, companyLocation.companyLocation_get)
    router.get('/companyLocation/list', crypto.ensureAuthorized, companyLocation.companyLocation_list)
    router.post('/companyLocation/add', crypto.ensureAuthorized, companyLocation.companyLocation_add)
    router.post('/companyLocation/edit', crypto.ensureAuthorized, companyLocation.companyLocation_edit)
    router.post('/companyLocation/delete', crypto.ensureAuthorized, companyLocation.companyLocation_delete)


    // ========================= User Block =============================

    return router;
}
