var jwt = require('jsonwebtoken');
var Joi = require('joi');
var moment = require('moment');
var async = require('async');
var utils = __rootRequire('app/utils/common');
var companyLocationModel = require('./../models/companyLocation_model');
module.exports = {


    companyLocation_list: function (req, res, next) {

        var page = req.query.page - 1 || 0;
        var limit = req.query.limit || 10;
        var offset = limit * page;

        var sort = 'created';
        var order = 'desc';

        var query = "is_deleted = 0 AND business_id = " + req.user.id;
        if (utils.notEmpty(req.query.name)) {
            query += " AND name LIKE '" + req.query.name + "%'";
        }

        if (utils.notEmpty(req.query.city)) {
            query += " AND city LIKE '" + req.query.city + "%'";
        }

     
        new companyLocationModel().query(function (qb) {
            qb.count('* as CNT');
            qb.whereRaw(query);
        }).fetch().then(function (result) {
            var cnt = result.toJSON().CNT;
            new companyLocationModel().query(function (qb) {
                qb.whereRaw(query);
                qb.orderBy(sort, order);
                qb.limit(limit).offset(offset);
            }).fetchAll({ columns: ['id', 'name',  'address', 'country', 'city', 'state', 'zip', 'business_id', 'created', 'phone', 'store_hours', 'type'] }).then(function (results) {
                res.json({
                    status: req.config.statusCode.success,
                    message: 'SUCCESS',
                    data: results.toJSON(),
                    count: cnt
                });
            }).catch(function (err) {
                res.json({
                    status: req.config.statusCode.error,
                    error: err,
                    message: "Something went wrong!!"
                });
            });
        }).catch(function (err) {
            res.json({
                status: req.config.statusCode.error,
                error: err,
                message: "Company not found"
            });
        });
    },

    companyLocation_add: function (req, res, next) {
        var Data = {
            "name": req.body.name,
            "address": req.body.address,
            "city": req.body.city,
            "state": req.body.state,
            "country": req.body.country,
            "zip": req.body.zip,
            "phone": req.body.phone,
            "store_hours":req.body.store_hours,
            "type":req.body.type
        };
        var schema = Joi.object().keys({
            "name": Joi.string().required(),
            "address": Joi.string().required(),
            "city": Joi.string().required(),
            "state": Joi.string().required(),
            "country": Joi.string().required(),
            "zip": Joi.string().required(),
            "phone": Joi.string().required(),
            "store_hours": Joi.string().required(),
            "type": Joi.string().required()

        });
        Joi.validate(Data, schema, function (err, value) {
            if (err) {
                res.json({
                    status: req.config.statusCode.error,
                    error: err,
                    message: "Validation errors!"
                });
            } else {
                Data.business_id = req.user.id;
                Data.created = moment.utc().format('YYYY-MM-DD HH:mm:ss');
                new companyLocationModel(Data).save().then(function (result) {
                    if (!result) {
                        throw new Error("An error has occurred while processing your request. Try again.");
                    }
                    var data = result.toJSON();
                    res.json({
                        status: req.config.statusCode.success,
                        data: data,
                        message: "Company location added successfully"
                    });
                }).catch(function (err) {
                    res.json({
                        status: req.config.statusCode.error,
                        data: null,
                        message: err
                    });
                });
            }

        });
    },

    companyLocation_edit: function (req, res, next) {
        var id = req.query.id || 0;

        if (id > 0) {
            var Data = {
            "name": req.body.name,
            "address": req.body.address,
            "city": req.body.city,
            "state": req.body.state,
            "country": req.body.country,
            "zip": req.body.zip,
            "phone": req.body.phone,
            "store_hours":req.body.store_hours,
            "type":req.body.type

            };
            var schema = Joi.object().keys({
                "name": Joi.string().required(),
                "address": Joi.string().required(),
                "city": Joi.string().required(),
                "state": Joi.string().required(),
                "country": Joi.string().required(),
                "zip": Joi.string().required(),
                "phone": Joi.string().required(),
                "store_hours": Joi.string().required(),
                "type": Joi.string().required()
            });
            Joi.validate(Data, schema, function (err, value) {
                if (err) {
                    res.json({
                        status: req.config.statusCode.error,
                        error: err,
                        message: "Validation errors!"
                    });
                } else {
                    new companyLocationModel().where({ id: id }).save(Data, { patch: true }).then(function (result) {
                        res.json({
                            status: req.config.statusCode.success,
                            data: result.toJSON(),
                            message: "Company location updated successfully."
                        });
                    }).catch(function (err) {
                        res.json({
                            status: req.config.statusCode.error,
                            error: err,
                            message: "Something went wrong! Please try again later"
                        });
                    });
                }
            });
        } else {
            res.json({
                status: req.config.statusCode.error,
                error: err,
                message: "Record not found!"
            });
        }
    },

    companyLocation_delete: function (req, res, next) {
        if (utils.notEmpty(req.body.id)) {
            new companyLocationModel().where({ id: req.body.id }).save({ "is_deleted": 1 }, { patch: true }).then(function (result) {
                res.json({
                    status: req.config.statusCode.success,
                    message: "Deleted successfully!"
                });
            }).catch(function (err) {
                return res.json({
                    status: req.config.statusCode.error,
                    message: 'Unable to delete!',
                    error: err
                });
            });
        } else {
            res.json({
                status: req.config.statusCode.error,
                error: [],
                message: "Please select atlist one record!"
            });
        }
    },

    companyLocation_get: function (req, res, next) {
        if (utils.notEmpty(req.query.id)) {
            new companyLocationModel().query(function (qb) {
                qb.whereRaw("id = " + req.query.id);
            }).fetch().then(function (result) {
                return res.json({
                    status: req.config.statusCode.success,
                    data: result.toJSON(),
                    message: 'Company location found successfully!'
                });
            }).catch(function (err) {
                return res.json({
                    status: req.config.statusCode.error,
                    message: 'Unable to get vendor!',
                    error: err
                });
            });
        } else {
            res.json({
                status: req.config.statusCode.error,
                error: [],
                message: "Please provide id"
            });
        }
    }

}



