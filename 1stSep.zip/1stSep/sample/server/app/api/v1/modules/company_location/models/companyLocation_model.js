var bookshelf = __rootRequire('app/config/bookshelf');
var CompanyLocation = bookshelf.Model.extend({
    tableName: 'company_locations',
    idAttribute: 'id'
});

module.exports = bookshelf.model('CompanyLocation', CompanyLocation);