var crypto = __rootRequire('app/utils/crypto');

module.exports = function(router){

    var configureoption = require('./controllers/configoption_ctrl')

    router.get('/configoption/get', crypto.ensureAuthorized, configureoption.configoption_get)
    router.get('/configoption/getall', crypto.ensureAuthorized, configureoption.configoption_getall)
    router.get('/configoption/list', crypto.ensureAuthorized, configureoption.configoption_list)
    router.post('/configoption/add', crypto.ensureAuthorized, configureoption.configoption_add)
    router.post('/configoption/edit', crypto.ensureAuthorized, configureoption.configoption_edit)
    router.post('/configoption/delete', crypto.ensureAuthorized, configureoption.configoption_delete)

    return router;
}
