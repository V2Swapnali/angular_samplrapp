var jwt = require('jsonwebtoken');
var Joi = require('joi');
var moment = require('moment');
var async = require('async');
var crypto = __rootRequire('app/utils/crypto');
var utils = __rootRequire('app/utils/common');
var configureModel = require('./../models/configoption_model');
const uuidV4 = require('uuid/v4');
module.exports = {

    configoption_list: function (req, res, next) {

        var page = req.query.page - 1 || 0;
        var limit = req.query.limit || 10;
        var offset = limit * page;

        var sort = 'created';
        var order = 'desc';

        
         var query = "is_deleted = 0 AND is_default = 0";
        if (utils.notEmpty(req.query.type)) {
            query += " AND type LIKE '" + req.query.type + "%'";
        }

        new configureModel().query(function (qb) {
            qb.count('* as CNT');
            qb.whereRaw(query);
        }).fetch().then(function (result) {
            var cnt = result.toJSON().CNT;
            new configureModel().query(function (qb) {
                qb.whereRaw(query);
                qb.orderBy(sort, order);
                qb.limit(limit).offset(offset);
            }).fetchAll({ columns: ['id', 'type', 'field', 'conf_values','created'] }).then(function (results) {
                res.json({
                    status: req.config.statusCode.success,
                    message: 'SUCCESS',
                    data: results.toJSON(),
                    count: cnt
                });
            }).catch(function (err) {
                console.log(err);
                res.json({
                    status: req.config.statusCode.error,
                    error: err,
                    message: "Something went wrong!!"
                });
            });
        }).catch(function (err) {
            console.log(err);
            res.json({
                status: req.config.statusCode.error,
                error: err,
                message: "Configuration not found"
            });
        });
    },

    configoption_add: function (req, res, next) { 
        var Data = {
            "type": req.body.type,
            "field": req.body.field,
            "conf_values": JSON.stringify(req.body.vals),
            "conf_units": JSON.stringify(req.body.units)
        };
        var schema = Joi.object().keys({
            "type": Joi.string().required(),
            "field": Joi.string().required(),
            "conf_values": Joi.any().optional(),
            "conf_units": Joi.any().optional(),
        });
        Joi.validate(Data, schema, function (err, value) {
            if (err) {
                res.json({
                    status: req.config.statusCode.error,
                    error: err,
                    message: "Validation errors!"
                });
            } else {

                Data.created = moment.utc().format('YYYY-MM-DD HH:mm:ss');
                new configureModel(Data).save().then(function (result) {
                    if (!result) {
                        throw new Error("An error has occurred while processing your request. Try again.");
                    }
                    var data = result.toJSON();
                    res.json({
                        status: req.config.statusCode.success,
                        data: data,
                        message: "Configuration added successfully."
                    });
                }).catch(function (err) {
                    console.log(err);
                    res.json({
                        status: req.config.statusCode.error,
                        data: null,
                        message: err
                    });
                });
            }


        });
    },

    configoption_edit: function (req, res, next) {
        var id = req.query.id || 0;

        if (id > 0) {
            var Data = {
                 "type": req.body.type,
                 "field": req.body.field,
                 "conf_values": JSON.stringify(req.body.conf_values),
                 "conf_units": JSON.stringify(req.body.conf_units)
            };
            var schema = Joi.object().keys({
                 "type": Joi.string().required(),
                 "field": Joi.string(),
                 "conf_values": Joi.any().optional(),
                 "conf_units": Joi.any().optional() 
            });
            Joi.validate(Data, schema, function (err, value) {
                if (err) {
                    res.json({
                        status: req.config.statusCode.error,
                        error: err,
                        message: "Validation errors!"
                    });
                } else {
                    new configureModel().where({ id: id }).save(Data, { patch: true }).then(function (result) {
                        res.json({
                            status: req.config.statusCode.success,
                            data: result.toJSON(),
                            message: "Configuration updated successfully."
                        });
                    }).catch(function (err) {
                        console.log(err);
                        res.json({
                            status: req.config.statusCode.error,
                            error: err,
                            message: "Something went wrong! Please try again later"
                        });
                    });
                }
            });
        } else {
            res.json({
                status: req.config.statusCode.error,
                error: err,
                message: "Record not found!"
            });
        }
    },

    configoption_delete: function (req, res, next) {
        if (utils.notEmpty(req.body.id)) {
          new configureModel().where({ id: req.body.id }).save({ "is_deleted": 1 }, { patch: true }).then(function (result) {
                res.json({
                    status: req.config.statusCode.success,
                    message: "Deleted successfully!"
                });
            }).catch(function (err) {
                console.log(err);
                return res.json({
                    status: req.config.statusCode.error,
                    message: 'Unable to delete!',
                    error: err
                });
            });
        } else {
            res.json({
                status: req.config.statusCode.error,
                error: [],
                message: "Please select atlist one record!"
            });
        }
    },

    configoption_get: function (req, res, next) {
        if (utils.notEmpty(req.query.id)) {
            new configureModel().query(function (qb) {
                qb.whereRaw("id = " + req.query.id);
            }).fetch().then(function (result) {
                res.json({
                    status: req.config.statusCode.success,
                    data: result.toJSON(),
                    message: 'Configuration found successfully!'
                });
            }).catch(function (err) {
                console.log(err);
                res.json({
                    status: req.config.statusCode.error,
                    message: 'Unable to get configuration!',
                    error: err
                });
            });
        } else {
            res.json({
                status: req.config.statusCode.error,
                error: [],
                message: "Please provide id"
            });
        }
    },

    configoption_getall: function (req, res, next) {

        var query = "is_deleted = 0 AND is_default = 0";
        new configureModel().query(function (qb) {
        }).fetch().then(function (result) {
            var cnt = result.toJSON().CNT;
            new configureModel().query(function (qb) {
                qb.whereRaw(query);
            }).fetchAll({ columns: ['id', 'type', 'field', 'conf_values', 'created'] }).then(function (results) {
                res.json({
                    status: req.config.statusCode.success,
                    message: 'SUCCESS',
                    data: results.toJSON(),
                    count: cnt
                });
            }).catch(function (err) {
                console.log(err);
                res.json({
                    status: req.config.statusCode.error,
                    error: err,
                    message: "Something went wrong!!"
                });
            });
        }).catch(function (err) {
            console.log(err);
            res.json({
                status: req.config.statusCode.error,
                error: err,
                message: "Configuration not found"
            });
        });
    }
    
}