var bookshelf = __rootRequire('app/config/bookshelf');
var Configure = bookshelf.Model.extend({
    tableName: 'configure_options',
    idAttribute: 'id',
    initialize:function(){ 
        // this.on("creating",this.onCreating);
        // this.on("updating",this.onCreating);
        this.on("fetched",this.onFetching);
    },
    onCreating:function(){ 
        // if(this.attributes.conf_values != ''){ 
        //     this.attributes.conf_values = '"'+JSON.stringify(this.attributes.conf_values)+'"';
        //     console.log('updating',this.attributes.conf_values);
        // }
    },
   
     onFetching:function(){
        if(this.attributes.conf_values != '' && typeof this.attributes.conf_values != 'undefined'){
            this.attributes.conf_values = JSON.parse(this.attributes.conf_values);
        }
        if(this.attributes.conf_units != '' && typeof this.attributes.conf_units != 'undefined'){
            this.attributes.conf_units = JSON.parse(this.attributes.conf_units);
        }
    }
});

module.exports = bookshelf.model('Configure', Configure);
