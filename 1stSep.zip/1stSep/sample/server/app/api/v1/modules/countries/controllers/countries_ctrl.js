var jwt = require('jsonwebtoken');
var Joi = require('joi');
var moment = require('moment');
var async = require('async');
var bookshelf = __rootRequire('app/config/bookshelf');
var utils = __rootRequire('app/utils/common');
var countryModel = require('./../models/countries_model');
module.exports = {

    country_list: function (req, res, next) {
        var sort = 'name';
        var order = 'ASC';
        var query = "is_deleted = 0 ";
        new countryModel().query(function (qb) {
            qb.select(bookshelf.knex.raw("id AS value, CONCAT(name) AS label"));
            qb.whereRaw(query);
            qb.orderBy(sort, order);
        }).fetchAll().then(function (results) {
            res.json({
                status: req.config.statusCode.success,
                message: 'SUCCESS',
                data: results.toJSON()
            });
        }).catch(function (err) {
            console.log(err);
            res.json({
                status: req.config.statusCode.error,
                error: err,
                message: "Something went wrong!!"
            });
        });
    }
}



