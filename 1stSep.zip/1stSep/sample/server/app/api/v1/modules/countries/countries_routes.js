var crypto = __rootRequire('app/utils/crypto');

module.exports = function (router) {
    var country = require('./controllers/countries_ctrl')
    router.get('/country/list', crypto.ensureAuthorized, country.country_list)
    return router;
}