var bookshelf = __rootRequire('app/config/bookshelf');
var Country = bookshelf.Model.extend({
    tableName: 'countries',
    idAttribute: 'id',
    role: function () {
        return this.belongsTo('State', 'country_id');
    }
});

module.exports = bookshelf.model('Country', Country);

