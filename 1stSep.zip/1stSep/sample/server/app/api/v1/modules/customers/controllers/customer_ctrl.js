var jwt = require('jsonwebtoken');
var Joi = require('joi');
var moment = require('moment');
var async = require('async');
var bookshelf = __rootRequire('app/config/bookshelf');
var utils = __rootRequire('app/utils/common');
var customerModel = require('./../models/customer_model');
module.exports = {


    customer_list: function (req, res, next) {

        var page = req.query.page - 1 || 0;
        var limit = req.query.limit || 10;
        var offset = limit * page;

        var sort = 'created';
        var order = 'desc';

        var query = "is_deleted = 0 AND business_id = " + req.user.id;
        if (utils.notEmpty(req.query.f_name)) {
            query += " AND f_name LIKE '" + req.query.f_name + "%'";
        }

        if (utils.notEmpty(req.query.l_name)) {
            query += " AND l_name LIKE '" + req.query.l_name + "%'";
        }

        if (utils.notEmpty(req.query.email)) {
            query += " AND email LIKE '" + req.query.email + "%'";
        }
        if (utils.notEmpty(req.query.city)) {
            query += " AND city LIKE '" + req.query.city + "%'";
        }

        new customerModel().query(function (qb) {
            qb.count('* as CNT');
            qb.whereRaw(query);
        }).fetch().then(function (result) {
            var cnt = result.toJSON().CNT;
            new customerModel().query(function (qb) {
                qb.whereRaw(query);
                qb.orderBy(sort, order);
                qb.limit(limit).offset(offset);
            }).fetchAll({ columns: ['id', 'f_name', 'l_name', 'email', 'company', 'address', 'country', 'city', 'state', 'zip', 'business_id', 'created', 'phone'] }).then(function (results) {
                res.json({
                    status: req.config.statusCode.success,
                    message: 'SUCCESS',
                    data: results.toJSON(),
                    count: cnt
                });
            }).catch(function (err) {
                console.log(err);
                res.json({
                    status: req.config.statusCode.error,
                    error: err,
                    message: "Something went wrong!!"
                });
            });
        }).catch(function (err) {
            console.log(err);
            res.json({
                status: req.config.statusCode.error,
                error: err,
                message: "Customer not found"
            });
        });
    },

    customer_getAll: function (req, res, next) {

        var sort = 'f_name';
        var order = 'ASC';

        var query = "is_deleted = 0 AND business_id = " + req.user.id;
        new customerModel().query(function (qb) {
            qb.select(bookshelf.knex.raw("id AS value, CONCAT(f_name, ' ', l_name) AS label"));
            qb.whereRaw(query);
            qb.orderBy(sort, order);
        }).fetchAll().then(function (results) {
            res.json({
                status: req.config.statusCode.success,
                message: 'SUCCESS',
                data: results.toJSON()
            });
        }).catch(function (err) {
            console.log(err);
            res.json({
                status: req.config.statusCode.error,
                error: err,
                message: "Something went wrong!!"
            });
        });
    },

    customer_add: function (req, res, next) {
        var Data = {
            "f_name": req.body.f_name,
            "l_name": req.body.l_name,
            "email": req.body.email,
            "phone": req.body.phone,
            "company": req.body.company,
            "address": req.body.address,
            "city": req.body.city,
            "state": req.body.state,
            "country": req.body.country,
            "zip": req.body.zip,

        };
        var schema = Joi.object().keys({
            "f_name": Joi.string().required(),
            "l_name": Joi.string().required(),
            "email": Joi.string().email().required(),
            "phone": Joi.string().required(),
            "company": Joi.string().required(),
            "address": Joi.string().required(),
            "city": Joi.string().required(),
            "state": Joi.string().required(),
            "country": Joi.string().required(),
            "zip": Joi.string().required(),

        });
        Joi.validate(Data, schema, function (err, value) {
            if (err) {
                res.json({
                    status: req.config.statusCode.error,
                    error: err,
                    message: "Validation errors!"
                });
            } else {

                unique_check('email', Data.email, function (exist) {
                    if (exist) {
                        res.json({
                            status: req.config.statusCode.error,
                            message: "Email  already exist"
                        });
                    } else {

                        Data.business_id = req.user.id;
                        Data.created = moment.utc().format('YYYY-MM-DD HH:mm:ss');
                        new customerModel(Data).save().then(function (result) {
                            if (!result) {
                                throw new Error("An error has occurred while processing your request. Try again.");
                            }
                            var data = result.toJSON();
                            res.json({
                                status: req.config.statusCode.success,
                                data: data,
                                message: "Customer added successfully"
                            });
                        }).catch(function (err) {
                            console.log(err);
                            res.json({
                                status: req.config.statusCode.error,
                                data: null,
                                message: err
                            });
                        });
                    }
                })
            }


        });
    },

    customer_edit: function (req, res, next) {
        var id = req.query.id || 0;

        if (id > 0) {
            var Data = {
                "f_name": req.body.f_name,
                "l_name": req.body.l_name,
                "email": req.body.email,
                "phone": req.body.phone,
                "company": req.body.company,
                "address": req.body.address,
                "city": req.body.city,
                "state": req.body.state,
                "country": req.body.country,
                "zip": req.body.zip,

            };
            var schema = Joi.object().keys({
                "f_name": Joi.string().required(),
                "l_name": Joi.string().required(),
                "email": Joi.string().email().required(),
                "phone": Joi.string().required(),
                "company": Joi.string().required(),
                "address": Joi.string().required(),
                "city": Joi.string().required(),
                "state": Joi.string().required(),
                "country": Joi.string().required(),
                "zip": Joi.string().required(),
            });
            Joi.validate(Data, schema, function (err, value) {
                if (err) {
                    res.json({
                        status: req.config.statusCode.error,
                        error: err,
                        message: "Validation errors!"
                    });
                } else {
                    new customerModel().where({ id: id }).save(Data, { patch: true }).then(function (result) {
                        res.json({
                            status: req.config.statusCode.success,
                            data: result.toJSON(),
                            message: "Customer account updated successfully."
                        });
                    }).catch(function (err) {
                        console.log(err);
                        res.json({
                            status: req.config.statusCode.error,
                            error: err,
                            message: "Something went wrong! Please try again later"
                        });
                    });
                }
            });
        } else {
            res.json({
                status: req.config.statusCode.error,
                error: err,
                message: "Record not found!"
            });
        }
    },

    customer_delete: function (req, res, next) {
        if (utils.notEmpty(req.body.id)) {
            new customerModel().where({ id: req.body.id }).save({ "is_deleted": 1 }, { patch: true }).then(function (result) {
                res.json({
                    status: req.config.statusCode.success,
                    message: "Deleted successfully!"
                });
            }).catch(function (err) {
                console.log(err);
                return res.json({
                    status: req.config.statusCode.error,
                    message: 'Unable to delete!',
                    error: err
                });
            });
        } else {
            res.json({
                status: req.config.statusCode.error,
                error: [],
                message: "Please select atlist one record!"
            });
        }
    },

    customer_get: function (req, res, next) {
        if (utils.notEmpty(req.query.id)) {
            new customerModel().query(function (qb) {
                qb.whereRaw("id = " + req.query.id);
            }).fetch().then(function (result) {
                return res.json({
                    status: req.config.statusCode.success,
                    data: result.toJSON(),
                    message: 'User found successfully!'
                });
            }).catch(function (err) {
                console.log(err);
                return res.json({
                    status: req.config.statusCode.error,
                    message: 'Unable to get user!',
                    error: err
                });
            });
        } else {
            res.json({
                status: req.config.statusCode.error,
                error: [],
                message: "Please provide id"
            });
        }
    }

}



function unique_check(field, value, callback) {
    new customerModel().query(function (qb) {
        qb.whereRaw("`" + field + "` = '" + value + "'");
    }).fetch().then(function (result) {
        if (result == null) {
            callback(false);
        } else {
            callback(true);
        }
    }).catch(function (err) {
        callback(false);
    });
} 