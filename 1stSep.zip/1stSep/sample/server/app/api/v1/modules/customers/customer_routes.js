var crypto = __rootRequire('app/utils/crypto');

module.exports = function (router) {

    // ========================= User Block =============================
    var customer = require('./controllers/customer_ctrl')

    router.get('/customer/get', crypto.ensureAuthorized, customer.customer_get)
    router.get('/customer/list', crypto.ensureAuthorized, customer.customer_list)
    router.post('/customer/add', crypto.ensureAuthorized, customer.customer_add)
    router.post('/customer/edit', crypto.ensureAuthorized, customer.customer_edit)
    router.post('/customer/delete', crypto.ensureAuthorized, customer.customer_delete)

    router.get('/customer/getall', crypto.ensureAuthorized, customer.customer_getAll)
    // ========================= User Block =============================

    return router;
}
