var bookshelf = __rootRequire('app/config/bookshelf');
var Customers = bookshelf.Model.extend({
    tableName: 'customers',
    idAttribute: 'id'
});

module.exports = bookshelf.model('Customers', Customers);