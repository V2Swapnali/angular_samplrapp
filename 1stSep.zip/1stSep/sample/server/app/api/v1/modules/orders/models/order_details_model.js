var bookshelf = __rootRequire('app/config/bookshelf');
var OrderDetails = bookshelf.Model.extend({
    tableName: 'order_details',
    idAttribute: 'id'
});

module.exports = bookshelf.model('OrderDetails', OrderDetails);