var bookshelf = __rootRequire('app/config/bookshelf');
require('./order_details_model');
var Orders = bookshelf.Model.extend({
    tableName: 'orders',
    idAttribute: 'id',
    details: function () {
        return this.hasMany('OrderDetails', 'order_id');
    }
});

module.exports = bookshelf.model('Orders', Orders);