var crypto = __rootRequire('app/utils/crypto');

module.exports = function (router) {

    // ========================= User Block =============================
    var order = require('./controllers/order_ctrl')

    router.get('/order/get', crypto.ensureAuthorized, order.order_get)
    router.get('/order/list', crypto.ensureAuthorized, order.order_list)
    router.post('/order/add', crypto.ensureAuthorized, order.order_add)
    router.post('/order/edit', crypto.ensureAuthorized, order.order_edit)
    router.post('/order/delete', crypto.ensureAuthorized, order.order_delete)

    router.get('/order/getall', crypto.ensureAuthorized, order.order_getAll)
    // ========================= User Block =============================

    return router;
}
