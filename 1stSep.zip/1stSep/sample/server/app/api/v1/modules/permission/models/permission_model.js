var bookshelf = __rootRequire('app/config/bookshelf');
var Permission = bookshelf.Model.extend({
    tableName: 'permissions',
    idAttribute: 'id'
});

module.exports = bookshelf.model('Permission', Permission);
