var crypto = __rootRequire('app/utils/crypto');

module.exports = function (router) {

    var permission = require('./controllers/permission_ctrl')

    router.get('/permission/tree', crypto.ensureAuthorized, permission.permission_tree)
    router.get('/permission/treeSa', crypto.ensureAuthorized, permission.permission_tree_Sa)
    

    return router;
}
