var bookshelf = __rootRequire('app/config/bookshelf');
var jwt = require('jsonwebtoken');
var Joi = require('joi');
var moment = require('moment');
var async = require('async');
var crypto = __rootRequire('app/utils/crypto');
var utils = __rootRequire('app/utils/common');
var productMasterModel = require('./../models/product_master_model');
var productSlaveModel = require('./../models/product_slave_model');
var slaveVariantsModel = require('./../models/slave_variants_model');
module.exports = {

    product_master_list: function (req, res, next) {        

        var sort = 'created';
        var order = 'desc';

        var query = "id > 0";
        if (utils.notEmpty(req.query.name)) {
            query += " AND name LIKE '%" + req.query.name + "%'";
        }
        
        new productMasterModel().query(function (qb) {
            qb.whereRaw(query);
            qb.orderBy(sort, order);
        }).fetchAll({withRelated: ['category']}).then(function (results) {
            res.json({
                status: req.config.statusCode.success,
                message: 'SUCCESS',
                data: results.toJSON()
            });
        }).catch(function (err) {
            console.log(err);
            res.json({
                status: req.config.statusCode.error,
                error: err,
                message: "Something went wrong!!"
            });
        });
    },

    product_master_get: function (req, res, next) {
        if (utils.notEmpty(req.query.id)) {
            new productMasterModel().query(function (qb) {
                qb.whereRaw("id = " + req.query.id);
            }).fetch().then(function (result) {
                return res.json({
                    status: req.config.statusCode.success,
                    data: result.toJSON(),
                    message: 'Product found successfully!'
                });
            }).catch(function (err) {
                console.log(err);
                return res.json({
                    status: req.config.statusCode.error,
                    message: 'Unable to get Product!',
                    error: err
                });
            });
        } else {
            res.json({
                status: req.config.statusCode.error,
                error: [],
                message: "Please provide id"
            });
        }
    },

    product_list: function (req, res, next) {
        var page = req.query.page - 1 || 0;
        var limit = req.query.limit || 10;
        var offset = limit * page;

        var sort = 'created';
        var order = 'desc';

        var query = "users_id = "+req.user.id+" AND is_deleted = 0";
        if (utils.notEmpty(req.query.name)) {
            query += " AND name LIKE '" + req.query.name + "%'";
        }

        if (utils.notEmpty(req.query.type)) {
            query += " AND type = '" + req.query.type + "'";
        }

        if (utils.notEmpty(req.query.category)) {
            query += " AND category_id = '" + req.query.category + "%'";
        }

        new productSlaveModel().query(function (qb) {
            qb.count('* as CNT');
            qb.whereRaw(query);
        }).fetch().then(function (result) {
            var cnt = result.toJSON().CNT;
            new productSlaveModel().query(function (qb) {
                qb.whereRaw(query);
                qb.orderBy(sort, order);
                qb.limit(limit).offset(offset);
            }).fetchAll({withRelated: ['category', 'variants']}).then(function (results) {
                res.json({
                    status: req.config.statusCode.success,
                    message: 'SUCCESS',
                    data: results.toJSON(),
                    count: cnt
                });
            }).catch(function (err) {
                console.log(err);
                res.json({
                    status: req.config.statusCode.error,
                    error: err,
                    message: "Something went wrong!!"
                });
            });
        }).catch(function (err) {
            console.log(err);
            res.json({
                status: req.config.statusCode.error,
                error: err,
                message: "Product not found"
            });
        });
    },

    product_add: function (req, res, next) {
        var noErr = true;
        var prodID = 0;
        var Data = {
            "name": req.body.name,
            "type": req.body.type,
            "description": req.body.description,
            "category_id": req.body.category_id,
            "conf_options": req.body.conf_options,
            "is_new": req.body.is_new
        };
        var schema = Joi.object().keys({
            "name": Joi.string().required(),
            "type": Joi.string().required(),
            "description": Joi.string().required(),
            "category_id": Joi.string().required(),
            "conf_options": Joi.any().optional(),
            "is_new": Joi.any().required()
        });
        Joi.validate(Data, schema, function (err, value) {
            if (err) {
                res.json({
                    status: req.config.statusCode.error,
                    error: err,
                    message: "Validation errors!"
                });
            } else {
                unique_check('name', Data.name, 'create', 0, function (exist) {
                    if (exist) {
                        res.json({
                            status: req.config.statusCode.error,
                            message: "Product with same name is already exist"
                        });
                    } else {
                        Data.created = moment.utc().format('YYYY-MM-DD HH:mm:ss');
                        bookshelf.transaction(function(t) {
                            async.series([
                                function(callback) { 
                                    if (req.body.is_new == 1) {
                                        var md = {
                                            "name": Data.name,
                                            "type": Data.type,
                                            "description": Data.description,
                                            "category_id": Data.category_id,
                                            "master_variants": JSON.stringify(Data.conf_options),
                                            "created": Data.created
                                        }
                                        new productMasterModel(md).save(null,{transacting: t}).then(function (result) {
                                            if (!result) {
                                                noErr = false;
                                            }  
                                            callback();                              
                                        }).catch(function (err) {
                                            noErr = false;
                                            callback(err);
                                        });
                                    }else{
                                        callback();
                                    }
                                },
                                function(callback) { 
                                    var sd = {
                                        "name": Data.name,
                                        "type": Data.type,
                                        "description": Data.description,
                                        "category_id": Data.category_id,
                                        "users_id": req.user.id,
                                        "created": Data.created
                                    }
                                    new productSlaveModel(sd).save(null,{transacting: t}).then(function (result) {
                                        if (!result) {
                                            noErr = false;
                                        }
                                        prodID = result.toJSON().id;
                                        callback();                              
                                    }).catch(function (err) {
                                        noErr = false;
                                        callback(err);
                                    });
                                },
                                function(callback) { 
                                    async.forEachOf(Data.conf_options, function (value, key, cback) {
                                        async.forEachOf(value, function (v, k, cb) {
                                            var d = {
                                                prod_id: prodID,
                                                vg_count: key,
                                                co_id: parseInt(k.substr(2)),
                                                co_value: v.val,
                                                co_unit: v.unit
                                            }
                                            new slaveVariantsModel(d).save(null,{transacting: t}).then(function (result) {
                                                if (!result) {
                                                    noErr = false;
                                                }  
                                                cb();                              
                                            }).catch(function (err) {
                                                console.log(err)
                                                noErr = false;
                                                cb(err);
                                            });
                                        }, function (err) {
                                            cback(err);
                                        }); 
                                    }, function (err) {
                                        callback(err);
                                    });                            
                                }
                            ], function(err, results) {
                                console.log(err);
                                if(err){
                                    t.rollback();
                                }else{
                                    if(noErr){
                                        t.commit();
                                    }else{
                                        t.rollback();
                                    }
                                }
                            });                    
                        }).then(function(library) {
                            res.json({
                                status: req.config.statusCode.success,
                                message: "Product Saved Successfully!"
                            });
                        }).catch(function(err) {
                            //console.log(err);
                            res.json({
                                status: req.config.statusCode.error,
                                message: "Something went wrong! Please try again!"
                            });
                        });
                    }
                });
            }
        });
    },

    product_edit: function (req, res, next) {
        var noErr = true;
        var Data = {
            "name": req.body.name,
            "type": req.body.type,
            "description": req.body.description,
            "category_id": req.body.category_id,
            "conf_options": req.body.conf_options
        };
        var schema = Joi.object().keys({
            "name": Joi.string().required(),
            "type": Joi.string().required(),
            "description": Joi.string().required(),
            "category_id": Joi.string().required(),
            "conf_options": Joi.any().optional()
        });
        Joi.validate(Data, schema, function (err, value) {
            if (err) {
                res.json({
                    status: req.config.statusCode.error,
                    error: err,
                    message: "Validation errors!"
                });
            } else {
                unique_check('name', Data.name, 'update', req.query.id, function (exist) {
                    if (exist) {
                        res.json({
                            status: req.config.statusCode.error,
                            message: "Product with same name is already exist"
                        });
                    } else {
                        Data.created = moment.utc().format('YYYY-MM-DD HH:mm:ss');
                        bookshelf.transaction(function(t) {
                            async.series([
                                function(callback) { 
                                    var sd = {
                                        "name": Data.name,
                                        "type": Data.type,
                                        "description": Data.description,
                                        "category_id": Data.category_id,
                                        "users_id": req.user.id,
                                        "created": Data.created
                                    }
                                    new productSlaveModel().where({ id: req.query.id }).save(sd,{patch: true, transacting: t}).then(function (result) {
                                        if (!result) {
                                            noErr = false;
                                        }
                                        callback();                              
                                    }).catch(function (err) {
                                        noErr = false;
                                        callback(err);
                                    });
                                },
                                function(callback){
                                    new slaveVariantsModel().query(function (qb) {
                                        qb.whereRaw("prod_id = "+req.query.id);
                                    }).destroy({transacting: t}).then(function (result) {
                                        callback();
                                    }).catch(function (err) {
                                        noErr = false;
                                        callback(err);
                                    });
                                },
                                function(callback) { 
                                    async.forEachOf(Data.conf_options, function (value, key, cback) {
                                        async.forEachOf(value, function (v, k, cb) {
                                            var d = {
                                                prod_id: req.query.id,
                                                vg_count: key,
                                                co_id: parseInt(k.substr(2)),
                                                co_value: v.val,
                                                co_unit: v.unit
                                            }
                                            new slaveVariantsModel(d).save(null,{transacting: t}).then(function (result) {
                                                if (!result) {
                                                    noErr = false;
                                                }  
                                                cb();                              
                                            }).catch(function (err) {
                                                console.log(err)
                                                noErr = false;
                                                cb(err);
                                            });
                                        }, function (err) {
                                            cback(err);
                                        }); 
                                    }, function (err) {
                                        callback(err);
                                    });                            
                                }
                            ], function(err, results) {
                                console.log(err);
                                if(err){
                                    t.rollback();
                                }else{
                                    if(noErr){
                                        t.commit();
                                    }else{
                                        t.rollback();
                                    }
                                }
                            });                    
                        }).then(function(library) {
                            res.json({
                                status: req.config.statusCode.success,
                                message: "Product Saved Successfully!"
                            });
                        }).catch(function(err) {
                            //console.log(err);
                            res.json({
                                status: req.config.statusCode.error,
                                message: "Something went wrong! Please try again!"
                            });
                        });
                    }
                });
            }
        });
    },

    product_delete: function (req, res, next) {
        if (utils.notEmpty(req.body.ids)) {
            new productSlaveModel().query(function (qb) {
                qb.whereRaw("id IN(" + req.body.ids.join(',') + ")");
            }).save({ "is_deleted": 1 }, { patch: true }).then(function (result) {
                return res.json({
                    status: req.config.statusCode.success,
                    message: 'Deleted successfully!'
                });
            }).catch(function (err) {
                console.log(err);
                return res.json({
                    status: req.config.statusCode.error,
                    message: 'Unable to delete!',
                    error: err
                });
            });
        } else {
            res.json({
                status: req.config.statusCode.error,
                error: [],
                message: "Please select atlist one record!"
            });
        }
    },

    product_get: function (req, res, next) {
        if (utils.notEmpty(req.query.id)) {
            new productSlaveModel().query(function (qb) {
                qb.whereRaw("id = " + req.query.id);
            }).fetch({withRelated: ['variants']}).then(function (result) {
                return res.json({
                    status: req.config.statusCode.success,
                    data: result.toJSON(),
                    message: 'User found successfully!'
                });
            }).catch(function (err) {
                console.log(err);
                return res.json({
                    status: req.config.statusCode.error,
                    message: 'Unable to get user!',
                    error: err
                });
            });
        } else {
            res.json({
                status: req.config.statusCode.error,
                error: [],
                message: "Please provide id"
            });
        }
    },

    product_search: function (req, res, next) {

        var sort = 'P.created';
        var order = 'desc';

        var query = "P.users_id = "+req.user.id+" AND P.is_deleted = 0";
        if (utils.notEmpty(req.query.name)) {
            query += " AND P.name LIKE '" + req.query.name + "%'";
        }

        new productSlaveModel().query(function (qb) {
            qb.from('product_slave as P');
            qb.select(bookshelf.knex.raw("MAX(S.vg_count) vc, P.*"));
            qb.joinRaw("LEFT JOIN slave_variants AS S ON(P.id = S.prod_id)");
            qb.whereRaw(query);
            //qb.groupBy('S.vg_count','S.prod_id');
            qb.groupBy('P.id');
            qb.orderBy(sort, order);
        }).fetchAll({withRelated: ['category']}).then(function (results) {
            var rs = results.toJSON();
            var resData = [];
            async.forEach(rs, function (value, callback) {
                async.times((value.vc+1), function(n, cb){
                    new slaveVariantsModel().query(function (qb) {
                        qb.whereRaw("prod_id = "+value.id+" AND vg_count = '"+n+"'");
                    }).fetchAll({withRelated: ['confoption']}).then(function (rslt) {
                        var prodListName = rslt.toJSON().map((v) => {
                            return v.confoption.type + ': ' + v.co_value;
                        }).filter((n) => { return n != undefined }).join(', ');
                        var d = {
                            "id": value.id,
                            "category_id": value.category_id,
                            "users_id": value.users_id,
                            "type": value.type,
                            "name": value.name,
                            "description": value.description,
                            "category": value.category,
                            "variants": rslt.toJSON(),
                            "vc": n,
                            "listname": value.name+', '+prodListName
                        };
                        resData.push(d);
                        cb()
                    }).catch(function (err) {
                        cb();
                    }); 
                }, function(err) {
                    callback()
                });
            }, function (err) {
                res.json({
                    status: req.config.statusCode.success,
                    message: 'SUCCESS',
                    data: resData
                });
            }); 
        }).catch(function (err) {
            console.log(err);
            res.json({
                status: req.config.statusCode.error,
                error: err,
                message: "Something went wrong!!"
            });
        });
    }
}

function unique_check(field, value, prps, id, callback) {
    var Q = "`" + field + "` = '" + value + "'";
    if (prps != 'create') {
        Q += " AND id != " + id;
    }
    new productSlaveModel().query(function (qb) {
        qb.whereRaw(Q);
    }).fetch().then(function (result) {
        if (result == null) {
            callback(false);
        } else {
            callback(true);
        }
    }).catch(function (err) {
        callback(false);
    });
}
