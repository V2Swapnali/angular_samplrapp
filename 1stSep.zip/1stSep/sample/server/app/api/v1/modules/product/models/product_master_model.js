var bookshelf = __rootRequire('app/config/bookshelf');
require('./../../product_category/models/category_model');
var ProductMaster = bookshelf.Model.extend({
    tableName: 'product_master',
    idAttribute: 'id',
    category: function () {
        return this.belongsTo('Category', 'category_id');
    },
    initialize:function(){
        this.on("fetched",this.onFetching);
    },
    onFetching:function(){
        if(this.attributes.master_variants != '' && typeof this.attributes.master_variants != 'undefined'){
            this.attributes.master_variants = JSON.parse(this.attributes.master_variants);
        }
    }
});

module.exports = bookshelf.model('ProductMaster', ProductMaster);
