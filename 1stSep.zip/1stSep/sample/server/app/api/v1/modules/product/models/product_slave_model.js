var bookshelf = __rootRequire('app/config/bookshelf');
require('./../../product_category/models/category_model');
require('./slave_variants_model');
var ProductSlave = bookshelf.Model.extend({
    tableName: 'product_slave',
    idAttribute: 'id',
    category: function () {
        return this.belongsTo('Category', 'category_id');
    },
    variants: function () {
        return this.hasMany('SlaveVariants', 'prod_id');
    }
});

module.exports = bookshelf.model('ProductSlave', ProductSlave);
