var bookshelf = __rootRequire('app/config/bookshelf');
require('./../../configure_option/models/configoption_model');
var SlaveVariants = bookshelf.Model.extend({
    tableName: 'slave_variants',
    idAttribute: 'id',
    confoption: function () {
        return this.belongsTo('Configure', 'co_id');
    }
});

module.exports = bookshelf.model('SlaveVariants', SlaveVariants);
