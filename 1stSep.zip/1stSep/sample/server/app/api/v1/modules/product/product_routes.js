var crypto = __rootRequire('app/utils/crypto');

module.exports = function(router){

    var product = require('./controllers/product_ctrl')

    router.get('/product/get', crypto.ensureAuthorized, product.product_get)
    router.get('/product/list', crypto.ensureAuthorized, crypto.ensureAccess, product.product_list)
    router.post('/product/add', crypto.ensureAuthorized, crypto.ensureAccess, product.product_add)
    router.post('/product/edit', crypto.ensureAuthorized, crypto.ensureAccess, product.product_edit)
    router.post('/product/delete', crypto.ensureAuthorized, crypto.ensureAccess, product.product_delete)

    router.get('/product/masterlist', crypto.ensureAuthorized, product.product_master_list)
    router.get('/product/masterget', crypto.ensureAuthorized, product.product_master_get)
    router.get('/product/getproducts', crypto.ensureAuthorized, product.product_search)

    return router;
}
