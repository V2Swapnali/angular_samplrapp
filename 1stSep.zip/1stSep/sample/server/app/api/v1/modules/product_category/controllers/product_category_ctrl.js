var jwt = require('jsonwebtoken');
var Joi = require('joi');
var moment = require('moment');
var async = require('async');
var crypto = __rootRequire('app/utils/crypto');
var utils = __rootRequire('app/utils/common');
var categoryModel = require('./../models/category_model');
var categoryConfigModel = require('./../../configure_option/models/configoption_model');
const uuidV4 = require('uuid/v4');
module.exports = {

    category_list: function (req, res, next) {

        var page = req.query.page - 1 || 0;
        var limit = req.query.limit || 10;
        var offset = limit * page;

        var sort = 'created';
        var order = 'desc';

        var query = "is_deleted = 0";
        if (utils.notEmpty(req.query.name)) {
            query += " AND name LIKE '" + req.query.name + "%'";
        }

        new categoryModel().query(function (qb) {
            qb.count('* as CNT');
            qb.whereRaw(query);
        }).fetch().then(function (result) {
            var cnt = result.toJSON().CNT;
            new categoryModel().query(function (qb) {
                qb.whereRaw(query);
                qb.orderBy(sort, order);
                qb.limit(limit).offset(offset);
            }).fetchAll({ withRelated: ['parent'] }).then(function (results) {
                res.json({
                    status: req.config.statusCode.success,
                    message: 'SUCCESS',
                    data: results.toJSON(),
                    count: cnt
                });
            }).catch(function (err) {
                console.log(err);
                res.json({
                    status: req.config.statusCode.error,
                    error: err,
                    message: "Something went wrong!!"
                });
            });
        }).catch(function (err) {
            console.log(err);
            res.json({
                status: req.config.statusCode.error,
                error: err,
                message: "Product not found"
            });
        });
    },

    category_add: function (req, res, next) {
        var Data = {
            "parent_id": req.body.parent_id,
            "name": req.body.name,
            "description": req.body.description,
            'configure_options': JSON.stringify(req.body.confoptions)
        };
        var schema = Joi.object().keys({
            "parent_id": Joi.number().required(),
            "name": Joi.string().required(),
            "description": Joi.string().required(),
            "configure_options": Joi.any().optional()
        });
        Joi.validate(Data, schema, function (err, value) {
            if (err) {
                res.json({
                    status: req.config.statusCode.error,
                    error: err,
                    message: "Validation errors!"
                });
            } else {

                Data.created = moment.utc().format('YYYY-MM-DD HH:mm:ss');
                new categoryModel(Data).save().then(function (result) {
                    if (!result) {
                        throw new Error("An error has occurred while processing your request. Try again.");
                    }
                    var data = result.toJSON();
                    res.json({
                        status: req.config.statusCode.success,
                        data: data,
                        message: "Category added successfully."
                    });
                }).catch(function (err) {
                    console.log(err);
                    res.json({
                        status: req.config.statusCode.error,
                        data: null,
                        message: err
                    });
                });
            }


        });
    },

    category_edit: function (req, res, next) {
        var id = req.query.id || 0;

        if (id > 0) {
            var Data = {
                "parent_id": req.body.parent_id,
                "name": req.body.name,
                "description": req.body.description,
                'configure_options': JSON.stringify(req.body.confoptions)
            };
            var schema = Joi.object().keys({
                "parent_id": Joi.number().required(),
                "name": Joi.string().required(),
                "description": Joi.string().required(),
                "configure_options": Joi.any().optional()
            });
            Joi.validate(Data, schema, function (err, value) {
                if (err) {
                    res.json({
                        status: req.config.statusCode.error,
                        error: err,
                        message: "Validation errors!"
                    });
                } else {
                    new categoryModel().where({ id: id }).save(Data, { patch: true }).then(function (result) {
                        res.json({
                            status: req.config.statusCode.success,
                            data: result.toJSON(),
                            message: "Category updated successfully."
                        });
                    }).catch(function (err) {
                        console.log(err);
                        res.json({
                            status: req.config.statusCode.error,
                            error: err,
                            message: "Something went wrong! Please try again later"
                        });
                    });
                }
            });
        } else {
            res.json({
                status: req.config.statusCode.error,
                error: err,
                message: "Record not found!"
            });
        }
    },

    category_delete: function (req, res, next) {
        if (utils.notEmpty(req.body.id)) {
            new categoryModel().where({ id: req.body.id }).save({ "is_deleted": 1 }, { patch: true }).then(function (result) {
                res.json({
                    status: req.config.statusCode.success,
                    message: "Deleted successfully!"
                });
            }).catch(function (err) {
                console.log(err);
                return res.json({
                    status: req.config.statusCode.error,
                    message: 'Unable to delete!',
                    error: err
                });
            });
        } else {
            res.json({
                status: req.config.statusCode.error,
                error: [],
                message: "Please select atlist one record!"
            });
        }
    },

    category_get: function (req, res, next) {
        if (utils.notEmpty(req.query.id)) {
            new categoryModel().query(function (qb) {
                qb.whereRaw("id = " + req.query.id);
            }).fetch().then(function (result) {
                res.json({
                    status: req.config.statusCode.success,
                    data: result.toJSON(),
                    message: 'User found successfully!'
                });
            }).catch(function (err) {
                console.log(err);
                res.json({
                    status: req.config.statusCode.error,
                    message: 'Unable to get user!',
                    error: err
                });
            });
        } else {
            res.json({
                status: req.config.statusCode.error,
                error: [],
                message: "Please provide id"
            });
        }
    },

    category_tree: function (req, res, next) {
        var id = req.query.id || 0;
        IterateOver(id).then(function (val) {
            res.json({
                status: req.config.statusCode.success,
                data: val,
                message: 'User found successfully!'
            });
        });
    },

    category_tree_options: function (req, res, next) {
        var id = req.query.id || 0;
        var root = req.query.root || 1;
        IterateOverOpt(id, [], 1).then(function (val) {
            if (root == 1) {
                val.push({
                    value: 0,
                    label: 'Root'
                });
            }
            res.json({
                status: req.config.statusCode.success,
                data: val.reverse(),
                message: 'Category list!'
            });
        });
    },

    category_child: function (req, res, next) {
        var id = req.query.id || 0;
        new categoryModel().query(function (qb) {
            qb.whereRaw("parent_id = " + id + " AND is_deleted = 0");
        }).fetchAll().then(function (result) {
            res.json({
                status: req.config.statusCode.success,
                data: result.toJSON(),
                message: 'User found successfully!'
            });
        }).catch(function (err) {
            console.log(err);
            res.json({
                status: req.config.statusCode.error,
                message: 'Unable to get chield!',
                error: err
            });
        });
    },

    category_configoption: function (req, res, next) {
        if (utils.notEmpty(req.query.id)) {
            var type = req.query.type || 'all';
            new categoryModel().query(function (qb) {
                qb.whereRaw("id = " + req.query.id);
            }).fetch().then(function (result) {
                var rs = result.toJSON();
                var Q = "is_deleted = 0 AND (FIND_IN_SET('all',inventory_type) > 0 OR FIND_IN_SET('"+type+"',inventory_type) > 0)";
                if (utils.notEmpty(rs.configure_options)) {
                    Q += " AND (id IN(" + rs.configure_options.map(function (v) { return v.optid; }) + ") OR is_default = 1)";
                } else {
                    Q += " AND is_default = 1";
                }
                new categoryConfigModel().query(function (qb) {
                    qb.whereRaw(Q);
                }).fetchAll().then(function (rslt) {
                    var confopt = [];
                    var rsc = rslt.toJSON();
                    async.forEachOf(rsc, function (value, key, callback) {
                        var isunique = false;
                        async.forEachOf(rs.configure_options, function (v, k, cb) {
                            if (v.optid == value.id && v.unique == 'true') {
                                isunique = true;
                            }
                            cb();
                        }, function (err) {
                            confopt.push({
                                optid: value.id,
                                unique: isunique,
                                confdata: value
                            });
                            callback();
                        });
                    }, function (err) {
                        rs.configure_options = confopt;
                        res.json({
                            status: req.config.statusCode.success,
                            data: rs,
                            message: 'Category details!'
                        });
                    });
                }).catch(function (err) {
                    console.log(err);
                    res.json({
                        status: req.config.statusCode.error,
                        message: 'Unable to get configurable options!',
                        error: err
                    });
                });
            }).catch(function (err) {
                console.log(err);
                res.json({
                    status: req.config.statusCode.error,
                    message: 'Unable to get category!',
                    error: err
                });
            });
        } else {
            res.json({
                status: req.config.statusCode.error,
                error: [],
                message: "Please select at list one record!"
            });
        }
    }
}

function IterateOver(id) {
    var q = require('q');
    var deferred = q.defer();
    new categoryModel().query(function (qb) {
        qb.whereRaw("parent_id = " + id + " AND is_deleted = 0");
    }).fetchAll().then(function (result) {
        var d = result.toJSON();
        if (d.length > 0) {
            async.forEachOf(d, function (value, key, callback) {
                IterateOver(value.id).then(function (val) {
                    d[key]['chield'] = val;
                    callback();
                })
            }, function (err) {
                deferred.resolve(d);
            });
        } else {
            deferred.resolve([]);
        }
    });
    return deferred.promise;
}

function IterateOverOpt(id, data, level) {
    var q = require('q');
    var deferred = q.defer();
    new categoryModel().query(function (qb) {
        qb.whereRaw("parent_id = " + id + " AND is_deleted = 0");
    }).fetchAll().then(function (result) {
        var d = result.toJSON();
        if (d.length > 0) {
            async.forEachOf(d, function (value, key, callback) {
                IterateOverOpt(value.id, data, level + 1).then(function (val) {
                    data.push({
                        value: value.id,
                        label: "-".repeat(level - 1) + value.name
                    });
                    callback();
                })
            }, function (err) {
                deferred.resolve(data);
            });
        } else {
            deferred.resolve(data);
        }
    });
    return deferred.promise;
}

