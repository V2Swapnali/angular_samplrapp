var bookshelf = __rootRequire('app/config/bookshelf');
var Category = bookshelf.Model.extend({
    tableName: 'categories',
    idAttribute: 'id',
    parent: function () {
        return this.belongsTo('Category', 'parent_id');
    },
    initialize:function(){
        //this.on("creating",this.onCreating);
        //this.on("updating",this.onCreating);
        this.on("fetched",this.onFetching);
    },
    onCreating:function(){
        if(this.attributes.configure_options != ''){
            this.attributes.configure_options = JSON.stringify(this.attributes.configure_options);
        }
    },
    onFetching:function(){
        if(this.attributes.configure_options != '' && typeof this.attributes.configure_options != 'undefined'){
            this.attributes.configure_options = JSON.parse(this.attributes.configure_options);
        }
    }
});

module.exports = bookshelf.model('Category', Category);
