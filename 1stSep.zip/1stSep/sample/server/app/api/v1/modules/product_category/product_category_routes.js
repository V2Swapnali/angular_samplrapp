var crypto = __rootRequire('app/utils/crypto');

module.exports = function(router){

    var category = require('./controllers/product_category_ctrl')

    router.get('/productcat/get', crypto.ensureAuthorized, category.category_get)
    router.get('/productcat/list', crypto.ensureAuthorized, category.category_list)
    router.post('/productcat/add', crypto.ensureAuthorized, category.category_add)
    router.post('/productcat/edit', crypto.ensureAuthorized, category.category_edit)
    router.post('/productcat/delete', crypto.ensureAuthorized, category.category_delete)

    router.get('/productcat/tree', crypto.ensureAuthorized, category.category_tree)
    router.get('/productcat/treeoptions', crypto.ensureAuthorized, category.category_tree_options)
    router.get('/productcat/child', crypto.ensureAuthorized, category.category_child)

    router.get('/productcat/configoption', crypto.ensureAuthorized, category.category_configoption)

    return router;
}
