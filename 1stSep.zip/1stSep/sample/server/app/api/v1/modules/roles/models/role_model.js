var bookshelf = __rootRequire('app/config/bookshelf');
var Role = bookshelf.Model.extend({
    tableName: 'roles',
    idAttribute: 'id'
});

module.exports = bookshelf.model('Role', Role);
