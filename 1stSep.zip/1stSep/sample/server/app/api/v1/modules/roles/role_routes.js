var crypto = __rootRequire('app/utils/crypto');

module.exports = function (router) {

    // ========================= Subscription Block =============================
    var role = require('./controllers/role_ctrl')

    router.get('/role/get', crypto.ensureAuthorized, role.role_get)
    router.get('/role/list', crypto.ensureAuthorized, crypto.ensureAccess, role.role_list)
    router.post('/role/add', crypto.ensureAuthorized, crypto.ensureAccess, role.role_add)    
    router.post('/role/edit', crypto.ensureAuthorized, crypto.ensureAccess, role.role_edit)     
    router.post('/role/delete', crypto.ensureAuthorized, crypto.ensureAccess, role.role_delete)
    router.get('/role/getall', crypto.ensureAuthorized, role.role_get_all)     
    // ========================= Subscription Block =============================

    return router;
}