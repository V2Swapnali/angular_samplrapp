var utils = __rootRequire('app/utils/common');
var settingsModel = require('./../models/settings_model');
module.exports = {

    settings_save: function (req, res, next) {
        if (utils.notEmpty(req.body.settings) && utils.notEmpty(req.body.settings_name)) {
            new settingsModel().query(function (qb) {
                qb.whereRaw("`business_id`  =  '" + req.user.comp_id + "'");
            }).fetch().then(function (result) {
                if(result){
                    var settings = JSON.parse(result.toJSON().settings);
                    settings[req.body.settings_name] = req.body.settings;
                    result.save({'settings':JSON.stringify(settings)}).then(function (result) {
                        res.json({
                            status: req.config.statusCode.success,
                            message: 'Settings saved successfully.',
                        });
                    }).catch(function (err) {
                        console.log(err);
                        res.json({
                            status: req.config.statusCode.error,
                            message: 'Settings not saved. Please try again.',
                            error: err
                        });
                    });
                }else {
                    var st = {};
                    st[req.body.settings_name] = req.body.settings;
                    var dd = {
                        business_id: req.user.comp_id,
                        settings: JSON.stringify(st)
                    };
                    new settingsModel(dd).save().then(function (rs) {
                        res.json({
                            status: req.config.statusCode.success,
                            data: {},
                            message: 'Settings saved successfully.'
                        });
                    }).catch(function (err) {
                        console.log(err);
                        res.json({
                            status: req.config.statusCode.error,
                            error: err,
                            message: "Settings not saved. Please try again!"
                        });
                    });
                }                
            }).catch(function (err) {
                console.log(err);
                res.json({
                    status: req.config.statusCode.error,
                    error: err,
                    message: "Something went wrong! Please try again later"
                });
            });
        } else {
            res.json({
                status: req.config.statusCode.error,
                error: err,
                message: "provide settings!"
            });
        }
    },

    settings_get: function (req, res, next) {
        if (utils.notEmpty(req.query.type)) {
            new settingsModel().query(function (qb) {
                qb.whereRaw("business_id = " + req.user.comp_id);
            }).fetch().then(function (result) {
                if(result){
                    var rs = result.toJSON();
                    var settings = JSON.parse(rs.settings);
                    return res.json({
                        status: req.config.statusCode.success,
                        data: settings[req.query.type] || {},
                        message: 'Settings found successfully!'
                    });
                }else{
                    return res.json({
                        status: req.config.statusCode.success,
                        data:{},
                        message: 'Settings found successfully'
                    });
                }
            }).catch(function (err) {
                console.log(err);
                return res.json({
                    status: req.config.statusCode.error,
                    message: 'Unable to get settings!',
                    error: err
                });
            });
        } else {
            res.json({
                status: req.config.statusCode.error,
                error: [],
                message: "Please provide settings type"
            });
        }
    }
}