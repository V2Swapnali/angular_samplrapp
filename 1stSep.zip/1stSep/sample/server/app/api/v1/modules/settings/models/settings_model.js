var bookshelf = __rootRequire('app/config/bookshelf');
var Settings = bookshelf.Model.extend({
    tableName: 'company_settings',
    idAttribute: 'id'
});

module.exports = bookshelf.model('Settings', Settings);
