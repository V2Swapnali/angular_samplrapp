var crypto = __rootRequire('app/utils/crypto');

module.exports = function(router){

// ========================= Settings Block =============================
    var settings = require('./controllers/settings_ctrl')
     //crypto.ensureAccess,
     router.get('/settings/get', crypto.ensureAuthorized, settings.settings_get)
     router.post('/settings/save', crypto.ensureAuthorized, settings.settings_save)   
// ========================= Settings Block =============================

    return router;
}
