var jwt = require('jsonwebtoken');
var Joi = require('joi');
var moment = require('moment');
var async = require('async');
var crypto = __rootRequire('app/utils/crypto');
var utils = __rootRequire('app/utils/common');
var staffModel = require('./../models/staff_model');
const uuidV4 = require('uuid/v4');
module.exports = {

    staff_add: function (req, res, next) {
        var Data = {
            "role_id": req.body.role_id,
            "f_name": req.body.f_name,
            "l_name": req.body.l_name,
            "user_name": req.body.user_name,
            "password": req.body.password,
            "email": req.body.email,
            "parent_id": req.user.id,
            "pay_rate":req.body.pay_rate,
            "pay_schedule":req.body.pay_schedule,
            "pay_method":req.body.pay_method,
            "hire_date":req.body.hire_date,
            "location":req.body.location,

        };
        var schema = Joi.object().keys({
            "role_id": Joi.string().required(),
            "f_name": Joi.string().required(),
            "l_name": Joi.string().required(),
            "user_name": Joi.string().required(),
            "password": Joi.string().required(),
            "email": Joi.string().email().required(),
            "parent_id": Joi.number(),
            "pay_rate":Joi.number(),
            "pay_schedule": Joi.string().required(),
            "pay_method": Joi.string().required(),
            "hire_date": Joi.string().required(),
            "location": Joi.string().required(),
        });
        Joi.validate(Data, schema, function (err, value) {
            if (err) {
                res.json({
                    status: req.config.statusCode.error,
                    error: err,
                    message: "Validation errors!"
                });
            } else {
                crypto.generatePassword(Data.password, function (err, solt, cryptedPassword) {
                    if (!err) {
                        var pass = Data.password;
                        Data.password = cryptedPassword;
                        Data.solt = solt;
                        Data.created = moment.utc().format('YYYY-MM-DD HH:mm:ss');
                        unique_check('email', Data.email, 'create', 0, function (exist) {
                            if (exist) {
                                res.json({
                                    status: req.config.statusCode.error,
                                    message: "Email  already exist"
                                });
                            } else {
                                unique_check('user_name', Data.user_name, 'create', 0, function (exist) {
                                    if (exist) {
                                        res.json({
                                            status: req.config.statusCode.error,
                                            message: " Username already exist"
                                        });
                                    } else {
                                        Data.activation_key = uuidV4();
                                        new staffModel(Data).save().then(function (result) {
                                            //Email code
                                            var email = __rootRequire('app/core/email');
                                            var options = { template: 'invite_email.html', repalcement: { "{{user.name}}": Data.f_name, "{{user.invite_url}}": req.config.businessAdminUrl + '/activateaccount/' + Data.activation_key, "{{logo_url}}": req.config.businessAdminUrl + "/assets/images/logo.png", "{{copyright}}": (new Date().getFullYear()) + " Copyright You__it", "{{link.abuse_email}}": "abuse@youblankit.com" }, to: Data.email, subject: 'Activate Account- You__it.com' };
                                            email.smtp.sendMail(options, function (error, response) {
                                                if (error)
                                                    console.log(error);
                                                else {
                                                    console.log("Message sent: Successfully");
                                                }
                                            });
                                            //End

                                            //Email code For sending username and password
                                            var email = __rootRequire('app/core/email');
                                            var options = { template: 'userpass_email.html', repalcement: { "{{user.name}}": Data.f_name, "{{user.invite_url}}": req.config.businessAdminUrl + '/login/', "{{user.user_name}}": Data.user_name, "{{user.password}}": pass, "{{logo_url}}": req.config.businessAdminUrl + "/assets/images/logo.png", "{{copyright}}": (new Date().getFullYear()) + " Copyright You__it", "{{link.abuse_email}}": "abuse@youblankit.com" }, to: Data.email, subject: 'Getting Username and Password' };
                                            email.smtp.sendMail(options, function (error, response) {
                                                if (error)
                                                    console.log(error);
                                                else {
                                                    console.log("Message sent: Successfully2");
                                                }
                                            });
                                            //End
                                            res.json({
                                                status: req.config.statusCode.success,
                                                data: result.toJSON(),
                                                message: "You have registered successfully"
                                            });
                                        }).catch(function (err) {
                                            console.log(err);
                                            res.json({
                                                status: req.config.statusCode.error,
                                                error: err,
                                                message: "Staff  process failed! Please try again later"
                                            });
                                        });
                                    }
                                })
                            }
                        })
                    } else {
                        console.log(err);
                        res.jsoqb.whereRaw("'" + field + "' = '" + value + "'"); n({
                            status: req.config.statusCode.error,
                            error: err,
                            message: "Unabale to get security info!"
                        });
                    }
                });
            }
        });
    },
    //Super admin Staff
        staff_add_Sa: function (req, res, next) {
        var Data = {
            "role_id": req.body.role_id,
            "f_name": req.body.f_name,
            "l_name": req.body.l_name,
            "user_name": req.body.user_name,
            "password": req.body.password,
            "email": req.body.email,
            "parent_id": req.user.id
          

        };
        var schema = Joi.object().keys({
            "role_id": Joi.string().required(),
            "f_name": Joi.string().required(),
            "l_name": Joi.string().required(),
            "user_name": Joi.string().required(),
            "password": Joi.string().required(),
            "email": Joi.string().email().required(),
            "parent_id": Joi.number()
            
            
        });
        Joi.validate(Data, schema, function (err, value) {
            if (err) {
                res.json({
                    status: req.config.statusCode.error,
                    error: err,
                    message: "Validation errors!"
                });
            } else {
                crypto.generatePassword(Data.password, function (err, solt, cryptedPassword) {
                    if (!err) {
                        var pass = Data.password;
                        Data.password = cryptedPassword;
                        Data.solt = solt;
                        Data.created = moment.utc().format('YYYY-MM-DD HH:mm:ss');
                        unique_check('email', Data.email, 'create', 0, function (exist) {
                            if (exist) {
                                res.json({
                                    status: req.config.statusCode.error,
                                    message: "Email  already exist"
                                });
                            } else {
                                unique_check('user_name', Data.user_name, 'create', 0, function (exist) {
                                    if (exist) {
                                        res.json({
                                            status: req.config.statusCode.error,
                                            message: " Username already exist"
                                        });
                                    } else {
                                        Data.activation_key = uuidV4();
                                        new staffModel(Data).save().then(function (result) {
                                            //Email code For sending username and password
                                            var email = __rootRequire('app/core/email');
                                            var options = { template: 'userpass_email.html', repalcement: { "{{user.name}}": Data.f_name, "{{user.invite_url}}": req.config.businessAdminUrl + '/login/', "{{user.user_name}}": Data.user_name, "{{user.password}}": pass, "{{logo_url}}": req.config.businessAdminUrl + "/assets/images/logo.png", "{{copyright}}": (new Date().getFullYear()) + " Copyright You__it", "{{link.abuse_email}}": "abuse@youblankit.com" }, to: Data.email, subject: 'Getting Username and Password' };
                                            email.smtp.sendMail(options, function (error, response) {
                                                if (error)
                                                    console.log(error);
                                                else {
                                                    console.log("Message sent: Successfully2");
                                                }
                                            });
                                            //End
                                            res.json({
                                                status: req.config.statusCode.success,
                                                data: result.toJSON(),
                                                message: "You have registered successfully"
                                            });
                                        }).catch(function (err) {
                                            console.log(err);
                                            res.json({
                                                status: req.config.statusCode.error,
                                                error: err,
                                                message: "Staff  process failed! Please try again later"
                                            });
                                        });
                                    }
                                })
                            }
                        })
                    } else {
                        console.log(err);
                        res.jsoqb.whereRaw("'" + field + "' = '" + value + "'"); n({
                            status: req.config.statusCode.error,
                            error: err,
                            message: "Unabale to get security info!"
                        });
                    }
                });
            }
        });
    },

    staff_edit: function (req, res, next) {
        var id = req.query.id || 0;

        if (id > 0) {
            var Data = {
                "role_id": req.body.role_id,
                "f_name": req.body.f_name,
                "l_name": req.body.l_name,
                "user_name": req.body.user_name,
                "email": req.body.email
            };

            var schema = Joi.object().keys({
                "role_id": Joi.string().required(),
                "f_name": Joi.string().required(),
                "l_name": Joi.string().required(),
                "user_name": Joi.string().required(),
                "email": Joi.string().email().required()
            });

            Joi.validate(Data, schema, function (err, value) {
                if (err) {
                    res.json({
                        status: req.config.statusCode.error,
                        error: err,
                        message: "Validation errors!"
                    });
                } else {
                    unique_check('email', Data.email, 'update', id, function (exist) {
                        if (exist) {
                            res.json({
                                status: req.config.statusCode.error,
                                message: "Email  already exist"
                            });
                        } else {
                            unique_check('user_name', Data.user_name, 'update', id, function (exist) {
                                if (exist) {
                                    res.json({
                                        status: req.config.statusCode.error,
                                        message: " Username already exist"
                                    });
                                } else {
                                    new staffModel().where({ id: id }).save(Data, { patch: true }).then(function (result) {
                                        res.json({
                                            status: req.config.statusCode.success,
                                            data: result.toJSON(),
                                            message: "Staff account updated successfully."
                                        });
                                    }).catch(function (err) {
                                        console.log(err);
                                        res.json({
                                            status: req.config.statusCode.error,
                                            error: err,
                                            message: "Something went wrong! Please try again later"
                                        });
                                    });
                                }
                            })
                        }
                    });
                }
            });
        } else {
            res.json({
                status: req.config.statusCode.error,
                error: err,
                message: "Record not found!"
            });
        }
    },

    staff_get: function (req, res, next) {
        if (utils.notEmpty(req.query.id)) {
            new staffModel().query(function (qb) {
                qb.whereRaw("id = " + req.query.id);
            }).fetch().then(function (result) {
                return res.json({
                    status: req.config.statusCode.success,
                    data: result.toJSON(),
                    message: 'Staff found successfully!'
                });
            }).catch(function (err) {
                console.log(err);
                return res.json({
                    status: req.config.statusCode.error,
                    message: 'Unable to get Staff!',
                    error: err
                });
            });
        } else {
            res.json({
                status: req.config.statusCode.error,
                error: [],
                message: "Please provide id"
            });
        }
    },

    staff_delete: function (req, res, next) {
        if (utils.notEmpty(req.body.id)) {
            new staffModel().where({ id: req.body.id }).save({ "is_deleted": 1 }, { patch: true }).then(function (result) {
                res.json({
                    status: req.config.statusCode.success,
                    message: "Deleted successfully!"
                });
            }).catch(function (err) {
                console.log(err);
                return res.json({
                    status: req.config.statusCode.error,
                    message: 'Unable to delete!',
                    error: err
                });
            });
        } else {
            res.json({
                status: req.config.statusCode.error,
                error: [],
                message: "Please select atlist one record!"
            });
        }
    },

    staff_list: function (req, res, next) {

        var page = req.query.page - 1 || 0;
        var limit = req.query.limit || 10;
        var offset = limit * page;

        var sort = 'created';
        var order = 'desc';

        var query = "role_id >= 10 AND is_deleted = 0 AND parent_id = " + req.user.id;
        if (utils.notEmpty(req.query.f_name)) {
            query += " AND f_name LIKE '" + req.query.f_name + "%'";
        }

        if (utils.notEmpty(req.query.l_name)) {
            query += " AND l_name LIKE '" + req.query.l_name + "%'";
        }

        if (utils.notEmpty(req.query.email)) {
            query += " AND email LIKE '" + req.query.email + "%'";
        }

        new staffModel().query(function (qb) {
            qb.count('* as CNT');
            qb.whereRaw(query);
        }).fetch().then(function (result) {
            var cnt = result.toJSON().CNT;
            new staffModel().query(function (qb) {
                qb.whereRaw(query);
                qb.orderBy(sort, order);
                qb.limit(limit).offset(offset);
            }).fetchAll({ columns: ['id', 'f_name', 'l_name', 'email', 'user_name', 'created','status'] }).then(function (results) {
                res.json({
                    status: req.config.statusCode.success,
                    message: 'SUCCESS',
                    data: results.toJSON(),
                    count: cnt
                });
            }).catch(function (err) {
                console.log(err);
                res.json({
                    status: req.config.statusCode.error,
                    error: err,
                    message: "Something went wrong!!"
                });
            });
        }).catch(function (err) {
            console.log(err);
            res.json({
                status: req.config.statusCode.error,
                error: err,
                message: "Staff not found"
            });
        });
    }
}

function unique_check(field, value, prps, user_id, callback) {
    var Q = "`" + field + "` = '" + value + "'";
    if (prps != 'prps') {
        console.log("Inside pprs");
        Q += " AND id != " + user_id;
    }
    new staffModel().query(function (qb) {
        qb.whereRaw(Q);
    }).fetch().then(function (result) {
        if (result == null) {
            callback(false);
        } else {
            callback(true);
        }
    }).catch(function (err) {
        callback(false);
    });
}   