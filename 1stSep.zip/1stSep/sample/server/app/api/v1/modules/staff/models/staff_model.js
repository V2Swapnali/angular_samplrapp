var bookshelf = __rootRequire('app/config/bookshelf');
var Staff = bookshelf.Model.extend({
    tableName: 'users',
    idAttribute: 'id'
});

module.exports = bookshelf.model('Staff', Staff);
