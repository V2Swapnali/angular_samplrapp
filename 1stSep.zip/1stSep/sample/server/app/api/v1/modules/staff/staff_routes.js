var crypto = __rootRequire('app/utils/crypto');

module.exports = function(router){

// ========================= Staff Block =============================
    var staff = require('./controllers/staff_ctrl')
    
     router.get('/staff/get', crypto.ensureAuthorized, staff.staff_get)
     router.get('/staff/list', crypto.ensureAuthorized, crypto.ensureAccess, staff.staff_list)
     router.post('/staff/add', crypto.ensureAuthorized, crypto.ensureAccess, staff.staff_add)
     router.post('/staff/addSa', crypto.ensureAuthorized, crypto.ensureAccess, staff.staff_add_Sa)
     router.post('/staff/edit', crypto.ensureAuthorized, crypto.ensureAccess, staff.staff_edit)
     router.post('/staff/delete', crypto.ensureAuthorized, crypto.ensureAccess, staff.staff_delete)    
// ========================= User Block =============================

    return router;
}
