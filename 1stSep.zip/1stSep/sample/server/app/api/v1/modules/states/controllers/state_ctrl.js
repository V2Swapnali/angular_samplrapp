var jwt = require('jsonwebtoken');
var Joi = require('joi');
var moment = require('moment');
var async = require('async');
var bookshelf = __rootRequire('app/config/bookshelf');
var utils = __rootRequire('app/utils/common');
var stateModel = require('./../models/state_model');
module.exports = {

    state_list: function (req, res, next) {
        if (utils.notEmpty(req.query.c_id)) {
            var sort = 'name';
            var order = 'ASC';
            var query = "is_deleted = 0 AND country_id = "+req.query.c_id;
            new stateModel().query(function (qb) {
                qb.select(bookshelf.knex.raw("id AS value, CONCAT(name) AS label"));
                qb.whereRaw(query);
                qb.orderBy(sort, order);
            }).fetchAll().then(function (results) {
                res.json({
                    status: req.config.statusCode.success,
                    message: 'SUCCESS',
                    data: results.toJSON()
                });
            }).catch(function (err) {
                console.log(err);
                res.json({
                    status: req.config.statusCode.error,
                    error: err,
                    message: "Something went wrong!!"
                });
            });
        } else {
            res.json({
                status: req.config.statusCode.error,
                error: [],
                message: "Please provide country!"
            });
        }
    }

}



