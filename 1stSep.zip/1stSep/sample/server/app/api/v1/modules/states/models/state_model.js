var bookshelf = __rootRequire('app/config/bookshelf');
var State = bookshelf.Model.extend({
    tableName: 'states',
    idAttribute: 'id',   
});

module.exports = bookshelf.model('State',State);

