var crypto = __rootRequire('app/utils/crypto');

module.exports = function (router) {
    var state = require('./controllers/state_ctrl')
    router.get('/state/list', crypto.ensureAuthorized, state.state_list)
    return router;
}