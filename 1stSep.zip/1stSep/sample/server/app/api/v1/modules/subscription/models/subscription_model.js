var bookshelf = __rootRequire('app/config/bookshelf');
var Subscription = bookshelf.Model.extend({
    tableName: 'subscription_plans',
    idAttribute: 'id'
});

module.exports = bookshelf.model('Subscription', Subscription);