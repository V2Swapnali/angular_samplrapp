var crypto = __rootRequire('app/utils/crypto');

module.exports = function (router) {

    // ========================= Subscription Block =============================
    var subscription = require('./controllers/subscription_ctrl')

    router.get('/subscription/get', crypto.ensureAuthorized, subscription.subscription_get)
    router.get('/subscription/list', crypto.ensureAuthorized, crypto.ensureAccess, subscription.subscription_list)
    router.post('/subscription/add', crypto.ensureAuthorized, crypto.ensureAccess, subscription.subscription_add)    
    router.post('/subscription/edit', crypto.ensureAuthorized, crypto.ensureAccess, subscription.subscription_edit)    
    router.post('/subscription/delete', crypto.ensureAuthorized, crypto.ensureAccess, subscription.subscription_delete)
    // ========================= Subscription Block =============================

    return router;
}