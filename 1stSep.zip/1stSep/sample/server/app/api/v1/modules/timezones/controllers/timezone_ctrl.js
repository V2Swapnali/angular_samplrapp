var jwt = require('jsonwebtoken');
var Joi = require('joi');
var moment = require('moment');
var async = require('async');
var bookshelf = __rootRequire('app/config/bookshelf');
var utils = __rootRequire('app/utils/common');
var timezoneModel = require('./../models/timezone_model');
module.exports = {

    timezone_list: function (req, res, next) {
        var sort = 'timezone';
        var order = 'ASC';
        var query = "id > 0 ";
        new timezoneModel().query(function (qb) {
            qb.select(bookshelf.knex.raw("id AS value, CONCAT(timezone, ' (', utc_offset, ')') AS label"));
            qb.whereRaw(query);
            qb.orderBy(sort, order);
        }).fetchAll().then(function (results) {
            res.json({
                status: req.config.statusCode.success,
                message: 'SUCCESS',
                data: results.toJSON()
            });
        }).catch(function (err) {
            console.log(err);
            res.json({
                status: req.config.statusCode.error,
                error: err,
                message: "Something went wrong!!"
            });
        });
    }
}



