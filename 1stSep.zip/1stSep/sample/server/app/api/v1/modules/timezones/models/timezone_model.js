var bookshelf = __rootRequire('app/config/bookshelf');
var Timezone = bookshelf.Model.extend({
    tableName: 'timezones',
    idAttribute: 'id',
    role: function () {
        return this.belongsTo('State', 'country_id');
    }
});

module.exports = bookshelf.model('Timezone', Timezone);

