var crypto = __rootRequire('app/utils/crypto');

module.exports = function (router) {
    var timezone = require('./controllers/timezone_ctrl')
    router.get('/timezone/list', timezone.timezone_list)
    return router;
}