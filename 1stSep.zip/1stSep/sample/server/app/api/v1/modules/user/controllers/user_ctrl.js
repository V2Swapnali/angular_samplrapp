var jwt = require('jsonwebtoken');
var Joi = require('joi');
var moment = require('moment');
var async = require('async');
var crypto = __rootRequire('app/utils/crypto');
var utils = __rootRequire('app/utils/common');
var bookshelf = __rootRequire('app/config/bookshelf');
var userModel = require('./../models/user_model');
const uuidV4 = require('uuid/v4');
module.exports = {

    checklogin: function (req, res, next) {
        crypto.ensureAuthorized(req, res, function () {
            res.json({
                status: req.config.statusCode.success,
                user: req.user,
                message: 'You have a valid login details'
            });
        });
    },

    sa_login: function (req, res, next) {
        var Data = {
            user_name: req.body.user_name,
            password: req.body.password
        };
        var schema = Joi.object().keys({
            user_name: Joi.string().required(),
            password: Joi.string().required()
        });
        Joi.validate(Data, schema, function (err, value) {
            if (err) {
                res.send({
                    status: req.config.statusCode.error,
                    error: err,
                    message: "Validation errors!"
                });
            } else {
                crypto.getSecurityInfo('secratekey', function (err, securityData) {
                    if (!err) {
                        new userModel().query(function (qb) {
                            qb.select(bookshelf.knex.raw("U.*, P.role_id, P.id as comp_id, R.role_details AS role_details"));
                            qb.from('users as U');
                            qb.joinRaw("LEFT JOIN `users` as P ON(U.parent_id=P.id)");
                            qb.joinRaw("LEFT JOIN `roles` as R ON(U.role_id=R.id)")
                            qb.whereRaw("U.user_name = '" + Data.user_name + "' AND (U.role_id = 1 OR P.role_id = 1) AND U.status = 1");
                        }).fetchAll().then(function (result) {
                            var rs = result.toJSON();
                            if (rs.length > 0) {
                                var userfound = null;
                                async.eachSeries(rs, function iteratee(user, callback) {
                                    crypto.comparePassword(user.password, Data.password, user.solt, securityData.key, function (Pres) {
                                        if (Pres) {
                                            userfound = user;
                                        }
                                        callback();
                                    })
                                }, function done() {
                                    var resUser = {
                                        "f_name": userfound.f_name,
                                        "l_name": userfound.l_name,
                                        "full_name": userfound.f_name + ' ' + userfound.l_name,
                                        "email": userfound.email,
                                        "role_details": userfound.role_details,
                                        "comp_id": userfound.comp_id || userfound.id,
                                        "created": userfound.created,
                                        "modified": userfound.modified
                                    };
                                    var tokenData = resUser;
                                    tokenData.id = userfound.id;
                                    var token = jwt.sign(tokenData, securityData.key, {
                                        expiresIn: req.config.tokenExpiryTime
                                    });
                                    res.json({
                                        status: req.config.statusCode.success,
                                        data: {
                                            'user': resUser,
                                            'token': token
                                        },
                                        message: 'user data'
                                    });
                                });
                            } else {
                                res.json({
                                    status: req.config.statusCode.error,
                                    error: err,
                                    message: "User not found!"
                                });
                            }
                        }).catch(function (err) {
                            console.log(err);
                            res.json({
                                status: req.config.statusCode.error,
                                error: err,
                                message: "User not found"
                            });
                        });
                    } else {
                        console.log(err);
                        res.json({
                            status: req.config.statusCode.error,
                            error: err,
                            message: "Unabale to get security info!"
                        });
                    }
                });
            }
        });
    },

    sa_profile_update: function (req, res, next) {
        var id = req.user.id || 0;

        if (id > 0) {
            var Data = {
                "f_name": req.body.f_name,
                "l_name": req.body.l_name,
                "email": req.body.email,
                "phone": req.body.phone,
                "user_name": req.body.user_name,

            };
            var schema = Joi.object().keys({
                "f_name": Joi.string().required(),
                "l_name": Joi.string().required(),
                "email": Joi.string().email().required(),
                "phone": Joi.string().required(),
                "user_name": Joi.string().required()
            });
            Joi.validate(Data, schema, function (err, value) {
                if (err) {
                    res.json({
                        status: req.config.statusCode.error,
                        error: err,
                        message: "Validation errors!"
                    });
                } else {
                    unique_check('email', Data.email, 'update', id, function (exist) {
                        if (exist) {
                            res.json({
                                status: req.config.statusCode.error,
                                message: "Email  already exist"
                            });
                        } else {
                            unique_check('user_name', Data.user_name, 'update', id, function (exist) {
                                if (exist) {
                                    res.json({
                                        status: req.config.statusCode.error,
                                        message: " Username already exist"
                                    });
                                } else {
                                    new userModel().where({ id: id }).save(Data, { patch: true }).then(function (result) {
                                        res.json({
                                            status: req.config.statusCode.success,
                                            data: result.toJSON(),
                                            message: "Profile updated successfully."
                                        });
                                    }).catch(function (err) {
                                        console.log(err);
                                        res.json({
                                            status: req.config.statusCode.error,
                                            error: err,
                                            message: "Something went wrong! Please try again later"
                                        });
                                    });
                                }
                            })
                        }
                    })
                }
            });
        } else {
            res.json({
                status: req.config.statusCode.error,
                message: "Record not found!"
            });
        }
    },

    bu_profile_update: function (req, res, next) {
        var id = req.user.id || 0;

        if (id > 0) {
            var Data = {
                "f_name": req.body.f_name,
                "l_name": req.body.l_name,
                "email": req.body.email,
                "phone": req.body.phone,
                "user_name": req.body.user_name,

            };
            var schema = Joi.object().keys({
                "f_name": Joi.string().required(),
                "l_name": Joi.string().required(),
                "email": Joi.string().email().required(),
                "phone": Joi.string().required(),
                "user_name": Joi.string().required()
            });
            Joi.validate(Data, schema, function (err, value) {
                if (err) {
                    res.json({
                        status: req.config.statusCode.error,
                        error: err,
                        message: "Validation errors!"
                    });
                } else {
                    unique_check('email', Data.email, 'update', id, function (exist) {
                        if (exist) {
                            res.json({
                                status: req.config.statusCode.error,
                                message: "Email  already exist"
                            });
                        } else {
                            unique_check('user_name', Data.user_name, 'update', id, function (exist) {
                                if (exist) {
                                    res.json({
                                        status: req.config.statusCode.error,
                                        message: " Username already exist"
                                    });
                                } else {
                                    new userModel().where({ id: id }).save(Data, { patch: true }).then(function (result) {
                                        res.json({
                                            status: req.config.statusCode.success,
                                            data: result.toJSON(),
                                            message: "Profile updated successfully."
                                        });
                                    }).catch(function (err) {
                                        console.log(err);
                                        res.json({
                                            status: req.config.statusCode.error,
                                            error: err,
                                            message: "Something went wrong! Please try again later"
                                        });
                                    });
                                }
                            })
                        }
                    })
                }
            });
        } else {
            res.json({
                status: req.config.statusCode.error,
                message: "Record not found!"
            });
        }

    },

    change_password: function (req, res, next) {
        var Data = {
            "password": req.body.password,
            "new_password": req.body.new_password,
        };
        var schema = Joi.object().keys({
            "password": Joi.string().required(),
            "new_password": Joi.string().required()
        });
        Joi.validate(Data, schema, function (err, value) {
            if (err) {
                res.json({
                    status: req.config.statusCode.error,
                    error: err,
                    message: "Validation errors!"
                });
            } else {
                crypto.generatePassword(Data.new_password, function (err, solt, cryptedPassword, securityData) {
                    if (!err) {
                        new userModel().query(function (qb) {
                            qb.whereRaw("id = '" + req.user.id + "'");
                        }).fetch().then(function (result) {
                            if (result) {
                                let rs = result.toJSON();
                                crypto.comparePassword(rs.password, Data.password, rs.solt, securityData.key, function (Pres) {
                                    if (Pres) {
                                        let d = { password: cryptedPassword, solt: solt };
                                        result.save(d, { patch: true }).then(function (rsdata) {
                                            res.json({
                                                status: req.config.statusCode.success,
                                                data: rsdata.toJSON(),
                                                message: "Password updated successfully."
                                            });
                                        }).catch(function (err) {
                                            console.log(err);
                                            res.json({
                                                status: req.config.statusCode.error,
                                                error: err,
                                                message: "Password updation process failed! Please try again later"
                                            });
                                        });
                                    } else {
                                        res.json({
                                            status: req.config.statusCode.error,
                                            error: err,
                                            message: "Invalid password!"
                                        });
                                    }
                                });
                            } else {
                                res.json({
                                    status: req.config.statusCode.error,
                                    error: {},
                                    message: "Password updation process failed! No user found!"
                                });
                            }
                        })
                    } else {
                        console.log(err);
                        res.json({
                            status: req.config.statusCode.error,
                            error: err,
                            message: "Unabale to get security info!"
                        });
                    }
                });

            }
        });
    },

    bu_login: function (req, res, next) {
        var Data = {
            user_name: req.body.user_name,
            password: req.body.password
        };
        var schema = Joi.object().keys({
            user_name: Joi.string().required(),
            password: Joi.string().required()
        });
        Joi.validate(Data, schema, function (err, value) {
            if (err) {
                res.send({
                    status: req.config.statusCode.error,
                    error: err,
                    message: "Validation errors!"
                });
            } else {
                crypto.getSecurityInfo('secratekey', function (err, securityData) {
                    if (!err) {
                        new userModel().query(function (qb) {
                            qb.select(bookshelf.knex.raw("U.*, P.role_id, P.id as comp_id, R.role_details AS role_details"));
                            qb.from('users as U');
                            qb.joinRaw("LEFT JOIN `users` as P ON(U.parent_id=P.id)");
                            qb.joinRaw("LEFT JOIN `roles` as R ON(U.role_id=R.id)");
                            qb.whereRaw("U.user_name = '" + Data.user_name + "' AND (U.role_id = 2 OR P.role_id = 2) AND U.status = 1");
                        }).fetchAll().then(function (result) {
                            var rs = result.toJSON();
                            if (rs.length > 0) {
                                var userfound = null;
                                async.eachSeries(rs, function iteratee(user, callback) {
                                    crypto.comparePassword(user.password, Data.password, user.solt, securityData.key, function (Pres) {
                                        if (Pres) {
                                            userfound = user;
                                        }
                                        callback();
                                    })
                                }, function done() {
                                    if (userfound != null) {
                                        var resUser = {
                                            "f_name": userfound.f_name,
                                            "l_name": userfound.l_name,
                                            "full_name": userfound.f_name + ' ' + userfound.l_name,
                                            "email": userfound.email,
                                            "role_details": userfound.role_details,
                                            "comp_id": userfound.comp_id || userfound.id,
                                            "created": userfound.created,
                                            "modified": userfound.modified
                                        };
                                        var tokenData = resUser;
                                        tokenData.id = userfound.id;
                                        var token = jwt.sign(tokenData, securityData.key, {
                                            expiresIn: req.config.tokenExpiryTime
                                        });
                                        res.json({
                                            status: req.config.statusCode.success,
                                            data: {
                                                'user': resUser,
                                                'token': token
                                            },
                                            message: 'user data'
                                        });
                                    } else {
                                        res.json({
                                            status: req.config.statusCode.error,
                                            error: err,
                                            message: "User not found!"
                                        });
                                    }
                                });
                            } else {
                                res.json({
                                    status: req.config.statusCode.error,
                                    error: err,
                                    message: "User not found!"
                                });
                            }
                        }).catch(function (err) {
                            console.log(err);
                            res.json({
                                status: req.config.statusCode.error,
                                error: err,
                                message: "User not found"
                            });
                        });
                    } else {
                        console.log(err);
                        res.json({
                            status: req.config.statusCode.error,
                            error: err,
                            message: "Unabale to get security info!"
                        });
                    }
                });
            }
        });
    },

    bu_registration: function (req, res, next) {
        var Data = {
            "user_name": req.body.user_name,
            "password": req.body.password,
            "email": req.body.email
        };
        var schema = Joi.object().keys({
            "user_name": Joi.string().required(),
            "password": Joi.string().required(),
            "email": Joi.string().email().required()
        });
        Joi.validate(Data, schema, function (err, value) {
            if (err) {
                res.json({
                    status: req.config.statusCode.error,
                    error: err,
                    message: "Validation errors!"
                });
            } else {
                crypto.generatePassword(Data.password, function (err, solt, cryptedPassword, securityData) {
                    if (!err) {
                        Data.password = cryptedPassword;
                        Data.role_id = 2;
                        Data.solt = solt;
                        Data.created = moment.utc().format('YYYY-MM-DD HH:mm:ss');
                        unique_check('email', Data.email, 'create', 0, function (exist) {
                            if (exist) {
                                res.json({
                                    status: req.config.statusCode.error,
                                    message: "Email  already exist"
                                });
                            } else {
                                unique_check('user_name', Data.user_name, 'create', 0, function (exist) {
                                    if (exist) {
                                        res.json({
                                            status: req.config.statusCode.error,
                                            message: " Username already exist"
                                        });
                                    } else {
                                        Data.activation_key = uuidV4();
                                        new userModel(Data).save().then(function (result) {
                                            //Email code
                                            var email = __rootRequire('app/core/email');
                                            var options = { template: 'invite_email.html', repalcement: { "{{user.name}}": Data.f_name, "{{user.invite_url}}": req.config.businessAdminUrl + '/activateaccount/' + Data.activation_key, "{{logo_url}}": req.config.businessAdminUrl + "/assets/images/logo.png", "{{copyright}}": (new Date().getFullYear()) + " Copyright You__it", "{{link.abuse_email}}": "abuse@youblankit.com" }, to: Data.email, subject: 'Activate Account- You__it.com' };
                                            email.smtp.sendMail(options, function (error, response) {
                                                if (error)
                                                    console.log(error);
                                                else {
                                                    console.log("Message sent: Successfully");
                                                }
                                            });

                                            var resUser = {
                                                "f_name": '',
                                                "l_name": '',
                                                "full_name": '',
                                                "email": Data.email,
                                                "created": Data.created,
                                                "modified": Data.created
                                            };
                                            var tokenData = resUser;
                                            tokenData.id = result.toJSON().id;
                                            var token = jwt.sign(tokenData, securityData.key, {
                                                expiresIn: req.config.tokenExpiryTime
                                            });
                                            res.json({
                                                status: req.config.statusCode.success,
                                                data: {
                                                    'user': resUser,
                                                    'token': token
                                                },
                                                message: 'user data'
                                            });

                                        }).catch(function (err) {
                                            console.log(err);
                                            res.json({
                                                status: req.config.statusCode.error,
                                                error: err,
                                                message: "Registration process failed! Please try again later"
                                            });
                                        });
                                    }
                                })
                            }
                        })
                    } else {
                        console.log(err);
                        res.json({
                            status: req.config.statusCode.error,
                            error: err,
                            message: "Unabale to get security info!"
                        });
                    }
                });
            }
        });
    },

    business_user_list: function (req, res, next) {

        var page = req.query.page - 1 || 0;
        var limit = req.query.limit || 10;
        var offset = limit * page;

        var sort = 'created';
        var order = 'desc';

        var query = "role_id = 2";
        if (utils.notEmpty(req.query.f_name)) {
            query += " AND f_name LIKE '" + req.query.f_name + "%'";
        }

        if (utils.notEmpty(req.query.l_name)) {
            query += " AND l_name LIKE '" + req.query.l_name + "%'";
        }

        if (utils.notEmpty(req.query.email)) {
            query += " AND email LIKE '" + req.query.email + "%'";
        }

        new userModel().query(function (qb) {
            qb.count('* as CNT');
            qb.whereRaw(query);
        }).fetch().then(function (result) {
            var cnt = result.toJSON().CNT;
            new userModel().query(function (qb) {
                qb.whereRaw(query);
                qb.orderBy(sort, order);
                qb.limit(limit).offset(offset);
            }).fetchAll({ columns: ['id', 'f_name', 'l_name', 'email', 'user_name', 'created', 'phone'] }).then(function (results) {
                res.json({
                    status: req.config.statusCode.success,
                    message: 'SUCCESS',
                    data: results.toJSON(),
                    count: cnt
                });
            }).catch(function (err) {
                console.log(err);
                res.json({
                    status: req.config.statusCode.error,
                    error: err,
                    message: "Something went wrong!!"
                });
            });
        }).catch(function (err) {
            console.log(err);
            res.json({
                status: req.config.statusCode.error,
                error: err,
                message: "User not found"
            });
        });
    },

    business_user_add: function (req, res, next) {
        var Data = {
            "f_name": req.body.f_name,
            "l_name": req.body.l_name,
            "email": req.body.email,
            "phone": req.body.phone
        };
        var schema = Joi.object().keys({
            "f_name": Joi.string().required(),
            "l_name": Joi.string().required(),
            "email": Joi.string().email().required(),
            "phone": Joi.string().required()
        });
        Joi.validate(Data, schema, function (err, value) {
            if (err) {
                res.json({
                    status: req.config.statusCode.error,
                    error: err,
                    message: "Validation errors!"
                });
            } else {
                Data.role_id = 2;
                Data.created = moment.utc().format('YYYY-MM-DD HH:mm:ss');
                Data.activation_key = uuidV4();
                new userModel(Data).save().then(function (result) {
                    if (!result) {
                        throw new Error("An error has occurred while processing your request. Try again.");
                    }
                    var data = result.toJSON();
                    var email = __rootRequire('app/core/email');
                    var options = { template: 'invite_email.html', repalcement: { "{{user.name}}": data.f_name, "{{user.invite_url}}": req.config.businessAdminUrl + '/activateaccount/' + data.activation_key, "{{logo_url}}": req.config.businessAdminUrl + "/assets/images/logo.png", "{{copyright}}": (new Date().getFullYear()) + " Copyright You__it", "{{link.abuse_email}}": "abuse@youblankit.com" }, to: data.email, subject: 'Activate Account- You__it.com' };
                    email.smtp.sendMail(options, function (error, response) {
                        if (error)
                            console.log(error);
                        else {
                            console.log("Message sent: Successfully");
                        }
                    });
                    res.json({
                        status: req.config.statusCode.success,
                        data: data,
                        message: "User account created successfully, and account activation link hasbeen sent to his email id."
                    });
                }).catch(function (err) {
                    console.log(err);
                    res.json({
                        status: req.config.statusCode.error,
                        data: null,
                        message: err
                    });
                });
            }


        });
    },

    business_user_edit: function (req, res, next) {
        var id = req.query.id || 0;

        if (id > 0) {
            var Data = {
                "f_name": req.body.f_name,
                "l_name": req.body.l_name,
                "email": req.body.email,
                "phone": req.body.phone
            };
            var schema = Joi.object().keys({
                "f_name": Joi.string().required(),
                "l_name": Joi.string().required(),
                "email": Joi.string().email().required(),
                "phone": Joi.string().required()
            });
            Joi.validate(Data, schema, function (err, value) {
                if (err) {
                    res.json({
                        status: req.config.statusCode.error,
                        error: err,
                        message: "Validation errors!"
                    });
                } else {
                    new userModel().where({ id: id }).save(Data, { patch: true }).then(function (result) {
                        res.json({
                            status: req.config.statusCode.success,
                            data: result.toJSON(),
                            message: "User account updated successfully."
                        });
                    }).catch(function (err) {
                        console.log(err);
                        res.json({
                            status: req.config.statusCode.error,
                            error: err,
                            message: "Something went wrong! Please try again later"
                        });
                    });
                }
            });
        } else {
            res.json({
                status: req.config.statusCode.error,
                error: err,
                message: "Record not found!"
            });
        }
    },

    business_user_delete: function (req, res, next) {
        if (utils.notEmpty(req.body.ids)) {
            new userModel().query(function (qb) {
                qb.whereRaw("id IN(" + req.body.ids.join(',') + ")");
            }).destroy().then(function (result) {
                return res.json({
                    status: req.config.statusCode.success,
                    message: 'Deleted successfully!'
                });
            }).catch(function (err) {
                console.log(err);
                return res.json({
                    status: req.config.statusCode.error,
                    message: 'Unable to delete!',
                    error: err
                });
            });
        } else {
            res.json({
                status: req.config.statusCode.error,
                error: [],
                message: "Please select atlist one record!"
            });
        }
    },

    business_user_get: function (req, res, next) {
        if (utils.notEmpty(req.query.id)) {
            new userModel().query(function (qb) {
                qb.whereRaw("id = " + req.query.id);
            }).fetch().then(function (result) {
                return res.json({
                    status: req.config.statusCode.success,
                    data: result.toJSON(),
                    message: 'User found successfully!'
                });
            }).catch(function (err) {
                console.log(err);
                return res.json({
                    status: req.config.statusCode.error,
                    message: 'Unable to get user!',
                    error: err
                });
            });
        } else {
            res.json({
                status: req.config.statusCode.error,
                error: [],
                message: "Please provide id"
            });
        }
    },

    unique_check_field: function (req, res, next) {
        var prps = req.query.purpose || 'create';
        var user_id = req.user.id || 0;
        if (utils.notEmpty(req.query.field) && utils.notEmpty(req.query.field_value)) {
            unique_check(req.query.field, req.query.field_value, prps, user_id, function (exist) {
                if (exist) {
                    res.json({
                        status: req.config.statusCode.error,
                        message: req.query.field + " already exist"
                    });
                } else {
                    res.json({
                        status: req.config.statusCode.success,
                        message: "Valid"
                    });
                }
            })
        } else {
            res.json({
                status: req.config.statusCode.error,
                message: "Plea se provide field and value!"
            });
        }
    },

    bu_verify_account: function (req, res, next) {
        if (utils.notEmpty(req.query.key)) {
            new userModel().query(function (qb) {
                qb.whereRaw("`activation_key`  =  '" + req.query.key + "' AND `verification_status` = " + 0);
            }).fetch().then(function (result) {
                if (result) {
                    var d = {
                        verification_status: 1,
                        activation_key: ''
                    }
                    result.save(d).then(function (result) {
                        res.json({
                            status: req.config.statusCode.success,
                            message: 'Your account is verified successfully.',
                        });
                    }).catch(function (err) {
                        console.log(err);
                        res.json({
                            status: req.config.statusCode.error,
                            message: 'We are unabale to verified your account. Please contact to admin!',
                            error: err
                        });
                    });
                } else {
                    res.json({
                        status: req.config.statusCode.error,
                        message: 'Invalid activation key!'
                    });
                }
            }).catch(function (err) {
                console.log(err);
                res.json({
                    status: req.config.statusCode.error,
                    message: 'Invalid activation key!',
                    error: err
                });
            });
        } else {
            res.json({
                status: req.config.statusCode.error,
                message: "Please provide key!"
            });
        }
    },

    bu_get_account_status: function (req, res, next) {
        console.log(req.user);
        if (utils.notEmpty(req.user.id)) {
            new userModel().query(function (qb) {
                qb.whereRaw("`id`  =  '" + req.user.id + "'");
            }).fetch().then(function (result) {
                if (result) {
                    var rs = result.toJSON();
                    if (rs.verification_status == 1) {
                        res.json({
                            status: req.config.statusCode.success,
                            message: 'Your account is verified',
                        });
                    } else {
                        res.json({
                            status: req.config.statusCode.error,
                            message: 'Your account is not verified',
                        });
                    }
                } else {
                    res.json({
                        status: req.config.statusCode.error,
                        message: 'User not found!'
                    });
                }
            }).catch(function (err) {
                console.log(err);
                res.json({
                    status: req.config.statusCode.error,
                    message: 'Invalid activation key!',
                    error: err
                });
            });
        }
    },

    bu_forget_username: function (req, res, next) {
        if (utils.notEmpty(req.body.email)) {
            new userModel().query(function (qb) {
                var field = 'email';
                var Q = "`" + field + "` = '" + req.body.email + "'";
                qb.whereRaw(Q);
            }).fetch().then(function (result) {
                if (result == null) {
                    return res.json({
                        status: req.config.statusCode.error,
                        message: 'Please provide correct email!'
                    });
                } else {
                    var Data = {};
                    var Data = result.toJSON();
                    Data.uch_key = uuidV4();
                    new userModel().where({ id: Data.id }).save(Data, { patch: true }).then(function (result) {
                        var Data = result.toJSON();
                        //Email code
                        var email = __rootRequire('app/core/email');
                        var options = { template: 'invite_email.html', repalcement: { "{{user.name}}": Data.f_name, "{{user.invite_url}}": req.config.businessAdminUrl + '/changeusername/' + Data.uch_key, "{{logo_url}}": req.config.businessAdminUrl + "/assets/images/logo.png", "{{copyright}}": (new Date().getFullYear()) + " Copyright You__it", "{{link.abuse_email}}": "abuse@youblankit.com" }, to: Data.email, subject: 'Email verification' };
                        email.smtp.sendMail(options, function (error, response) {
                            if (error)
                                console.log(error);
                            else {
                                return res.json({
                                    status: req.config.statusCode.success,
                                    data: result.toJSON(),
                                    message: 'Check your email for changing username link!'
                                });
                            }
                        });
                    }).catch(function (err) {
                        console.log(err);
                        res.json({
                            status: req.config.statusCode.error,
                            error: err,
                            message: "Registration process failed! Please try again later"
                        });
                    });
                }
            }).catch(function (err) {
                console.log(err);
                return res.json({
                    status: req.config.statusCode.error,
                    message: 'No User present with this email  !',
                    error: err
                });
            });
        } else {
            res.json({
                status: req.config.statusCode.error,
                error: [],
                message: "Please provide email"
            });

        }
    },

    bu_change_username: function (req, res, next) {
        var id = req.query.id;
        if (utils.notEmpty(req.query.id)) {
            var Data = {
                "user_name": req.body.user_name,
            };
            var schema = Joi.object().keys({
                "user_name": Joi.string().required()
            });
            Joi.validate(Data, schema, function (err, value) {
                if (err) {
                    res.json({
                        status: req.config.statusCode.error,
                        error: err,
                        message: "Validation errors!"
                    });
                } else {
                    unique_check('user_name', Data.user_name, 'update', id, function (exist) {
                        if (exist) {
                            res.json({
                                status: req.config.statusCode.error,
                                message: " Username already exist"
                            });
                        } else {
                            new userModel().where({ uch_key: id }).save(Data, { patch: true }).then(function (result) {
                                res.json({
                                    status: req.config.statusCode.success,
                                    data: result.toJSON(),
                                    message: "Username updated successfully."
                                });
                            }).catch(function (err) {
                                res.json({
                                    status: req.config.statusCode.error,
                                    error: err,
                                    message: "Something went wrong! Please try again later"
                                });
                            });
                        }
                    })
                }
            });
        } else {
            res.json({
                status: req.config.statusCode.error,
                message: "Please provide key!"
            });
        }
    },

    bu_verify_uch: function (req, res, next) {
        if (utils.notEmpty(req.query.key)) {
            new userModel().query(function (qb) {
                qb.whereRaw("`uch_key`  =  '" + req.query.key + "' AND `verification_status` = " + 0);
            }).fetch().then(function (result) {
                if (result != null) {
                    res.json({
                        status: req.config.statusCode.success,
                        message: 'true',
                    });
                } else {
                    res.json({
                        status: req.config.statusCode.error,
                        message: 'False'
                    });
                }
            }).catch(function (err) {
                res.json({
                    status: req.config.statusCode.error,
                    message: 'Invalid activation key!',
                    error: err
                });
            });
        } else {
            res.json({
                status: req.config.statusCode.error,
                message: "Please provide key!"
            });
        }
    },

    bu_forget_password: function (req, res, next) {
        if (utils.notEmpty(req.body.email)) {
            new userModel().query(function (qb) {
                var field = 'email';
                var Q = "`" + field + "` = '" + req.body.email + "'";
                qb.whereRaw(Q);
            }).fetch().then(function (result) {
                if (result == null) {
                    return res.json({
                        status: req.config.statusCode.error,
                        message: 'Please provide correct email!'
                    });
                } else {
                    var Data = {};
                    var Data = result.toJSON();
                    Data.pch_key = uuidV4();
                    if (Data.pwd_reset_settings == 0) {
                        new userModel().where({ id: Data.id }).save(Data, { patch: true }).then(function (result) {
                            var Data = result.toJSON();
                            //Email code
                            var email = __rootRequire('app/core/email');
                            var options = { template: 'invite_email.html', repalcement: { "{{user.name}}": Data.f_name, "{{user.invite_url}}": req.config.businessAdminUrl + '/changepassword/' + Data.pch_key, "{{logo_url}}": req.config.businessAdminUrl + "/assets/images/logo.png", "{{copyright}}": (new Date().getFullYear()) + " Copyright You__it", "{{link.abuse_email}}": "abuse@youblankit.com" }, to: Data.email, subject: 'Email verification' };
                            email.smtp.sendMail(options, function (error, response) {
                                if (error)
                                    console.log(error);
                                else {
                                    return res.json({
                                        status: req.config.statusCode.success,
                                        data: result.toJSON(),
                                        message: 'Check your email for changing password link!'
                                    });
                                }
                            });
                        }).catch(function (err) {
                            console.log(err);
                            res.json({
                                status: req.config.statusCode.error,
                                error: err,
                                message: " process failed! Please try again later"
                            });
                        });
                    } else {
                        return res.json({
                            status: req.config.statusCode.error,
                            message: 'You have disabled your password reset function.Please contact admin  !',

                        });
                    }

                }
            }).catch(function (err) {
                console.log(err);
                return res.json({
                    status: req.config.statusCode.error,
                    message: 'No User present with this email  !',
                    error: err
                });
            });
        } else {
            res.json({
                status: req.config.statusCode.error,
                error: [],
                message: "Please provide email"
            });

        }
    },

    bu_account_security: function (req, res, next) {
        var id = req.user.id || 0;
        if (id > 0) {
            var Data = {
                "pwd_reset_settings": req.body.pwd_reset_settings
            };
            var schema = Joi.object().keys({
                "pwd_reset_settings": Joi.number().required()
            });
            Joi.validate(Data, schema, function (err, value) {
                if (err) {
                    res.json({
                        status: req.config.statusCode.error,
                        error: err,
                        message: "Validation errors!"
                    });
                } else {
                    new userModel().where({ id: id }).save(Data, { patch: true }).then(function (result) {
                        res.json({
                            status: req.config.statusCode.success,
                            data: result.toJSON(),
                            message: "Account security updated successfully."
                        });
                    }).catch(function (err) {
                        console.log(err);
                        res.json({
                            status: req.config.statusCode.error,
                            error: err,
                            message: "Something went wrong! Please try again later"
                        });
                    });
                }
            });
        } else {
            res.json({
                status: req.config.statusCode.error,
                message: "Record not found!"
            });
        }
    },

    bu_change_password: function (req, res, next) {
        var id = req.query.id;
        if (utils.notEmpty(req.query.id)) {
            var Data = {
                "password": req.body.password,
            };
            var schema = Joi.object().keys({
                "password": Joi.string().required(),
            });
            Joi.validate(Data, schema, function (err, value) {
                if (err) {
                    res.json({
                        status: req.config.statusCode.error,
                        error: err,
                        message: "Validation errors!"
                    });
                } else {
                    crypto.generatePassword(Data.password, function (err, solt, cryptedPassword, securityData) {
                        if (!err) {
                            Data.password = cryptedPassword;
                            new userModel().where({ pch_key: id }).save(Data, { patch: true }).then(function (result) {
                                res.json({
                                    status: req.config.statusCode.success,
                                    message: "Password updated successfully."
                                });
                            }).catch(function (err) {
                                res.json({
                                    status: req.config.statusCode.error,
                                    error: err,
                                    message: "Password updation process failed! Please try again later"
                                });
                            });
                        } else {
                            res.json({
                                status: req.config.statusCode.error,
                                error: err,
                                message: "Unabale to get security info!"
                            });
                        }
                    });

                }
            });
        } else {
            res.json({
                status: req.config.statusCode.error,
                message: "Please provide key!"
            });
        }
    },

    bu_verify_pch: function (req, res, next) {
        if (utils.notEmpty(req.query.key)) {
            new userModel().query(function (qb) {
                qb.whereRaw("`pch_key`  =  '" + req.query.key + "' AND `verification_status` = " + 0);
            }).fetch().then(function (result) {
                if (result != null) {
                    res.json({
                        status: req.config.statusCode.success,
                        message: 'true',
                    });
                } else {
                    res.json({
                        status: req.config.statusCode.error,
                        message: 'False'
                    });
                }
            }).catch(function (err) {
                res.json({
                    status: req.config.statusCode.error,
                    message: 'Invalid activation key!',
                    error: err
                });
            });
        } else {
            res.json({
                status: req.config.statusCode.error,
                message: "Please provide key!"
            });
        }


    },
    bu_status_change: function (req, res, next) {
        var id = req.body.id || 0;
        if (id > 0) {
            var Data = {
                "status": req.body.status
            };
            console.log("Data@@@@",Data);
            var schema = Joi.object().keys({
                "status": Joi.number().required()
            });
            Joi.validate(Data, schema, function (err, value) {
                if (err) {
                    res.json({
                        status: req.config.statusCode.error,
                        error: err,
                        message: "Validation errors!"
                    });
                } else {
                    new userModel().where({ id: id }).save(Data, { patch: true }).then(function (result) {
                        res.json({
                            status: req.config.statusCode.success,
                            data: result.toJSON(),
                            message: "Account Status updated successfully."
                        });
                    }).catch(function (err) {
                        console.log(err);
                        res.json({
                            status: req.config.statusCode.error,
                            error: err,
                            message: "Something went wrong! Please try again later"
                        });
                    });
                }
            });
        } else {
            res.json({
                status: req.config.statusCode.error,
                message: "Record not found!"
            });
        }
    },

}


function unique_check(field, value, prps, user_id, callback) {
    var Q = "`" + field + "` = '" + value + "'";
    if (prps != 'create') {
        Q += " AND id != " + user_id;
    }
    new userModel().query(function (qb) {
        qb.whereRaw(Q);
    }).fetch().then(function (result) {
        if (result == null) {
            callback(false);
        } else {
            callback(true);
        }
    }).catch(function (err) {
        callback(false);
    });
}        
