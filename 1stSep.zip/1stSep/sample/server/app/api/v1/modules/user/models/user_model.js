var bookshelf = __rootRequire('app/config/bookshelf');
require('./../../roles/models/role_model');
var User = bookshelf.Model.extend({ 
    tableName: 'users',
    idAttribute: 'id',
    role: function () {
        return this.belongsTo('Role', 'role_id');
    }
});

module.exports = bookshelf.model('User', User);
