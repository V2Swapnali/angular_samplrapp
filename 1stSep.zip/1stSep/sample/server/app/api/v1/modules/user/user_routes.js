var crypto = __rootRequire('app/utils/crypto');

module.exports = function(router){

// ========================= User Block =============================
    var user = require('./controllers/user_ctrl')
    router.get('/user/checklogin', user.checklogin)
    router.get('/user/unique_check', user.unique_check_field)
    router.post('/user/changepwd', crypto.ensureAuthorized, user.change_password)

    router.post('/user/sa/login', user.sa_login)
    router.post('/user/sa/profileupdate', crypto.ensureAuthorized, user.sa_profile_update)

    router.get('/user/businessuser/get', crypto.ensureAuthorized, user.business_user_get)
    router.get('/user/businessuser/list', crypto.ensureAuthorized, crypto.ensureAccess, user.business_user_list)
    router.post('/user/businessuser/add', crypto.ensureAuthorized, crypto.ensureAccess, user.business_user_add)
    router.post('/user/businessuser/edit', crypto.ensureAuthorized, crypto.ensureAccess, user.business_user_edit)
    router.post('/user/businessuser/delete', crypto.ensureAuthorized, crypto.ensureAccess, user.business_user_delete)
    
    router.post('/user/bu/login', user.bu_login)
    router.post('/user/bu/profileupdate', crypto.ensureAuthorized, user.bu_profile_update)
    router.post('/user/bu/registration', user.bu_registration)    
    router.get('/user/bu/verify_account', user.bu_verify_account)
    router.get('/user/bu/verificationstatus', crypto.ensureAuthorized, user.bu_get_account_status)
    router.post('/user/bu/forget_username',  user.bu_forget_username)
    router.post('/user/bu/change_username/edit',  user.bu_change_username)
    router.get('/user/bu/verifyuch', user.bu_verify_uch)
    router.post('/user/bu/account_security', crypto.ensureAuthorized, user.bu_account_security)
    router.post('/user/bu/forget_password',  user.bu_forget_password)
    router.post('/user/bu/change_password/edit',  user.bu_change_password)
    router.get('/user/bu/verifypch', user.bu_verify_pch)
    router.post('/user/bu/status_change', crypto.ensureAuthorized, user.bu_status_change)
    
    
// ========================= User Block =============================

    return router;
}
