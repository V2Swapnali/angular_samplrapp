module.exports = function(express){
    var router = express.Router()
   
    require('./modules/user/user_routes')(router);
    require('./modules/subscription/subscription_routes')(router);
    require('./modules/product/product_routes')(router);
    require('./modules/product_category/product_category_routes')(router);
    require('./modules/configure_option/configoption_routes')(router);
    require('./modules/roles/role_routes')(router);
    require('./modules/permission/permission_routes')(router);
    require('./modules/staff/staff_routes')(router);
    require('./modules/customers/customer_routes')(router);
    require('./modules/vendors/vendor_routes')(router);
    require('./modules/countries/countries_routes')(router);
    require('./modules/states/state_routes')(router);
    require('./modules/company_detail/companyDetail_routes')(router);
    require('./modules/company_location/companyLocation_routes')(router);
    require('./modules/orders/order_routes')(router);
    require('./modules/timezones/timezone_routes')(router);
    require('./modules/settings/settings_routes')(router);

    return router;
}

