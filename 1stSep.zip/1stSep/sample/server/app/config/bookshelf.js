var dbConfig = {
    client: 'mysql',  
    connection: {
        host: '45.34.2.20',
        user: 'ybi',
        password: 'Y79yrt456Itr6',
        database: 'db_ybi',
        charset: 'utf8',
        debug: ['ComQueryPacket'],
        timezone: "UTC"
    }
};

/*var dbConfig = {
    client: 'mysql',  
    connection: {
        host: 'localhost',
        user: 'root',
        password: 'root',
        database: 'db_ybi',
        charset: 'utf8',
        debug: ['ComQueryPacket'],
        timezone: "UTC"
    }
};*/

var knex = require('knex')(dbConfig);
var bookshelf = require('bookshelf')(knex);
bookshelf.plugin('registry');
module.exports = bookshelf;