module.exports = {
    //secureServerUrl: 'http://45.34.2.22:5001',
    secureServerUrl: 'http://localhost:5001',
    businessAdminUrl: 'http://45.34.2.19:5004',
    authPass: 'dhjfsdf456bkjhjbkj456546kj@d6*Fsgkjdhsgkjs&*3E$feq',
    tokenExpiryTime: '24 hours',
    statusCode: {
        'success': 200,
        'error': 201,
        'authErr': 203
    },
    env:'development'
};
