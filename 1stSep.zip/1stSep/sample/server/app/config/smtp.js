var config = {};
config.development = {
  options :{
            from: 'info@youblankit.com'
  },
connectionURL:'smtps://viralcontentsystem@gmail.com:viral@123@smtp.gmail.com',
templatePath  :__rootRequire('app/core/email/templates/')
};

module.exports = config; 