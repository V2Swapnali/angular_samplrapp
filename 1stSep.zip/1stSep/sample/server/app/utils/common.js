var config      = require('./../config/config');
var async       = require('async');

module.exports = {
    notEmpty: function(data) {
        var res = true;
        var dataType = typeof data;
        switch (dataType) {
            case 'object':
            case 'array':
                if (data == null || data.length < 1)
                    res = false;
                break;

            case 'undefined':
                res = false;
                break;

            case 'number':
                if (data == "")
                    res = false;
                break;
            case 'string':
                if (data.trim() == "")
                    res = false;
                break;
        }

        return res;
    },
    remove_empty: function(data) {
        var y;
        for (var x in data) {
            y = data[x];
            if (y === "null" || y === null || y === "" || typeof y === "undefined" || (y instanceof Object && Object.keys(y).length == 0)) {
                delete data[x];
            }
            if (y instanceof Object)
                y = this.remove_empty(y);
        }
        return data;
    }
};