var jwt = require('jsonwebtoken');
var crypto = require('crypto');
var config = require('./../config/config');
var async = require('async');
var fs = require('fs');
var algorithm = 'aes-256-ctr';

module.exports = {
    getSecurityInfo: function (type, callback) {
        var request = require('request');
        request.post({
            url: config.secureServerUrl + '/api/v1/gd',
            form: { 'type': type, pwd: config.authPass }
        }, function (err, httpResponse, body) {
            if (!err) {
                callback(null, JSON.parse(body).data);
            } else {
                callback(err);
            }
        });
    },
    
    ensureAuthorized: function (req, res, next) {
        var bearerToken;
        var bearerHeader = req.headers["authorization"];
        if (typeof bearerHeader !== 'undefined') {
            bearerToken = bearerHeader.replace('bearer ', '');
            req.token = bearerToken;

            var request = require('request');
            request.post({
                url: config.secureServerUrl + '/api/v1/gd',
                form: { 'type': 'secratekey', pwd: config.authPass }
            }, function (err, httpResponse, body) {
                if (!err) {
                    var securityData = JSON.parse(body).data;
                    jwt.verify(bearerToken, securityData.key, function (err, decoded) {
                        req.user = decoded;
                        if (err) {
                            res.json({
                                status: req.config.statusCode.authErr,
                                error: err,
                                message: 'Invalid Token!'
                            });
                        } else {
                            next();
                        }
                    });
                } else {
                    res.json({
                        status: req.config.statusCode.authErr,
                        error: err,
                        message: "Unabale to get security info!"
                    });
                }
            });
        } else {
            res.json({
                status: req.config.statusCode.authErr,
                message: 'Token not found!'
            });
        }
    },

    ensureAccess: function (req, res, next) {
        if (req.user) {
            if (req.user.role_details != 'ALL') { console.log(req.user);
                var userPermissions = req.user.role_details.split(',');
                if (typeof req.modulesArray[req.path] != 'undefined') {
                    if (userPermissions.indexOf(String(req.modulesArray[req.path])) >= 0) {
                        next();
                    } else {
                        res.json({
                            status: req.config.statusCode.authErr,
                            message: "You are not authorized to access this module"
                        });
                    }
                } else {
                    res.json({
                        status: req.config.statusCode.authErr,
                        message: "You are not authorized to access this module!"
                    });
                }
            } else {
                next();
            }
        } else {
            next();
        }
    },

    generatePassword: function (myPlaintextPassword, callback) {
        this.getSecurityInfo('secratekey', function (err, securityData) {
            if (!err) {
                //var salt = bcrypt.genSaltSync(8);
                //var passwordHash  = bcrypt.hashSync(myPlaintextPassword, salt);
                var salt = crypto.randomBytes(64).toString('base64');
                var passwordHash = myPlaintextPassword + salt;
                var cipher = crypto.createCipher(algorithm, securityData.key)
                var crypted = cipher.update(passwordHash, 'utf8', 'hex')
                var cryptedPassword = crypted + cipher.final('hex');
                callback(null, salt, cryptedPassword, securityData);
            } else {
                callback(err);
            }
        });
    },

    comparePassword: function (pData, password, solt, securityKey, callback) {
        var decipher = crypto.createDecipher(algorithm, securityKey);
        var dec = decipher.update(pData, 'hex', 'utf8');
        dec += decipher.final('utf8');
        var pass = dec.replace(solt, '');
        if (pass == password) {
            return callback(true);
        } else {
            return callback(false);
        }
    }
};