var config = require('./config');

var dbConfig = {
    // local: {
    //     client: 'pg',
    //     connection: {
    //         host: process.env.LOCAL_DB_HOST,
    //         user: process.env.LOCAL_DB_USER,
    //         password: process.env.LOCAL_DB_PASS,
    //         database: process.env.LOCAL_DB_NAME,
    //         charset: 'utf8',
    //         debug: true,
    //         timezone: "UTC"
    //     }
    // },
    // production: {
    //     client: 'pg',
    //     connection: {
    //         host: 'localhost',
    //         user: '',
    //         port: 5432,
    //         password: '',
    //         database: '',
    //         charset: 'utf8',
    //         debug: true,
    //         timezone: "UTC"
    //     }
    // },
    // development: {
    //     client: 'pg',
    //     connection: {
    //         host: 'localhost',
    //         user: 'wicare',
    //         password: 'wicare20170',
    //         database: 'wicare',
    //         charset: 'utf8',
    //         debug: true,
    //         debug: ['ComQueryPacket'],
    //         timezone: "UTC"
    //     }
    // },
    // aws: {
    //     client: 'pg',
    //     connection: {
    //         host: process.env.AWS_DB_HOST,
    //         user: process.env.AWS_DB_USER,
    //         password: process.env.AWS_DB_PASS,
    //         database: process.env.AWS_DB_V2_NAME,
    //         port: 5432,
    //         charset: 'utf8',
    //         debug: true,
    //         timezone: "UTC"
    //     }
    // },
    // test: {
    //     client: 'pg',
    //     connection: {
    //         host: '52.39.212.226',
    //         user: 'wicare',
    //         password: 'wicare20170',
    //         database: 'wicare',
    //         port: 5432,
    //         charset: 'utf8',
    //         debug: true,
    //         timezone: "UTC"
    //     }
    // }
    test: {
        client: 'pg',
        connection: {
            host: '127.0.0.1',
            user: 'postgres',
            password: 'postgres',
            database: 'postgres',
            port: 5432,
            charset: 'utf8',
            debug: true,
            timezone: "UTC"
        }
    }
};
//__debug("v1 ",dbConfig[config.env])
//var knex = require('knex')(dbConfig[config.env]);
var knex = require('knex')(dbConfig["test"]);

var bookshelf = require('bookshelf')(knex);
bookshelf.plugin('registry');
bookshelf.plugin('virtuals'); //https://github.com/tgriesser/bookshelf/wiki/Plugin:-Virtuals
bookshelf.plugin('pagination'); //fetchPage({page: 10, pageSize: 20});   //https://github.com/tgriesser/bookshelf/wiki/Plugin:-Pagination
module.exports = bookshelf;