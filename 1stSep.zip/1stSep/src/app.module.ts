import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ToastrModule } from 'ngx-toastr';
import { AppComponent } from './app.component';
import { AppRoutingModule } from "app/app-routing.module";
import { PageNotFountComponent } from "app/pagenotfound.component";
import { AuthGuard } from "app/core/guards/auth.guard";
import { AuthService } from "app/core/services/auth.service";
import { RouterModule } from "@angular/router";

import { HttpClient } from './utility/http.client';
import { AppConfig } from './config/app.config';
import { WebStorage } from './utility/web.storage';

@NgModule({
  declarations: [
    AppComponent,
    PageNotFountComponent
  ],
  imports: [
    BrowserModule,
    RouterModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot(),
    HttpModule,
    AppRoutingModule
  ],
  providers: [
    AuthGuard,
    AuthService, 
    HttpClient,
    AppConfig,
    WebStorage
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
