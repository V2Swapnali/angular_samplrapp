import { Injectable } from '@angular/core';
import { Headers } from '@angular/http';

@Injectable()
export class AppConfig {
    //withoutLoginUrls:any = ['login','registration'];
    //apiUrl:any = "http://45.34.2.19:5004/api";
    apiUrl:any = "http://localhost:3000/api";
    perPageDefault:any = 5;
    perPageArray:any = [5,10,20,30,40,50];
    MOMENT_DATE_TIME_FORMAT:any = 'YYYY-MM-DD HH:mm:ss';    
    statusCode: {
        'success': 'OK',
        'badRequest':'BAD_REQUEST',
        'unauthorized': 'UNAUTHORIZED',        
        'forbidden':'FORBIDDEN',
        'notFound':'NOT_FOUND',
        'error': 'INTERNAL_ERROR',
        'invalid':'INVALID',
        'serviceUnavailable':'UNAVAILABLE',        
    };
    pattern:any = {
        'NAME':/^[a-zA-Z . \-\']*$/,
        'CMPNAME':/^[a-zA-Z0-9 ]*$/,
        'USERNAME':/^[a-zA-Z0-9]*$/,
        "CITY":/^[a-zA-Z . \-\']*$/,               
        "EMAIL":/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
        "POSTAL_CODE":/(^\d{5}$)|(^\d{5}-\d{4}$)/,
        "PASSWORD":/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{5,15}$/
    };
    productType:any = [
        {id: "consumable", text: "Consumable (Non tracking)"},
        {id: "service_non_tracking", text: "Service (non tracking)"},
        {id: "service_tracking", text: "Service (tracking)"},
        {id: "stockable", text: "Stockable Product (Inventory tracking)"}
    ];
   goodsType:any = [
        {id: "products", text: "Products"},
        {id: "service", text: "Service"}
    ];
    fldType:any = [
        {id: "text", text: "Text", unt: false},
        {id: "textunit", text: "Text With Unit", unt: true},
        {id: "numeric", text: "Numeric", unt: false},
        {id: "numericunit", text: "Numeric With Unit", unt: true},
        {id: "select", text: "Select", unt: false},
        {id: "selectunit", text: "Select With Unit", unt: true}
    ];
}