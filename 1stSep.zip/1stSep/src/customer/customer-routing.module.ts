import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { CustomerComponent } from "app/customer/customer.component";
import { CustomeraddComponent } from "app/customer/components/add-customer/add-customer.component";
import { CustomerlistComponent } from "app/customer/components/list-customer/list-customer.component";

const routes: Routes = [
    {
        path: '',
        component: CustomerComponent,
        children: [
            { path: '', component: CustomerlistComponent },
            { path: 'customer-add', component: CustomeraddComponent }
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class CustomerRoutingModule {

}