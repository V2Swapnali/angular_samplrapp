import { NgModule } from "@angular/core/";
import { CommonModule } from "@angular/common";
import { CustomerRoutingModule } from "app/customer/customer-routing.module";
import { CustomerComponent } from "app/customer/customer.component";
import { CustomeraddComponent } from "app/customer/components/add-customer/add-customer.component";
import { CustomerlistComponent } from "app/customer/components/list-customer/list-customer.component";
import { CustomerService } from "app/customer/services/customer.services";
import { HttpModule } from '@angular/http';
import { MyDatePickerModule } from 'mydatepicker';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ModalModule } from "ngx-bootstrap/modal";

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        HttpModule,
        ReactiveFormsModule,
        ModalModule.forRoot(),        
        MyDatePickerModule,
        CustomerRoutingModule
    ],
    declarations: [
        CustomerComponent,
        CustomeraddComponent,
        CustomerlistComponent
    ],
    providers: [
        CustomerService
    ]
})
export class CustomerModule {

}