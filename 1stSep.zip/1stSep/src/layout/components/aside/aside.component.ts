import { Component } from "@angular/core";

@Component({
    selector: 'sidebar-component',
    templateUrl: 'aside.component.html'
})
export class SidebarComponent {

}